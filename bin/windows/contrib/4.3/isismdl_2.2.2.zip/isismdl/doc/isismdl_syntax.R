## ----include = FALSE----------------------------------------------------------
file.copy("syntax_data/example.mdl", "example.mdl")
library(isismdl)

## -----------------------------------------------------------------------------
library(isismdl)
isis_mdl("example.mdl", parse_options = list(flags = "x_zero"))

## -----------------------------------------------------------------------------
isis_mdl("example.mdl")

## ----include = FALSE----------------------------------------------------------
unlink(c("example.mdl", "example.mrf"))

