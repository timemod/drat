## ----echo = FALSE, message = FALSE--------------------------------------------

library(isismdl)

# input/output chunks are separated
# R inputlines start with >, outputlines with nothing
knitr::opts_chunk$set(collapse = FALSE, comment = "", prompt = TRUE)

## ----echo = FALSE, message = FALSE--------------------------------------------
unlink("islm.mdl")

## ----results='hide'-----------------------------------------------------------
mdl_file <- system.file("models", "islm.mdl", package = "isismdl")
file.copy(mdl_file, "islm.mdl")

## ----echo = FALSE, comment=''-------------------------------------------------
cat(readLines('islm.mdl'), sep = '\n')

## -----------------------------------------------------------------------------
mdl <- isis_mdl("islm.mdl")

## ----echo = FALSE-------------------------------------------------------------
cat(readLines('islm.mrf'), sep = '\n')

## -----------------------------------------------------------------------------
mdl$get_param(names = c("m0", "c1"))

## -----------------------------------------------------------------------------
mdl$set_param(list(m0 = 100))
mdl$get_param("m0")

## -----------------------------------------------------------------------------
mdl2 <- mdl

## -----------------------------------------------------------------------------
mdl2$set_param(list(m0 = 75))
mdl$get_param("m0")

## -----------------------------------------------------------------------------
mdl2 <- mdl$copy()
mdl2$set_param(list(m0 = -9999))
mdl$get_param("m0")

## -----------------------------------------------------------------------------
# exogenous variables:
g  <- regts(210 * cumprod(rep(1.015, 6)), start = "2017Q1")
ms <- regts(200 * cumprod(rep(1.015, 6)), start = "2017Q1")
# feedback variables (with lag):
r <- regts(3.4, period = "2016Q4/2018Q2")
y <- regts(980, period = "2016Q4/2018Q2")
# lagged variable
yd <- regts(790, start = "2016Q4")
data <- cbind(g, ms, r, y, yd)
data

## -----------------------------------------------------------------------------
mdl$set_period(period_range("2017Q1", "2018Q2"))
mdl

## -----------------------------------------------------------------------------
mdl$set_data(data)

## -----------------------------------------------------------------------------
mdl$get_data()

## -----------------------------------------------------------------------------
mdl$solve()

## -----------------------------------------------------------------------------
mdl$get_data()

## -----------------------------------------------------------------------------
mdl$write_mdl(file = "islm_mdl.ismdl")

## ---- results = "hide"--------------------------------------------------------
mdl <- read_mdl("islm_mdl.ismdl")

## ---- echo = FALSE, results = "hide"------------------------------------------
unlink("islm_mdl.rds")

