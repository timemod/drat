## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, collapse = FALSE, comment = "")
library(umfpackr)

## -----------------------------------------------------------------------------
dslnex <- function(x) {
   y <- numeric(2)
   y[1] <- x[1]^2 + x[2]^2 - 2
   y[2] <- exp(x[1]-1) + x[2]^3 - 2
   return(y)
}

jacdsln <- function(x) {
   n <- length(x)
   Df <- matrix(numeric(n*n),n,n)
   Df[1,1] <- 2*x[1]
   Df[1,2] <- 2*x[2]
   Df[2,1] <- exp(x[1]-1)
   Df[2,2] <- 3*x[2]^2
   return(as(Df, "dgCMatrix"))
}

xstart <- c(2,3)

# use CHOLMOD ordering on Linux and AMD on Windows
ord <- if (.Platform$OS.type != "windows")  "CHOLMOD" else "AMD"
umf_solve_nl(xstart, dslnex, jacdsln, umf_control = list(ordering = ord))

