## ----echo = FALSE, message = FALSE--------------------------------------------
knitr::opts_chunk$set(collapse = FALSE, comment = "", prompt = TRUE)

## ---- eval = FALSE------------------------------------------------------------
#  library(cbsots)
#  edit_ts_code("tscode.rds")

## ----include = FALSE----------------------------------------------------------
library(cbsots)
file.copy("tutorial_data/tscode_final.rds", "tscode.rds")

## -----------------------------------------------------------------------------
ts_code <- readRDS("tscode.rds")

## -----------------------------------------------------------------------------
data <- get_ts("70076ned", ts_code)

## -----------------------------------------------------------------------------
data

## -----------------------------------------------------------------------------
data <- get_ts("70076NED", ts_code)

## ----echo = FALSE-------------------------------------------------------------
unlink("raw_cbs_data", recursive = TRUE)
unlink("tscode.rds")

