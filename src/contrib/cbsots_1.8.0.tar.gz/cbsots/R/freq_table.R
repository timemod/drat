# table of frequencies
freq_table <- data.frame(freq_cbs = c("JJ", "HJ", "KW", "MM"),
                         freq     = c( "Y",  "H",  "Q",  "M"),
                         freq_num = c(   1,   2,    4,   12))
