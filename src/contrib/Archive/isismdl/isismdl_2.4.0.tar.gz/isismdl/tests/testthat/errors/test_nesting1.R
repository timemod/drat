library(isismdl)
library(testthat)
library(readr)

rm(list = ls())

update_expected <- FALSE


test_that("error given", {
  msg <- "Error detected in compilation of model mdl/nesting1\nCheck the .err file"
  expect_error(capture_output(mdl <- isis_mdl("mdl/nesting1")), msg)
})

test_that("error file correct", {
  error_txt <- read_file("mdl/nesting1.err")
  if (.Platform$OS.type == "windows") {
    error_txt <- gsub("\r", "", error_txt)
  }
  #cat(error_txt)
  expect_known_output(cat(error_txt), "expected_output/nesting1.txt",
                      update = update_expected)
})
