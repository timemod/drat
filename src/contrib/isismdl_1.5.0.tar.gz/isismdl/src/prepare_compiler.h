void prepare_compiler(SEXP flags, SEXP include_dirs);
