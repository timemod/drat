library(isismdl)
library(testthat)
library(utils)

context("solve IFN model")
capture_output(ifn_mdl <- read_mdl("ifn_mdl.rds"))

isis_result <- as.regts(read.csv("isi/solve.csv"), time_column = 1)
mdl_per <- ifn_mdl$get_period()

test_that("ftrelax correctly read from file", {
  res_correct <- c(a = NA, eta = NA, lambda = 0.5, mzk = NA, px = NA, rho = NA)
  expect_identical(ifn_mdl$get_ftrelax(), res_correct)
})

test_that("get_var_names/get_endo_names for (endogenous) leads", {

  all_leads <- c("a", "eta", "gpx", "groei", "lambda", "mzk", "px", "rho",
                 "tc")
  endo_leads <- c("a", "eta", "lambda", "mzk", "px", "rho")

  expect_identical(ifn_mdl$get_var_names(type = "leads"), all_leads)
  expect_identical(ifn_mdl$get_endo_names(type = "endolead"), endo_leads)
  expect_identical(intersect(all_leads, ifn_mdl$get_endo_names()), endo_leads)
})

test_that("solve options read from file", {
  options_set <- list(xmaxiter = 1500, ratreport = "iter",
                      report = "minimal", ratreport_rep = 10,
                      ratfullreport_rep = 50)
  expect_equal(ifn_mdl$get_solve_options()[names(options_set)], options_set)
})

test_that("model administration correct", {
  expect_identical(mdl_per, period_range("2y", "100y"))
  expect_identical(ifn_mdl$get_data_period(), period_range("1y", "101y"))
  expect_identical(ifn_mdl$get_var_names(), colnames(isis_result))
})

test_that("solve result almost identical to Isis result", {
  ifn_mdl2 <- ifn_mdl$copy()
  ifn_mdl2$solve(options = list(report = "none"))
  dif <- tsdif(ifn_mdl2$get_data(period = mdl_per), isis_result, tol = 1e-6,
               fun = cvgdif)
  expect_identical(dif$missing_names1, character(0))
  expect_identical(dif$missing_names2, character(0))
  expect_identical(dif$difnames, character(0))
})

test_that("warning when Fair-Taylor has not converged", {
  ifn_mdl2 <- ifn_mdl$copy()
  expect_warning(ifn_mdl2$solve(options = list(xmaxiter = 10,
                                               report = "none")),
                           "Fair-Taylor has not converged")
})

test_that("errors", {
 ifn_mdl2 <- ifn_mdl$copy()
 expect_error(ifn_mdl2$solve(options = list(xmaxiter = 0, report = "none")),
              "xmaxiter should be larger than 0")
})
