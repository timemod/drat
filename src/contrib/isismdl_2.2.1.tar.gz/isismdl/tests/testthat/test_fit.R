library(testthat)
source_test_helpers(path = "fit")
source_dir(path = "fit", pattern = "test_.*[rR]$")
