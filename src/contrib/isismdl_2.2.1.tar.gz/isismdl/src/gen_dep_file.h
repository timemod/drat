SEXP gen_dep_file(SEXP filename, SEXP outputfile);
