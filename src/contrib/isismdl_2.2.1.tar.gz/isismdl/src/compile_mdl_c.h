SEXP compile_mdl_c(SEXP filename, SEXP mifname, SEXP ppfname,
		   SEXP flags, SEXP include_dirs);
