
void init_options(int n_options);
void add_option(const char *name, SEXP value);
SEXP get_options(void);
