# maximum length of a url, used to determine which filters are used to 
# download the data
MAX_URL_LEN <- 8000
DEBUG <- FALSE