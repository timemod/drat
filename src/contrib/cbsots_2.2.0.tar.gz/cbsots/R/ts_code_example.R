#' An example `ts_code` object
#' 
#' A `ts_code` object containing timeseries coding for three CBS tables. 
#' This object is used for demonstrating several functions of 
#' package `cbsots`. 
"ts_code_example"