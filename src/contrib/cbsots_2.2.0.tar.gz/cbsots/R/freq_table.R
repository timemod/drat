# table of frequencies
# CBS frequency MC are cumulative monthly series
# (the monthly value is the cumulative value for the year).
# An example of a table with cumulative series is 
# https://mlzopendata.cbs.nl/#/MLZ/nl/dataset/40079NED.
freq_table <- data.frame(freq_cbs = c("JJ", "HJ", "KW", "MM", "MC"),
                         freq     = c( "Y",  "H",  "Q",  "M",  "M"),
                         freq_num = c(   1,   2,    4,   12,   12))
