library(cbsots)
library(testthat)

rm(list = ls())


# Use UTF-8 endocing, because the Titles contains diacritical characters 
# and the data files have been created with UTF-8 encoding 
options(encoding = "UTF-8")

ts_code_file <- "tscode/tscode_mlz_40079NED.rds"

#edit_ts_code(ts_code_file)

ts_code <- readRDS(ts_code_file)

source("utils/check_ts_table.R")

id <- "40079NED"

raw_cbs_dir <- tempfile(pattern = "raw_cbs_dir")

test_that(paste(id, "(example of cumulative monthly series"), {
  
  expect_output(
    expect_warning(
      expect_error(
        result1 <- get_ts(id, ts_code, download = TRUE, 
                          min_year = 2019, raw_cbs_dir = raw_cbs_dir, 
                          base_url = "https://dataderden.cbs.nl",
                          frequencies = "Q"),
        "None of the requested frequencies is present in the CBS data",
        fixed = TRUE
      ),
      "Frequencies Q not present in CBS data",
      fixed = TRUE
    )
  )
  
  expect_output(
    result1 <- get_ts(id, ts_code, download = TRUE, 
                      min_year = 2019, raw_cbs_dir = raw_cbs_dir, 
                      base_url = "https://dataderden.cbs.nl")
  )

  check <- check_ts_table(result1, id, raw_cbs_dir = raw_cbs_dir)
  expect_true(check)
  
  result2 <- get_ts(id, ts_code, download = FALSE, 
                    raw_cbs_dir = raw_cbs_dir, 
                    min_year = 2019,
                    base_url = "https://dataderden.cbs.nl",
                    frequencies = "M")
  expect_identical(result1, result2)
  
  result3 <- get_ts(id, ts_code, download = FALSE, 
                    raw_cbs_dir = raw_cbs_dir, 
                    min_year = 2019,
                    base_url = "https://dataderden.cbs.nl")
  expect_identical(result1, result3)
  
  expect_output(
    result4 <- get_ts(id, ts_code, download = TRUE, 
                      min_year = 2019, raw_cbs_dir = raw_cbs_dir, 
                      base_url = "https://dataderden.cbs.nl",
                      frequencies = "M")
  )
  
  expect_identical(result1, result4)
  
  result5 <- get_ts(id, ts_code, download = FALSE, 
                    raw_cbs_dir = raw_cbs_dir, 
                    min_year = 2022,
                    base_url = "https://dataderden.cbs.nl")
  
  result5_expected <- result1
  result5_expected$M <- na_trim(result5_expected$M["2022/"], method = "first")
  
  expect_identical(result5, result5_expected)
})
