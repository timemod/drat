library(testthat)
source_test_helpers(path = "misc")
source_dir(path = "misc", pattern = "test_.*[rR]$")
