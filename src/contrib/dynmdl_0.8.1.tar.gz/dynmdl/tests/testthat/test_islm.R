library(testthat)
source_test_helpers(path = "islm")
source_dir(path = "islm", pattern = "test_.*[rR]$")
