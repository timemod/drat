function [residual, g1, g2, g3] = islm_if_fit_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           rows: equations in order of declaration
%                                                           columns: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(20, 1);
lhs =y(12);
rhs =params(21)+params(22)*y(5);
residual(1)= lhs-rhs;
lhs =y(11);
rhs =min(x(it_, 1)+10,y(12))+y(13);
residual(2)= lhs-rhs;
lhs =y(5);
rhs =x(it_, 1)+y(7)+y(8);
residual(3)= lhs-rhs;
lhs =y(6);
rhs =y(5)-y(11);
residual(4)= lhs-rhs;
lhs =y(7);
rhs =params(5)+params(6)*y(2)+y(6)*params(7)+params(8)*y(26)+params(9)*y(10)+params(10)*y(10)^2+y(14);
residual(5)= lhs-rhs;
lhs =y(8);
rhs =params(11)+params(12)*y(1)+y(5)*params(13)+params(14)*y(25)+y(10)*params(15)+y(10)^2*params(16)+y(16);
residual(6)= lhs-rhs;
lhs =y(9);
rhs =params(17)+y(5)*params(18)+y(10)*params(19)+y(10)^2*params(20)+y(15);
residual(7)= lhs-rhs;
lhs =y(9);
rhs =x(it_, 2);
residual(8)= lhs-rhs;
residual(9) = y(13)/params(1)^2-y(18);
residual(10) = y(14)/params(2)^2-y(21);
residual(11) = y(15)/params(3)^2-y(23);
residual(12) = y(16)/params(4)^2-y(22);
residual(13) = x(it_, 3)*(y(5)-x(it_, 11))+(1-x(it_, 3))*(y(28)*(-params(12))+y(17)*(-params(22))+y(19)-y(20)+y(22)*(-params(13))+y(23)*(-params(18))+y(4)*(-params(14)));
residual(14) = x(it_, 4)*(y(6)-x(it_, 12))+(1-x(it_, 4))*(y(20)+y(27)*(-params(6))+y(21)*(-params(7))+y(3)*(-params(8)));
residual(15) = x(it_, 5)*(y(7)-x(it_, 13))+(1-x(it_, 5))*(y(21)-y(19));
residual(16) = x(it_, 6)*(y(8)-x(it_, 14))+(1-x(it_, 6))*(y(22)-y(19));
residual(17) = x(it_, 7)*(y(9)-x(it_, 15))+(1-x(it_, 7))*(y(23)+y(24));
residual(18) = x(it_, 8)*(y(10)-x(it_, 16))+(1-x(it_, 8))*(y(21)*(-(params(9)+y(10)*2*params(10)))+y(22)*(-(params(15)+y(10)*2*params(16)))+y(23)*(-(params(19)+y(10)*2*params(20))));
residual(19) = x(it_, 9)*(y(11)-x(it_, 17))+(1-x(it_, 9))*(y(18)+y(20));
residual(20) = x(it_, 10)*(y(12)-x(it_, 18))+(1-x(it_, 10))*(y(17)+y(18)*(-(1-(y(12)>x(it_, 1)+10))));
if nargout >= 2,
  g1 = zeros(20, 46);

  %
  % Jacobian matrix
  %

  g1(1,5)=(-params(22));
  g1(1,12)=1;
  g1(2,11)=1;
  g1(2,12)=(-(1-(y(12)>x(it_, 1)+10)));
  g1(2,29)=(-(y(12)>x(it_, 1)+10));
  g1(2,13)=(-1);
  g1(3,5)=1;
  g1(3,7)=(-1);
  g1(3,8)=(-1);
  g1(3,29)=(-1);
  g1(4,5)=(-1);
  g1(4,6)=1;
  g1(4,11)=1;
  g1(5,2)=(-params(6));
  g1(5,6)=(-params(7));
  g1(5,26)=(-params(8));
  g1(5,7)=1;
  g1(5,10)=(-(params(9)+params(10)*2*y(10)));
  g1(5,14)=(-1);
  g1(6,1)=(-params(12));
  g1(6,5)=(-params(13));
  g1(6,25)=(-params(14));
  g1(6,8)=1;
  g1(6,10)=(-(params(15)+params(16)*2*y(10)));
  g1(6,16)=(-1);
  g1(7,5)=(-params(18));
  g1(7,9)=1;
  g1(7,10)=(-(params(19)+params(20)*2*y(10)));
  g1(7,15)=(-1);
  g1(8,9)=1;
  g1(8,30)=(-1);
  g1(9,13)=1/params(1)^2;
  g1(9,18)=(-1);
  g1(10,14)=1/params(2)^2;
  g1(10,21)=(-1);
  g1(11,15)=1/params(3)^2;
  g1(11,23)=(-1);
  g1(12,16)=1/params(4)^2;
  g1(12,22)=(-1);
  g1(13,5)=x(it_, 3);
  g1(13,17)=(1-x(it_, 3))*(-params(22));
  g1(13,19)=1-x(it_, 3);
  g1(13,20)=(-(1-x(it_, 3)));
  g1(13,4)=(1-x(it_, 3))*(-params(14));
  g1(13,22)=(1-x(it_, 3))*(-params(13));
  g1(13,28)=(1-x(it_, 3))*(-params(12));
  g1(13,23)=(1-x(it_, 3))*(-params(18));
  g1(13,31)=y(5)-x(it_, 11)-(y(28)*(-params(12))+y(17)*(-params(22))+y(19)-y(20)+y(22)*(-params(13))+y(23)*(-params(18))+y(4)*(-params(14)));
  g1(13,39)=(-x(it_, 3));
  g1(14,6)=x(it_, 4);
  g1(14,20)=1-x(it_, 4);
  g1(14,3)=(1-x(it_, 4))*(-params(8));
  g1(14,21)=(1-x(it_, 4))*(-params(7));
  g1(14,27)=(1-x(it_, 4))*(-params(6));
  g1(14,32)=y(6)-x(it_, 12)-(y(20)+y(27)*(-params(6))+y(21)*(-params(7))+y(3)*(-params(8)));
  g1(14,40)=(-x(it_, 4));
  g1(15,7)=x(it_, 5);
  g1(15,19)=(-(1-x(it_, 5)));
  g1(15,21)=1-x(it_, 5);
  g1(15,33)=y(7)-x(it_, 13)-(y(21)-y(19));
  g1(15,41)=(-x(it_, 5));
  g1(16,8)=x(it_, 6);
  g1(16,19)=(-(1-x(it_, 6)));
  g1(16,22)=1-x(it_, 6);
  g1(16,34)=y(8)-x(it_, 14)-(y(22)-y(19));
  g1(16,42)=(-x(it_, 6));
  g1(17,9)=x(it_, 7);
  g1(17,23)=1-x(it_, 7);
  g1(17,24)=1-x(it_, 7);
  g1(17,35)=y(9)-x(it_, 15)-(y(23)+y(24));
  g1(17,43)=(-x(it_, 7));
  g1(18,10)=x(it_, 8)+(1-x(it_, 8))*(y(21)*(-(2*params(10)))+y(22)*(-(2*params(16)))+y(23)*(-(2*params(20))));
  g1(18,21)=(1-x(it_, 8))*(-(params(9)+y(10)*2*params(10)));
  g1(18,22)=(1-x(it_, 8))*(-(params(15)+y(10)*2*params(16)));
  g1(18,23)=(1-x(it_, 8))*(-(params(19)+y(10)*2*params(20)));
  g1(18,36)=y(10)-x(it_, 16)-(y(21)*(-(params(9)+y(10)*2*params(10)))+y(22)*(-(params(15)+y(10)*2*params(16)))+y(23)*(-(params(19)+y(10)*2*params(20))));
  g1(18,44)=(-x(it_, 8));
  g1(19,11)=x(it_, 9);
  g1(19,18)=1-x(it_, 9);
  g1(19,20)=1-x(it_, 9);
  g1(19,37)=y(11)-x(it_, 17)-(y(18)+y(20));
  g1(19,45)=(-x(it_, 9));
  g1(20,12)=x(it_, 10);
  g1(20,17)=1-x(it_, 10);
  g1(20,18)=(1-x(it_, 10))*(-(1-(y(12)>x(it_, 1)+10)));
  g1(20,38)=y(12)-x(it_, 18)-(y(17)+y(18)*(-(1-(y(12)>x(it_, 1)+10))));
  g1(20,46)=(-x(it_, 10));
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],20,2116);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],20,97336);
end
end
