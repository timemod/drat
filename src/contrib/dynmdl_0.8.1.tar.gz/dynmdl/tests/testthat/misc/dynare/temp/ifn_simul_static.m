function [residual, g1, g2] = ifn_simul_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                     columns: variables in declaration order
%                                                     rows: equations in order of declaration
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: variables in declaration order
%                                                       rows: equations in order of declaration
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 39, 1);

%
% Model equations
%

T126 = y(5)*(1-params(1))*y(23)+y(24)*y(3)*y(3)*y(5)*(1-x(1))*y(20)+(1-x(1))*y(20)*y(26)+y(5)*params(1)*(y(21)+y(22));
T220 = params(5)*y(14)^(-params(2))+params(6)*y(4)^(-params(2));
T229 = (y(11)/y(31))^(-params(12));
T250 = (y(12)/y(35))^((-1)/params(12));
T256 = (y(11)*params(8)*params(5))^(-params(3));
T311 = getPowerDeriv(T220,(-1)/params(2),1);
T316 = getPowerDeriv(y(12)/y(4),1+params(2),1);
T354 = getPowerDeriv(y(11)/y(31),(-params(12)),1);
T379 = getPowerDeriv(y(12)/y(14),1+params(2),1);
T384 = getPowerDeriv(y(12)/y(35),(-1)/params(12),1);
T453 = (y(21)*y(25)-y(22))/((1-x(1))*y(20))>x(2);
lhs =y(1);
rhs =params(1)+(1-params(9))*(y(2)-params(1))+y(3)*y(4)/y(4)-y(3)*y(5)/y(5)-y(6);
residual(1)= lhs-rhs;
lhs =y(7);
rhs =max(y(1),0);
residual(2)= lhs-rhs;
lhs =y(8);
rhs =(-min(y(1),0));
residual(3)= lhs-rhs;
lhs =y(9);
rhs =y(7)+params(9)*(y(2)-params(1));
residual(4)= lhs-rhs;
lhs =y(10);
rhs =y(11)*y(12)/(y(4)*y(5))-y(13)*y(14)/(y(4)*y(5))-y(6)*y(6)*.5*params(7);
residual(5)= lhs-rhs;
lhs =y(2);
rhs =params(1)+(1-x(1))*(y(10)-y(5)*y(3)*y(15)/y(5)-params(1));
residual(6)= lhs-rhs;
lhs =y(16);
rhs =y(4)*(y(6)+y(3)*y(5)/y(5)+(y(2)-params(1))*(-(1-params(9)))-params(1))/y(4);
residual(7)= lhs-rhs;
lhs =y(3);
rhs =min(y(17),max(y(16),y(18)));
residual(8)= lhs-rhs;
lhs =y(4);
rhs =y(4)*(1-params(1))+y(19);
residual(9)= lhs-rhs;
lhs =y(20);
rhs =y(21)+(1-params(9))*y(22);
residual(10)= lhs-rhs;
lhs =y(6);
rhs =(y(23)-y(21)-y(22))/(y(20)*params(7)*(1-x(1)));
residual(11)= lhs-rhs;
lhs =y(19);
rhs =y(4)*y(6);
residual(12)= lhs-rhs;
lhs =y(22);
rhs =(y(21)+y(22)+(1-x(1))*y(20)*(y(15)+y(3)*y(24)))/(1+y(25))-y(21);
residual(13)= lhs-rhs;
lhs =y(23);
rhs =T126/(y(5)*(1+y(25)));
residual(14)= lhs-rhs;
lhs =y(15);
rhs =x(2)+y(3)*params(10)+y(3)*y(3)*params(11);
residual(15)= lhs-rhs;
lhs =y(24);
rhs =params(10)+y(3)*2*params(11);
residual(16)= lhs-rhs;
lhs =y(18);
rhs =(params(10)*(-2)+(params(10)*params(10)*4+params(11)*12*(y(27)-x(2)))^.5)/(params(11)*6);
residual(17)= lhs-rhs;
lhs =y(17);
rhs =(params(10)*(-2)+(params(10)*params(10)*4+params(11)*12*(y(28)-x(2)))^.5)/(params(11)*6);
residual(18)= lhs-rhs;
lhs =y(25);
rhs =y(21)*x(2)+x(3);
residual(19)= lhs-rhs;
lhs =y(29);
rhs =(y(21)+y(22))*y(25)/((1-x(1))*y(20));
residual(20)= lhs-rhs;
lhs =y(27);
rhs =max((y(21)*y(25)-y(22))/((1-x(1))*y(20)),x(2));
residual(21)= lhs-rhs;
lhs =y(28);
rhs =(1+y(25)-y(21)-y(22))/((1-x(1))*y(20));
residual(22)= lhs-rhs;
lhs =y(21);
rhs =1-x(4);
residual(23)= lhs-rhs;
lhs =y(26);
rhs =y(11)*params(8)*y(30)+y(6)*y(6)*y(5)*.5*params(7)-params(1)*y(5);
residual(24)= lhs-rhs;
lhs =y(31);
rhs =y(31)*(1+x(5));
residual(25)= lhs-rhs;
lhs =y(5);
rhs =y(5)*(1+x(5));
residual(26)= lhs-rhs;
lhs =y(13);
rhs =y(13)*(1+x(5));
residual(27)= lhs-rhs;
lhs =y(32);
rhs =y(31)*(1+x(5));
residual(28)= lhs-rhs;
lhs =y(33);
rhs =y(13)*(1+x(5));
residual(29)= lhs-rhs;
lhs =y(12);
rhs =T220^((-1)/params(2));
residual(30)= lhs-rhs;
lhs =y(34);
rhs =y(35)*T229;
residual(31)= lhs-rhs;
lhs =y(35);
rhs =y(35)*(1+x(6));
residual(32)= lhs-rhs;
lhs =y(36);
rhs =y(35)*(1+x(6));
residual(33)= lhs-rhs;
lhs =y(30);
rhs =params(6)*(y(12)/y(4))^(1+params(2));
residual(34)= lhs-rhs;
lhs =y(37);
rhs =params(5)*(y(12)/y(14))^(1+params(2));
residual(35)= lhs-rhs;
lhs =y(11);
rhs =y(31)*T250;
residual(36)= lhs-rhs;
lhs =y(14);
rhs =y(12)*y(13)/T256;
residual(37)= lhs-rhs;
lhs =y(38);
rhs =y(3)*y(15)+y(29)*(1-y(3));
residual(38)= lhs-rhs;
lhs =y(39);
rhs =y(13)*y(14)/(y(11)*y(12));
residual(39)= lhs-rhs;
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(39, 39);

  %
  % Jacobian matrix
  %

  g1(1,1)=1;
  g1(1,2)=(-(1-params(9)));
  g1(1,6)=1;
  g1(2,1)=(-(y(1)>0));
  g1(2,7)=1;
  g1(3,1)=0>y(1);
  g1(3,8)=1;
  g1(4,2)=(-params(9));
  g1(4,7)=(-1);
  g1(4,9)=1;
  g1(5,4)=(-((-(y(5)*y(11)*y(12)))/(y(4)*y(5)*y(4)*y(5))-(-(y(5)*y(13)*y(14)))/(y(4)*y(5)*y(4)*y(5))));
  g1(5,5)=(-((-(y(4)*y(11)*y(12)))/(y(4)*y(5)*y(4)*y(5))-(-(y(4)*y(13)*y(14)))/(y(4)*y(5)*y(4)*y(5))));
  g1(5,6)=y(6)*.5*params(7)+y(6)*.5*params(7);
  g1(5,10)=1;
  g1(5,11)=(-(y(12)/(y(4)*y(5))));
  g1(5,12)=(-(y(11)/(y(4)*y(5))));
  g1(5,13)=y(14)/(y(4)*y(5));
  g1(5,14)=y(13)/(y(4)*y(5));
  g1(6,2)=1;
  g1(6,3)=(-((1-x(1))*(-(y(5)*y(15)/y(5)))));
  g1(6,10)=(-(1-x(1)));
  g1(6,15)=(-((1-x(1))*(-(y(3)*y(5)/y(5)))));
  g1(7,2)=(-(y(4)*(-(1-params(9)))/y(4)));
  g1(7,3)=(-1);
  g1(7,6)=(-1);
  g1(7,16)=1;
  g1(8,3)=1;
  g1(8,16)=(-((y(16)>y(18))*(1-(max(y(16),y(18))>y(17)))));
  g1(8,17)=(-(max(y(16),y(18))>y(17)));
  g1(8,18)=(-((1-(y(16)>y(18)))*(1-(max(y(16),y(18))>y(17)))));
  g1(9,4)=1-(1-params(1));
  g1(9,19)=(-1);
  g1(10,20)=1;
  g1(10,21)=(-1);
  g1(10,22)=(-(1-params(9)));
  g1(11,6)=1;
  g1(11,20)=(-((-((y(23)-y(21)-y(22))*params(7)*(1-x(1))))/(y(20)*params(7)*(1-x(1))*y(20)*params(7)*(1-x(1)))));
  g1(11,21)=(-((-1)/(y(20)*params(7)*(1-x(1)))));
  g1(11,22)=(-((-1)/(y(20)*params(7)*(1-x(1)))));
  g1(11,23)=(-(1/(y(20)*params(7)*(1-x(1)))));
  g1(12,4)=(-y(6));
  g1(12,6)=(-y(4));
  g1(12,19)=1;
  g1(13,3)=(-((1-x(1))*y(20)*y(24)/(1+y(25))));
  g1(13,15)=(-((1-x(1))*y(20)/(1+y(25))));
  g1(13,20)=(-((1-x(1))*(y(15)+y(3)*y(24))/(1+y(25))));
  g1(13,21)=(-(1/(1+y(25))-1));
  g1(13,22)=1-1/(1+y(25));
  g1(13,24)=(-(y(3)*(1-x(1))*y(20)/(1+y(25))));
  g1(13,25)=(-((-(y(21)+y(22)+(1-x(1))*y(20)*(y(15)+y(3)*y(24))))/((1+y(25))*(1+y(25)))));
  g1(14,3)=(-(y(24)*(y(3)*y(5)*(1-x(1))*y(20)+y(3)*y(5)*(1-x(1))*y(20))/(y(5)*(1+y(25)))));
  g1(14,5)=(-((y(5)*(1+y(25))*(params(1)*(y(21)+y(22))+(1-params(1))*y(23)+y(24)*y(3)*y(3)*(1-x(1))*y(20))-(1+y(25))*T126)/(y(5)*(1+y(25))*y(5)*(1+y(25)))));
  g1(14,20)=(-((y(24)*y(3)*y(3)*y(5)*(1-x(1))+(1-x(1))*y(26))/(y(5)*(1+y(25)))));
  g1(14,21)=(-(params(1)*y(5)/(y(5)*(1+y(25)))));
  g1(14,22)=(-(params(1)*y(5)/(y(5)*(1+y(25)))));
  g1(14,23)=1-y(5)*(1-params(1))/(y(5)*(1+y(25)));
  g1(14,24)=(-(y(3)*y(3)*y(5)*(1-x(1))*y(20)/(y(5)*(1+y(25)))));
  g1(14,25)=(-((-(y(5)*T126))/(y(5)*(1+y(25))*y(5)*(1+y(25)))));
  g1(14,26)=(-((1-x(1))*y(20)/(y(5)*(1+y(25)))));
  g1(15,3)=(-(params(10)+y(3)*params(11)+y(3)*params(11)));
  g1(15,15)=1;
  g1(16,3)=(-(2*params(11)));
  g1(16,24)=1;
  g1(17,18)=1;
  g1(17,27)=(-(params(11)*12*.5*(params(10)*params(10)*4+params(11)*12*(y(27)-x(2)))^(-0.5)/(params(11)*6)));
  g1(18,17)=1;
  g1(18,28)=(-(params(11)*12*.5*(params(10)*params(10)*4+params(11)*12*(y(28)-x(2)))^(-0.5)/(params(11)*6)));
  g1(19,21)=(-x(2));
  g1(19,25)=1;
  g1(20,20)=(-((-((1-x(1))*(y(21)+y(22))*y(25)))/((1-x(1))*y(20)*(1-x(1))*y(20))));
  g1(20,21)=(-(y(25)/((1-x(1))*y(20))));
  g1(20,22)=(-(y(25)/((1-x(1))*y(20))));
  g1(20,25)=(-((y(21)+y(22))/((1-x(1))*y(20))));
  g1(20,29)=1;
  g1(21,20)=(-((-((1-x(1))*(y(21)*y(25)-y(22))))/((1-x(1))*y(20)*(1-x(1))*y(20))*T453));
  g1(21,21)=(-(T453*y(25)/((1-x(1))*y(20))));
  g1(21,22)=(-(T453*(-1)/((1-x(1))*y(20))));
  g1(21,25)=(-(T453*y(21)/((1-x(1))*y(20))));
  g1(21,27)=1;
  g1(22,20)=(-((-((1-x(1))*(1+y(25)-y(21)-y(22))))/((1-x(1))*y(20)*(1-x(1))*y(20))));
  g1(22,21)=(-((-1)/((1-x(1))*y(20))));
  g1(22,22)=(-((-1)/((1-x(1))*y(20))));
  g1(22,25)=(-(1/((1-x(1))*y(20))));
  g1(22,28)=1;
  g1(23,21)=1;
  g1(24,5)=(-(y(6)*y(6)*.5*params(7)-params(1)));
  g1(24,6)=(-(y(6)*y(5)*.5*params(7)+y(6)*y(5)*.5*params(7)));
  g1(24,11)=(-(params(8)*y(30)));
  g1(24,26)=1;
  g1(24,30)=(-(y(11)*params(8)));
  g1(25,31)=1-(1+x(5));
  g1(26,5)=1-(1+x(5));
  g1(27,13)=1-(1+x(5));
  g1(28,31)=(-(1+x(5)));
  g1(28,32)=1;
  g1(29,13)=(-(1+x(5)));
  g1(29,33)=1;
  g1(30,4)=(-(params(6)*getPowerDeriv(y(4),(-params(2)),1)*T311));
  g1(30,12)=1;
  g1(30,14)=(-(T311*params(5)*getPowerDeriv(y(14),(-params(2)),1)));
  g1(31,11)=(-(y(35)*1/y(31)*T354));
  g1(31,31)=(-(y(35)*T354*(-y(11))/(y(31)*y(31))));
  g1(31,34)=1;
  g1(31,35)=(-T229);
  g1(32,35)=1-(1+x(6));
  g1(33,35)=(-(1+x(6)));
  g1(33,36)=1;
  g1(34,4)=(-(params(6)*(-y(12))/(y(4)*y(4))*T316));
  g1(34,12)=(-(params(6)*T316*1/y(4)));
  g1(34,30)=1;
  g1(35,12)=(-(params(5)*1/y(14)*T379));
  g1(35,14)=(-(params(5)*T379*(-y(12))/(y(14)*y(14))));
  g1(35,37)=1;
  g1(36,11)=1;
  g1(36,12)=(-(y(31)*1/y(35)*T384));
  g1(36,31)=(-T250);
  g1(36,35)=(-(y(31)*T384*(-y(12))/(y(35)*y(35))));
  g1(37,11)=(-(y(12)*(-(y(13)*params(8)*params(5)*getPowerDeriv(y(11)*params(8)*params(5),(-params(3)),1)))/(T256*T256)));
  g1(37,12)=(-(y(13)/T256));
  g1(37,13)=(-(y(12)*1/T256));
  g1(37,14)=1;
  g1(38,3)=(-(y(15)-y(29)));
  g1(38,15)=(-y(3));
  g1(38,29)=(-(1-y(3)));
  g1(38,38)=1;
  g1(39,11)=(-((-(y(12)*y(13)*y(14)))/(y(11)*y(12)*y(11)*y(12))));
  g1(39,12)=(-((-(y(11)*y(13)*y(14)))/(y(11)*y(12)*y(11)*y(12))));
  g1(39,13)=(-(y(14)/(y(11)*y(12))));
  g1(39,14)=(-(y(13)/(y(11)*y(12))));
  g1(39,39)=1;
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],39,1521);
end
end
