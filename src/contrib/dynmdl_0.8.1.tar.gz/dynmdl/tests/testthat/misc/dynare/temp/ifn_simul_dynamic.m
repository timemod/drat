function [residual, g1, g2, g3] = ifn_simul_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           rows: equations in order of declaration
%                                                           columns: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(39, 1);
T136 = (1-params(1))*y(50)*y(47)+y(31)*y(10)*y(10)*y(12)*(1-x(it_+1, 1))*y(48)+(1-x(it_+1, 1))*y(48)*y(52)+y(47)*params(1)*(y(28)+y(49));
T242 = params(5)*y(21)^(-params(2))+params(6)*y(2)^(-params(2));
T251 = (y(18)/y(38))^(-params(12));
T276 = (y(19)/y(42))^((-1)/params(12));
T282 = (y(18)*params(8)*params(5))^(-params(3));
T350 = getPowerDeriv(T242,(-1)/params(2),1);
T355 = getPowerDeriv(y(19)/y(2),1+params(2),1);
T422 = getPowerDeriv(y(18)/y(38),(-params(12)),1);
T447 = getPowerDeriv(y(19)/y(21),1+params(2),1);
T452 = getPowerDeriv(y(19)/y(42),(-1)/params(12),1);
T525 = (y(28)*y(51)-y(49))/((1-x(it_+1, 1))*y(48))>x(it_, 2);
T547 = (-((-1)/((1-x(it_+1, 1))*y(48))));
T582 = .5*(params(10)*params(10)*4+params(11)*12*(y(34)-x(it_, 2)))^(-0.5);
T587 = .5*(params(10)*params(10)*4+params(11)*12*(y(35)-x(it_, 2)))^(-0.5);
lhs =y(8);
rhs =params(1)+(1-params(9))*(y(9)-params(1))+y(10)*y(11)/y(2)-y(1)*y(3)/y(12)-y(13);
residual(1)= lhs-rhs;
lhs =y(14);
rhs =max(y(8),0);
residual(2)= lhs-rhs;
lhs =y(15);
rhs =(-min(y(8),0));
residual(3)= lhs-rhs;
lhs =y(16);
rhs =y(14)+params(9)*(y(9)-params(1));
residual(4)= lhs-rhs;
lhs =y(17);
rhs =y(18)*y(19)/(y(2)*y(12))-y(20)*y(21)/(y(2)*y(12))-y(13)*y(13)*.5*params(7);
residual(5)= lhs-rhs;
lhs =y(9);
rhs =params(1)+(1-x(it_, 1))*(y(17)-y(3)*y(1)*y(5)/y(12)-params(1));
residual(6)= lhs-rhs;
lhs =y(23);
rhs =y(2)*(y(13)+y(1)*y(3)/y(12)+(y(9)-params(1))*(-(1-params(9)))-params(1))/y(11);
residual(7)= lhs-rhs;
lhs =y(10);
rhs =min(y(24),max(y(23),y(25)));
residual(8)= lhs-rhs;
lhs =y(11);
rhs =y(2)*(1-params(1))+y(26);
residual(9)= lhs-rhs;
lhs =y(27);
rhs =y(28)+(1-params(9))*y(29);
residual(10)= lhs-rhs;
lhs =y(13);
rhs =(y(30)-y(28)-y(29))/(y(27)*params(7)*(1-x(it_, 1)));
residual(11)= lhs-rhs;
lhs =y(26);
rhs =y(2)*y(13);
residual(12)= lhs-rhs;
lhs =y(29);
rhs =(y(28)+y(49)+(1-x(it_+1, 1))*y(48)*(y(22)+y(10)*y(31)))/(1+y(51))-y(28);
residual(13)= lhs-rhs;
lhs =y(30);
rhs =T136/(y(12)*(1+y(51)));
residual(14)= lhs-rhs;
lhs =y(22);
rhs =x(it_, 2)+y(10)*params(10)+y(10)*y(10)*params(11);
residual(15)= lhs-rhs;
lhs =y(31);
rhs =params(10)+y(10)*2*params(11);
residual(16)= lhs-rhs;
lhs =y(25);
rhs =(params(10)*(-2)+(params(10)*params(10)*4+params(11)*12*(y(34)-x(it_, 2)))^.5)/(params(11)*6);
residual(17)= lhs-rhs;
lhs =y(24);
rhs =(params(10)*(-2)+(params(10)*params(10)*4+params(11)*12*(y(35)-x(it_, 2)))^.5)/(params(11)*6);
residual(18)= lhs-rhs;
lhs =y(32);
rhs =y(28)*x(it_, 2)+x(it_, 3);
residual(19)= lhs-rhs;
lhs =y(36);
rhs =y(51)*(y(28)+y(29))/((1-x(it_+1, 1))*y(48))+(y(29)-y(49))/((1-x(it_+1, 1))*y(48));
residual(20)= lhs-rhs;
lhs =y(34);
rhs =max((y(28)*y(51)-y(49))/((1-x(it_+1, 1))*y(48)),x(it_, 2));
residual(21)= lhs-rhs;
lhs =y(35);
rhs =(1+y(51)-y(28)-y(49))/((1-x(it_+1, 1))*y(48));
residual(22)= lhs-rhs;
lhs =y(28);
rhs =1-x(it_, 4);
residual(23)= lhs-rhs;
lhs =y(33);
rhs =y(18)*params(8)*y(37)+y(13)*y(13)*y(12)*.5*params(7)-params(1)*y(12);
residual(24)= lhs-rhs;
lhs =y(38);
rhs =(1+x(it_, 5))*y(6);
residual(25)= lhs-rhs;
lhs =y(12);
rhs =y(3)*(1+x(it_, 5));
residual(26)= lhs-rhs;
lhs =y(20);
rhs =(1+x(it_, 5))*y(4);
residual(27)= lhs-rhs;
lhs =y(39);
rhs =y(38)*(1+x(it_+1, 5));
residual(28)= lhs-rhs;
lhs =y(40);
rhs =y(20)*(1+x(it_+1, 5));
residual(29)= lhs-rhs;
lhs =y(19);
rhs =T242^((-1)/params(2));
residual(30)= lhs-rhs;
lhs =y(41);
rhs =y(42)*T251;
residual(31)= lhs-rhs;
lhs =y(42);
rhs =y(7)*(1+x(it_, 6));
residual(32)= lhs-rhs;
lhs =y(43);
rhs =y(42)*(1+x(it_+1, 6));
residual(33)= lhs-rhs;
lhs =y(37);
rhs =params(6)*(y(19)/y(2))^(1+params(2));
residual(34)= lhs-rhs;
lhs =y(44);
rhs =params(5)*(y(19)/y(21))^(1+params(2));
residual(35)= lhs-rhs;
lhs =y(18);
rhs =y(38)*T276;
residual(36)= lhs-rhs;
lhs =y(21);
rhs =y(19)*y(20)/T282;
residual(37)= lhs-rhs;
lhs =y(45);
rhs =y(10)*y(22)+y(36)*(1-y(10));
residual(38)= lhs-rhs;
lhs =y(46);
rhs =y(20)*y(21)/(y(18)*y(19));
residual(39)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(39, 58);

  %
  % Jacobian matrix
  %

  g1(1,8)=1;
  g1(1,9)=(-(1-params(9)));
  g1(1,1)=y(3)/y(12);
  g1(1,10)=(-(y(11)/y(2)));
  g1(1,2)=(-((-(y(10)*y(11)))/(y(2)*y(2))));
  g1(1,11)=(-(y(10)/y(2)));
  g1(1,3)=y(1)/y(12);
  g1(1,12)=(-(y(1)*y(3)))/(y(12)*y(12));
  g1(1,13)=1;
  g1(2,8)=(-(y(8)>0));
  g1(2,14)=1;
  g1(3,8)=0>y(8);
  g1(3,15)=1;
  g1(4,9)=(-params(9));
  g1(4,14)=(-1);
  g1(4,16)=1;
  g1(5,2)=(-((-(y(12)*y(18)*y(19)))/(y(2)*y(12)*y(2)*y(12))-(-(y(12)*y(20)*y(21)))/(y(2)*y(12)*y(2)*y(12))));
  g1(5,12)=(-((-(y(2)*y(18)*y(19)))/(y(2)*y(12)*y(2)*y(12))-(-(y(2)*y(20)*y(21)))/(y(2)*y(12)*y(2)*y(12))));
  g1(5,13)=y(13)*.5*params(7)+y(13)*.5*params(7);
  g1(5,17)=1;
  g1(5,18)=(-(y(19)/(y(2)*y(12))));
  g1(5,19)=(-(y(18)/(y(2)*y(12))));
  g1(5,20)=y(21)/(y(2)*y(12));
  g1(5,21)=y(20)/(y(2)*y(12));
  g1(6,9)=1;
  g1(6,1)=(-((1-x(it_, 1))*(-(y(3)*y(5)/y(12)))));
  g1(6,3)=(-((1-x(it_, 1))*(-(y(1)*y(5)/y(12)))));
  g1(6,12)=(-((1-x(it_, 1))*(-((-(y(3)*y(1)*y(5)))/(y(12)*y(12))))));
  g1(6,17)=(-(1-x(it_, 1)));
  g1(6,5)=(-((1-x(it_, 1))*(-(y(1)*y(3)/y(12)))));
  g1(6,53)=y(17)-y(3)*y(1)*y(5)/y(12)-params(1);
  g1(7,9)=(-(y(2)*(-(1-params(9)))/y(11)));
  g1(7,1)=(-(y(2)*y(3)/y(12)/y(11)));
  g1(7,2)=(-((y(13)+y(1)*y(3)/y(12)+(y(9)-params(1))*(-(1-params(9)))-params(1))/y(11)));
  g1(7,11)=(-((-(y(2)*(y(13)+y(1)*y(3)/y(12)+(y(9)-params(1))*(-(1-params(9)))-params(1))))/(y(11)*y(11))));
  g1(7,3)=(-(y(2)*y(1)/y(12)/y(11)));
  g1(7,12)=(-(y(2)*(-(y(1)*y(3)))/(y(12)*y(12))/y(11)));
  g1(7,13)=(-(y(2)/y(11)));
  g1(7,23)=1;
  g1(8,10)=1;
  g1(8,23)=(-((y(23)>y(25))*(1-(max(y(23),y(25))>y(24)))));
  g1(8,24)=(-(max(y(23),y(25))>y(24)));
  g1(8,25)=(-((1-(y(23)>y(25)))*(1-(max(y(23),y(25))>y(24)))));
  g1(9,2)=(-(1-params(1)));
  g1(9,11)=1;
  g1(9,26)=(-1);
  g1(10,27)=1;
  g1(10,28)=(-1);
  g1(10,29)=(-(1-params(9)));
  g1(11,13)=1;
  g1(11,27)=(-((-((y(30)-y(28)-y(29))*params(7)*(1-x(it_, 1))))/(y(27)*params(7)*(1-x(it_, 1))*y(27)*params(7)*(1-x(it_, 1)))));
  g1(11,28)=(-((-1)/(y(27)*params(7)*(1-x(it_, 1)))));
  g1(11,29)=(-((-1)/(y(27)*params(7)*(1-x(it_, 1)))));
  g1(11,30)=(-(1/(y(27)*params(7)*(1-x(it_, 1)))));
  g1(11,53)=(-((-((y(30)-y(28)-y(29))*y(27)*(-params(7))))/(y(27)*params(7)*(1-x(it_, 1))*y(27)*params(7)*(1-x(it_, 1)))));
  g1(12,2)=(-y(13));
  g1(12,13)=(-y(2));
  g1(12,26)=1;
  g1(13,10)=(-((1-x(it_+1, 1))*y(48)*y(31)/(1+y(51))));
  g1(13,22)=(-((1-x(it_+1, 1))*y(48)/(1+y(51))));
  g1(13,48)=(-((1-x(it_+1, 1))*(y(22)+y(10)*y(31))/(1+y(51))));
  g1(13,28)=(-(1/(1+y(51))-1));
  g1(13,29)=1;
  g1(13,49)=(-(1/(1+y(51))));
  g1(13,31)=(-(y(10)*(1-x(it_+1, 1))*y(48)/(1+y(51))));
  g1(13,51)=(-((-(y(28)+y(49)+(1-x(it_+1, 1))*y(48)*(y(22)+y(10)*y(31))))/((1+y(51))*(1+y(51)))));
  g1(13,53)=(-((y(22)+y(10)*y(31))*(-y(48))/(1+y(51))));
  g1(14,10)=(-(y(31)*(y(10)*y(12)*(1-x(it_+1, 1))*y(48)+y(10)*y(12)*(1-x(it_+1, 1))*y(48))/(y(12)*(1+y(51)))));
  g1(14,12)=(-((y(12)*(1+y(51))*y(31)*y(10)*y(10)*(1-x(it_+1, 1))*y(48)-(1+y(51))*T136)/(y(12)*(1+y(51))*y(12)*(1+y(51)))));
  g1(14,47)=(-(((1-params(1))*y(50)+params(1)*(y(28)+y(49)))/(y(12)*(1+y(51)))));
  g1(14,48)=(-((y(31)*y(10)*y(10)*y(12)*(1-x(it_+1, 1))+(1-x(it_+1, 1))*y(52))/(y(12)*(1+y(51)))));
  g1(14,28)=(-(params(1)*y(47)/(y(12)*(1+y(51)))));
  g1(14,49)=(-(params(1)*y(47)/(y(12)*(1+y(51)))));
  g1(14,30)=1;
  g1(14,50)=(-((1-params(1))*y(47)/(y(12)*(1+y(51)))));
  g1(14,31)=(-(y(10)*y(10)*y(12)*(1-x(it_+1, 1))*y(48)/(y(12)*(1+y(51)))));
  g1(14,51)=(-((-(y(12)*T136))/(y(12)*(1+y(51))*y(12)*(1+y(51)))));
  g1(14,52)=(-((1-x(it_+1, 1))*y(48)/(y(12)*(1+y(51)))));
  g1(14,53)=(-((y(31)*y(10)*y(10)*y(12)*(-y(48))+y(52)*(-y(48)))/(y(12)*(1+y(51)))));
  g1(15,10)=(-(params(10)+y(10)*params(11)+y(10)*params(11)));
  g1(15,22)=1;
  g1(15,54)=(-1);
  g1(16,10)=(-(2*params(11)));
  g1(16,31)=1;
  g1(17,25)=1;
  g1(17,34)=(-(params(11)*12*T582/(params(11)*6)));
  g1(17,54)=(-(T582*(-(params(11)*12))/(params(11)*6)));
  g1(18,24)=1;
  g1(18,35)=(-(params(11)*12*T587/(params(11)*6)));
  g1(18,54)=(-(T587*(-(params(11)*12))/(params(11)*6)));
  g1(19,28)=(-x(it_, 2));
  g1(19,32)=1;
  g1(19,54)=(-y(28));
  g1(19,55)=(-1);
  g1(20,48)=(-((-((1-x(it_+1, 1))*y(51)*(y(28)+y(29))))/((1-x(it_+1, 1))*y(48)*(1-x(it_+1, 1))*y(48))+(-((1-x(it_+1, 1))*(y(29)-y(49))))/((1-x(it_+1, 1))*y(48)*(1-x(it_+1, 1))*y(48))));
  g1(20,28)=(-(y(51)/((1-x(it_+1, 1))*y(48))));
  g1(20,29)=(-(y(51)/((1-x(it_+1, 1))*y(48))+1/((1-x(it_+1, 1))*y(48))));
  g1(20,49)=T547;
  g1(20,51)=(-((y(28)+y(29))/((1-x(it_+1, 1))*y(48))));
  g1(20,36)=1;
  g1(20,53)=(-((-(y(51)*(y(28)+y(29))*(-y(48))))/((1-x(it_+1, 1))*y(48)*(1-x(it_+1, 1))*y(48))+(-((y(29)-y(49))*(-y(48))))/((1-x(it_+1, 1))*y(48)*(1-x(it_+1, 1))*y(48))));
  g1(21,48)=(-((-((1-x(it_+1, 1))*(y(28)*y(51)-y(49))))/((1-x(it_+1, 1))*y(48)*(1-x(it_+1, 1))*y(48))*T525));
  g1(21,28)=(-(T525*y(51)/((1-x(it_+1, 1))*y(48))));
  g1(21,49)=(-(T525*(-1)/((1-x(it_+1, 1))*y(48))));
  g1(21,51)=(-(T525*y(28)/((1-x(it_+1, 1))*y(48))));
  g1(21,34)=1;
  g1(21,53)=(-(T525*(-((y(28)*y(51)-y(49))*(-y(48))))/((1-x(it_+1, 1))*y(48)*(1-x(it_+1, 1))*y(48))));
  g1(21,54)=(-(1-T525));
  g1(22,48)=(-((-((1-x(it_+1, 1))*(1+y(51)-y(28)-y(49))))/((1-x(it_+1, 1))*y(48)*(1-x(it_+1, 1))*y(48))));
  g1(22,28)=T547;
  g1(22,49)=T547;
  g1(22,51)=(-(1/((1-x(it_+1, 1))*y(48))));
  g1(22,35)=1;
  g1(22,53)=(-((-((1+y(51)-y(28)-y(49))*(-y(48))))/((1-x(it_+1, 1))*y(48)*(1-x(it_+1, 1))*y(48))));
  g1(23,28)=1;
  g1(23,56)=1;
  g1(24,12)=(-(y(13)*y(13)*.5*params(7)-params(1)));
  g1(24,13)=(-(y(13)*y(12)*.5*params(7)+y(13)*y(12)*.5*params(7)));
  g1(24,18)=(-(params(8)*y(37)));
  g1(24,33)=1;
  g1(24,37)=(-(y(18)*params(8)));
  g1(25,6)=(-(1+x(it_, 5)));
  g1(25,38)=1;
  g1(25,57)=(-y(6));
  g1(26,3)=(-(1+x(it_, 5)));
  g1(26,12)=1;
  g1(26,57)=(-y(3));
  g1(27,4)=(-(1+x(it_, 5)));
  g1(27,20)=1;
  g1(27,57)=(-y(4));
  g1(28,38)=(-(1+x(it_+1, 5)));
  g1(28,39)=1;
  g1(28,57)=(-y(38));
  g1(29,20)=(-(1+x(it_+1, 5)));
  g1(29,40)=1;
  g1(29,57)=(-y(20));
  g1(30,2)=(-(params(6)*getPowerDeriv(y(2),(-params(2)),1)*T350));
  g1(30,19)=1;
  g1(30,21)=(-(T350*params(5)*getPowerDeriv(y(21),(-params(2)),1)));
  g1(31,18)=(-(y(42)*1/y(38)*T422));
  g1(31,38)=(-(y(42)*T422*(-y(18))/(y(38)*y(38))));
  g1(31,41)=1;
  g1(31,42)=(-T251);
  g1(32,7)=(-(1+x(it_, 6)));
  g1(32,42)=1;
  g1(32,58)=(-y(7));
  g1(33,42)=(-(1+x(it_+1, 6)));
  g1(33,43)=1;
  g1(33,58)=(-y(42));
  g1(34,2)=(-(params(6)*(-y(19))/(y(2)*y(2))*T355));
  g1(34,19)=(-(params(6)*T355*1/y(2)));
  g1(34,37)=1;
  g1(35,19)=(-(params(5)*1/y(21)*T447));
  g1(35,21)=(-(params(5)*T447*(-y(19))/(y(21)*y(21))));
  g1(35,44)=1;
  g1(36,18)=1;
  g1(36,19)=(-(y(38)*1/y(42)*T452));
  g1(36,38)=(-T276);
  g1(36,42)=(-(y(38)*T452*(-y(19))/(y(42)*y(42))));
  g1(37,18)=(-(y(19)*(-(y(20)*params(8)*params(5)*getPowerDeriv(y(18)*params(8)*params(5),(-params(3)),1)))/(T282*T282)));
  g1(37,19)=(-(y(20)/T282));
  g1(37,20)=(-(y(19)*1/T282));
  g1(37,21)=1;
  g1(38,10)=(-(y(22)-y(36)));
  g1(38,22)=(-y(10));
  g1(38,36)=(-(1-y(10)));
  g1(38,45)=1;
  g1(39,18)=(-((-(y(19)*y(20)*y(21)))/(y(18)*y(19)*y(18)*y(19))));
  g1(39,19)=(-((-(y(18)*y(20)*y(21)))/(y(18)*y(19)*y(18)*y(19))));
  g1(39,20)=(-(y(21)/(y(18)*y(19))));
  g1(39,21)=(-(y(20)/(y(18)*y(19))));
  g1(39,46)=1;
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],39,3364);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],39,195112);
end
end
