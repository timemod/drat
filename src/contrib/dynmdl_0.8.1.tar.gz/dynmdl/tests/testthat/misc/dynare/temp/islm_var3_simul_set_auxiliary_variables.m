function y = islm_var3_simul_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(8)=y(2);
y(9)=y(8);
y(10)=y(1);
y(11)=y(10);
y(12)=y(11);
