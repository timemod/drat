SEXP run_mcexec(SEXP filename, SEXP outputfile_, SEXP flags, 
                SEXP include_dirs, const Mcopt *mc_options);
