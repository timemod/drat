This directory contains the (LaTeX) sources used to build some
papers whose pdf files are in the parent directory.
