extend_path

dynare ifn_check noclearall

clean_dynare('ifn_check', 'temp', true)

