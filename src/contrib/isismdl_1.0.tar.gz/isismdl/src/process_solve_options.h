void process_solve_options(int *mws_index, int *use_mws, SEXP options);
