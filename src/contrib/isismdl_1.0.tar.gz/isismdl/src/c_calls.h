#define SET_DATA 1
#define SET_CA   2 
#define SET_FIX  3
#define SET_FIT  4
