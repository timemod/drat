.onUnload <- function(libpath) {
    library.dynam.unload("regts", libpath)
}
