extern void F77_SUB(init_get_options)(int *mws_index);
