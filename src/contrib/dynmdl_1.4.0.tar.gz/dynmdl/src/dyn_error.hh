void dyn_error(std::ostringstream &message);
void dyn_error(std::string message);
void dyn_warning(std::ostringstream &message);
void dyn_warning(std::string message);
