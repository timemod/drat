function y = square(x)
  y = x * x;
end
