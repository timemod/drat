library(dynmdl)
library(testthat)
rm(list = ls())
context("ISLM model with fit procedure")

source("../tools/read_dynare_result.R")

rds_file <- "islm_model_fit.rds"
model_name <- "islm_fit"

report <- capture_output(mdl <- read_mdl(rds_file))
mdl$set_param(c(sigma_ut = 7, sigma_uc = 5, sigma_ui = 21, sigma_umd = 2))

endo_names <- c("y", "yd", "c", "i", "md", "r", "t") 
inames <- c("ut", "uc", "umd", "ui")

mdl_old <- mdl$copy()

test_that("all.equal works correctly for fit models", {
  expect_true(isTRUE(all.equal(mdl, mdl_old)))
})

mdl$set_fit(regts(c(1250, 1255, 1260), start = "2016Q1"), names = "y")
mdl$set_fit(regts(c(250, 255), start = "2016Q1"), names = "t")

fit_targets <- mdl$get_fit()

test_that("all.equal works correctly for fit models", {
  expect_false(isTRUE(all.equal(mdl, mdl_old)))
})

mdl$solve(control = list(silent = TRUE))

dynare_result <- read_dynare_result(model_name, mdl)
dynare_endo <- update_ts_labels(dynare_result$endo, mdl$get_labels())

test_that("dynare result equal to islm result", {
  p <- mdl$get_period()
  expect_equal(dynare_endo, mdl$get_endo_data(period = p))
})


test_that("get_data", {
  p <- mdl$get_period()
  endo_data <- mdl$get_endo_data()
  exo_data <- mdl$get_exo_data()
  expect_identical(colnames(exo_data), c("g", "ms"))
  all_data <- cbind(endo_data, exo_data)
  all_data <- all_data[, order(colnames(all_data))]

  expect_equal(mdl$get_data(), all_data)  
  expect_equal(mdl$get_data(names = "g", period = p), 
              all_data[p, "g", drop = FALSE])  
  
  expect_equal(mdl$get_data(names = "ms", pattern = "^y",
                             period = p), 
                all_data[p, c("ms", "y", "yd")])  
  
  # errors 
  expect_error(mdl$get_data(names = "ui"), "\"ui\" is not a model variable") 
  expect_error(mdl$get_exo_data(names = c("ui", "aap")), 
              "\"ui\", \"aap\" are no exogenous model variables")         
  
  expect_null(mdl$get_data(pattern = "^u"))
})


test_that("get_names", {
 
  expect_equal(mdl$get_endo_names(), endo_names)
  
  expect_equal(mdl$get_endo_names(type = "lag"), c("y", "yd"))
  expect_equal(mdl$get_endo_names(type = "lead"), c("y", "yd"))
  
  expect_equal(mdl$get_exo_names(), c("g", "ms"))
  
  par_names <- c(paste0("sigma_u", c("t", "c", "i", "md")),
                 paste0("c", 0:5), paste0("i", 0:5), paste0("m", 0:3),
                 paste0("t", 0:1))
  expect_equal(mdl$get_par_names(), par_names)
  
  
  expect_equal(mdl$get_sigma_names(), paste0("sigma_", inames))
})

test_that("start solution with correct lagrange multipliers", {
  l <- mdl$get_lagrange()
  inst <- mdl$get_fit_instruments()
  endo_data <- mdl$get_endo_data(period = mdl$get_period())
  
  mdl2 <- mdl_old$copy()
  mdl2$set_fit(fit_targets)
  expect_warning(
    expect_output(
      mdl2$solve(control = list(maxiter = 1)),
      "No convergence after 1 iterations"),
    "The maximum number of iterations \\(1\\) has been reached"
  )
  mdl2$set_data(cbind(endo_data, l, inst))
  expect_output(mdl2$solve(), "Convergence after 0 iterations")
})
