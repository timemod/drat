void run_macro_(char * modfile, std::string &modfile_expanded);
