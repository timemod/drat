/*
 * The k-th derivative of x^p
 */
double getPowerDeriv(double x, double p, int k);
