void process_solve_options(int *model_index, int *use_mws, SEXP options);
