SEXP set_fit_opts_c(SEXP model_index_, SEXP options);
