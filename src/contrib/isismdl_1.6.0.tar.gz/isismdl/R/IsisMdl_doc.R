#' \code{\link{IsisMdl}} method: returns the maximum lag of the model
#' @name get_maxlag
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the maximum
#' lag of the model
#'
#' @section Usage:
#' \preformatted{
#' mdl$get_maxlag()
#'
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
NULL

#' \code{\link{IsisMdl}} method: returns the maximum lead of the model
#' @name get_maxlead
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the maximum
#' lead of the model
#'
#' @section Usage:
#' \preformatted{
#' mdl$get_maxlead()
#'
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
NULL


#' \code{\link{IsisMdl}} method: returns the names of the endogenous model
#' variables
#' @name get_endo_names
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the names of
#' the endogenous model variables. By default, the function returns the
#' names of all active endogenous variables. Argument \code{pattern} can be
#' specified to select only variables with names matching a regular expression.
#' Argument \code{type}
#' can be specified to select variables with a specific type.
#' The following types are supported
#' \describe{
#' \item{\code{"frml"}}{stochastic variables.
#' Stochastic variables are variables that occur on the left hand side
#' of frml equations}
#' \item{\code{"endolead"}}{all variables with endogenous leads}
#' \item{\code{"all"}}{all endogenous variables, the default}
#' }
#'
#' If some equation have been deactivated (see \code{\link{set_eq_status}},
#' then argument \code{status} may be useful.
#' By default, the function only returns the names of the active
#' endogenous variables, i.e. the variables that occur on the
#' left hand side of active equation. This behaviour can be modified
#' by specifying the status\code{status}. The following options
#' for argument \code{status} are recognized:
#'\describe{
#' \item{\code{"active"}}{active endogenous variables, the default}
#' \item{\code{"inactive"}}{inactive endogenous variables}
#' \item{\code{"all"}}{all endogenous variables}
#' }
#'
#' @section Usage:
#' \preformatted{
#' mdl$get_endo_names(pattern = ".*",
#'                   type =  c("all", "frml", "endolead"),
#'                   status = c("active", "inactive", "all"))
#'
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{pattern}}{a regular expression specifying variable names}
#' \item{\code{type}}{a character string specifying the variable type. See
#' the description above}
#' \item{\code{status}}{a character string specifying the status of the
#' endogenous variable (inactive or active). See the description above}
#' }
#'
#' @seealso \code{\link{get_exo_names}} and \code{\link{get_var_names}}
#' @examples
#' mdl <- islm_mdl()
#'
#' # get the names of all stochastic variables
#' mdl$get_endo_names(type = "frml")
#'
#' # get all variables with names starting with "y":
#' mdl$get_endo_names(pattern = "^y.*")
NULL

#' \code{\link{IsisMdl}} method: Sets labels for the model variables.
#' @name set_labels
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} sets labels
#' for the model variables.
#' @section Usage:
#' \preformatted{
#' mdl$set_labels(labels)
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{labels}}{a named character vector.
#' The names are the names of the model variables}
#' }
#' @examples
#' mdl <- islm_mdl()
#' mdl$set_labels(c(c = "Consumption", i = "investments"))
NULL

#' \code{\link{IsisMdl}} method: returns the names of the exogenous model
#' variables
#' @name get_exo_names
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the names of
#' the exogenous model variables, including
#' the left hand side variables of inactive equations
#' (see \code{\link{set_eq_status}}).
#' @section Usage:
#' \preformatted{
#' mdl$get_exo_names(pattern = ".*")
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{pattern}}{a regular expression specifying variable names}
#' }
#' @seealso \code{\link{get_endo_names}} and \code{\link{get_var_names}}
#' @examples
#' mdl <- islm_mdl()
#'
#' # get the names of all exogenous model variables
#' mdl$get_exo_names()
#'
#' # get all variables with names starting with "g":
#' mdl$get_exo_names(pattern = "^g.*")
NULL

#' \code{\link{IsisMdl}} method: returns the names of the model
#' variables
#' @name get_var_names
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the names of
#' the model variables, both exogenous and endogenous.
#'
#' Argument \code{type} can be specified to select variables with a specific type.
#' The following types are supported
#' \describe{
#' \item{\code{"all"}}{All model variables}
#' \item{\code{"lags"}}{Model variables with lags}
#' \item{\code{"leads"}}{Model variables with leads}
#' }
#'
#' @section Usage:
#' \preformatted{
#' mdl$get_var_names(pattern = ".*", type = c("all", "lags", "leads"))
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{pattern}}{a regular expression specifying variable names}
#' \item{\code{type}}{a character string specifying the variable type. See
#' the description above}
#' }
#'

#'
#' @seealso \code{\link{get_endo_names}} and \code{\link{get_exo_names}}
#' @examples
#' mdl <- islm_mdl()
#'
#' # get the names of all model variables
#' mdl$get_var_names()
#'
#' # get all variables with names starting with "m":
#' mdl$get_var_names(pattern = "^y.*")
#'
#' # get the names of all lagged variables
#' mdl$get_var_names(type = "lags")
NULL


#' \code{\link{IsisMdl}} method: returns the names of the model variables
#' @name get_par_names
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the names of
#' the model parameters
#'
#' @section Usage:
#' \preformatted{
#' mdl$get_par_names(pattern = ".*")
#'
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{pattern}}{a regular expression specifying parameter names}
#' }
#' @examples
#' mdl <- islm_mdl()
#'
#' # print all model parameter names
#' print(mdl$get_par_names())
#'
#' # print names of model paramters with names starting with c
#' print(mdl$get_par_names(pattern = "^c.*"))
NULL

#' \code{\link{IsisMdl}} method: returns the the equation names
#' @name get_eq_names
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the
#' the equation names.
#' Argument \code{pattern} can be specified to select only
#' equations with names matching a regular expression. Argument \code{status}
#' can be specified to select only the active or inactive equations.
#' Possible options for argument \code{status are}
#' \describe{
#' \item{\code{"active"}}{active equations}
#' \item{\code{"inactive"}}{inactive equations}
#' \item{\code{"all"}}{all equations, the default}
#' }
#'
#' Argument \code{order} specifies the order of the eqautions returned.
#' The following ordering options are recognized:
#' \describe{
#' \item{\code{"sorted"}}{alphabetically ordering}
#' \item{\code{"solve"}}{ordered according to the solution sequence}
#' \item{\code{"natural"}}{same order as in the \code{mdl} file}
#' }
#'
#' @section Usage:
#' \preformatted{
#' mdl$get_eq_names(pattern = ".*", status =  c("all", "active", "inactive"),
#'                  order =  c("sorted", "solve", "natural"))
#'
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{pattern}}{a regular expression specifying equation names}
#' \item{\code{status}}{the equation status, see Description}
#' \item{\code{order}}{the ordering of the equations (see description)}
#' }
#' @examples
#' mdl <- islm_mdl()
#'
#' # get the names of equations in solution order
#' mdl$get_eq_names(order = "solve")
#'
#' # get all equations with names starting with "y":
#' mdl$get_eq_names(pattern = "^y.*")
NULL

#' \code{\link{IsisMdl}} method: activates or de-activates one or more equations.
#' @name set_eq_status
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' can be used to set the equation status (active or inactive)
#' of one or more equations.
#'
#' This procedure is used to activate or deactivate a specified set
#' of equations.
#' After compiling a model, all equations are active.
#' Sometimes however it can be necessary to temporarily
#' exclude an equation from the model and
#' the solution process without actually removing it.
#'
#' Deactivating an equation implies that the left-hand side variable
#' becomes an exogenous variable. As long as an equation is
#' inactive, the corresponding left-hand side variable and any
#' constant adjustment (for \code{frml} equations) will remain
#' \emph{unchanged} in the model workspace.
#'
#' However the methods \code{set_data}, \code{set_ca},
#' \code{get_data} and \code{get_ca}
#' will still transfer data to and from the model workspace.
#'
#' A deactivated equation can also be reactivated. It will again
#' participate in the solution process and its left-hand side
#' variable will be treated as endogenous.
#'
#' Since deactivating effectively changes the structure of the model,
#' it may be necessary to compute a new ordering of the model.
#' This is not done automatically.
#' You must do it by hand. Currently, package \code{isismdl} does
#' not yet support reordering the model, but this feature will
#' become available in the future.
#'
#' If the left-hand side variable of a deactivated equation
#' appears as lead in the model, that lead will
#' temporarily be marked as an exogenous lead.
#' However, if a lead of another endogenous variable occurs
#' only in the deactivated equation that particular lead will \emph{not}
#' be registered as exogenous. The model will still be regarded as containing
#' endogenous leads and therefore the default solution mode will be
#' \code{ratex}, i.e. the Fair-Taylor method will be used for solving the model.
#'
#'
#' @section Usage:
#' \preformatted{
#' mdl$set_eq_status(status =  c("active", "inactive"), pattern, names)
#'
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{status}}{a character string specifying
#' the equation status (\code{"active"} or code{"inactive"})}
#' \item{\code{pattern}}{a regular expression specifying the names
#' of the equations}
#' \item{\code{names}}{a character vector with the names of the equations}
#' }
#'
#' If neither \code{pattern} nor \code{status} have been specified,
#' then all equations will be activated or deactivated.
#' @seealso \code{\link{get_eq_names}}
#' @examples
#' mdl <- islm_mdl()
#'
#' # deactivate equation "c" and "i"
#' mdl$set_eq_status("inactive", names = c("c", "i"))
#'
#' # deactivate all equations starting with "y" ("y" and "yd")
#' mdl$set_eq_status("inactive", pattern = "^y*")
#'
#' # print all deactivated equations
#' print(mdl$get_eq_names(status = "inactive"))
NULL

#' \code{\link{IsisMdl}} method: sets the model period
#' @name set_period
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} sets the model period.
#' This is the default period used when solving the model.
#'
#' If the model data has not already been initialized with method
#' \code{\link{init_data}}, then \code{set_period} also initializes
#' the model data. In that case the model data period is set to the
#' specified model period extended with a lag and lead period.
#' Model timeseries are initialized with \code{NA} and all constant
#' adjustments with 0.
#'
#' If the model data has already been initialized with  method
#' \code{\link{init_data}}, then the new model period
#' should be compatible with the model data period.
#' In particular, the new model period extended with a lag and lead period
#' should not contain periods outside the model data period.
#' @section Usage:
#' \preformatted{
#' mdl$set_period(period)
#'
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{period}}{\code{\link[regts]{period_range}}
#' object, or an object that can be coerced to
#' \code{\link[regts]{period_range}}}
#' }
#'
#' @examples
#' mdl <- islm_mdl()
#' mdl$set_period("2017Q2/2021Q3")
NULL

#' \code{\link{IsisMdl}} method: initialized the model data.
#' @name init_data
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} sets the data period and
#' initializes the model variables and constant adjustmemts.
#'
#' If the model period has not yet been specified (in function
#' \code{\link{isis_mdl}} or method \code{\link{set_period}}), then
#' this method also sets the model period, the standard period
#' for which the model will be solved. The model period
#' is obtained from the data period by subtracting the lag and lead periods.
#'
#' The method initializes all model timeseries with \code{NA}
#' and all constant adjustments with 0 for the data period.
#' If arguments \code{data} or \code{ca} have been specified,
#' then the model variables or constant adjustments are
#' subsequently updated with the timeseries in \code{data} or \code{ca},
#' respectively.
#' @section Usage:
#' \preformatted{
#' mdl$init_data(data_period, data, ca)
#'
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{data_period}}{\code{\link[regts]{period_range}}
#' object, or an object that can be coerced to
#' \code{\link[regts]{period_range}}.  If not specified then the data period
#' is based on the period range of argument \code{data} (if this argument
#' has been specified) and  the model period.}
#' \item{\code{data}}{a \code{\link[stats]{ts}} or \code{\link[regts]{regts}}
#'  object with model variables}
#' \item{\code{ca}}{a \code{\link[stats]{ts}} or \code{\link[regts]{regts}}
#'  object with constant adjustments}
#' }
NULL

#' \code{\link{IsisMdl}} method: returns the model period
#' @name get_period
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the model period.
#'
#' @section Usage:
#' \preformatted{
#' mdl$get_period()
#'
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
#' @seealso
#' \code{\link{set_period}}
NULL

#' \code{\link{IsisMdl}} method: returns the model data period
#' @name get_data_period
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the model data period.
#'
#' @section Usage:
#' \preformatted{
#' mdl$get_data_period()
#'
#' }
#'
#' \code{mdl} is an \code{IsisMdl} object
#' @seealso
#' \code{\link{set_period}}
NULL

#' \code{\link{IsisMdl}} method: Solves the model.
#' @name solve
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} solves
#' the model. It requires that the model period has been
#' set with methods \code{\link{isis_mdl}}, \code{\link{init_data}}
#' or \code{\link{set_period}}).

#' @section Usage:
#' \code{IsisMdl} method:
#' \preformatted{
#' mdl$solve(period = mdl$get_period(), options = list(),
#'           fit_options = list()
#'
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{period}}{\code{\link[regts]{period_range}}
#' object, or an object
#' that can be coerced to \code{\link[regts]{period_range}}}
#' \item{\code{options}}{a named list with solve options,
#' for example \code{list(maxiter = 50)}.
#' The names are the corresponding argument names of
#' method \code{\link{set_solve_options}}
#' The specified options will only used in this call of
#' {solve()} and will not be stored in the \code{IsisMdl} object}
#' \item{\code{fit_options}}{a named list with options for the fit procedure,
#' for example \code{list(maxiter = 10)}.
#' The names are the corresponding argument names of
#' method \code{\link{set_fit_options}}
#' The specified options will only used in this call of
#' {solve()} and will not be stored in the \code{IsisMdl} object}
#' }
#'
#' @section Details:
#'
#' The model will be solved for each subperiod from the
#' solution period sequentially.
#' The solution is stored in the \code{IsisMdl} object, and can be
#' retrieved by methods \code{\link{get_data}}
#' (or \code{\link{get_ca}} for the constant adjustments).
#' Any subsequent solves of a model will use these data.
#' If a \code{solve} has converged and no data have changed,
#' then a second \code{solve} will report convergence in 0
#' iterations.
#'
#' The solve options specified are only applied to the current
#' solve. If none are specified the solve options
#' as specified with method \code{\link{set_solve_options}}
#' are used.
#'
#' The solve procedure \emph{never} raises an error, even if the solve was
#' not successful. In that case a warning may be issued. It is up to the user
#' to perform any checks.
#' Method \code{\link{get_solve_status}} can be used to check
#' whether the solve was successfully terminated or not.
#' The solve method outputs a report which the user should check.
#'
#' @seealso \code{\link{set_solve_options}},
#' \code{\link{set_fit_options}} and \code{\link{get_solve_status}}
#' @examples
#' mdl <- islm_mdl(period = "2017Q1/2018Q4")
#' mdl$solve(options = list(report = "fullrep"))
#'
#' # solve the model for all periods before 2018Q1
#' mdl$solve(period = "/2017Q4")
#'
#' # solve the model for all quarters in 2017 (2017Q1/2017Q4)
#' mdl$solve(period = "2017")
NULL

#' \code{\link{IsisMdl}} method: Returns the solve status of the last model solve.
#' @name get_solve_status
#' @md
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the status
#' of the last model solve as a  text string. If the last model solve
#' was succesfull, it returns the string \code{"OK"}.
#'

#' @section Usage:
#' \code{IsisMdl} method:
#' \preformatted{
#' mdl$get_solve_status()
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Details:
#'
#' The possible return values are:
#'  * \code{"Method solve has not yet been called"}
#'  * \code{"OK"}
#'  * \code{"Simulation not possible"} (usually this means that exogenous
#'  or feedback variables have \code{NA} values)
#'  * \code{"Simulation stopped"} (it was not possible to find a solution)
#'  * \code{"Initial lags/leads missing/invalid. Simulation not possible"}
#'  * \code{"Invalid parameter values detected. Simulation not possible"}
#'  * \code{"Fair-Taylor has not converged"}
#'  * \code{"Out of memory. Simulation not succesfull"}
#'  * \code{"Unknown problem in solve. Simulation not succesfull"}
#'
#' @seealso \code{\link{solve}}
#' @examples
#' \dontrun{
#' mdl <- islm_mdl(period = "2017Q1/2018Q4")
#' mdl$set_values(NA, names = "y", period = "2017Q1")
#' mdl$solve()
#' if (mdl$get_solve_status() != "OK") {
#'    stop("Error solving the model. Check the warnings!")
#' }
#' }
NULL

#' \code{\link{IsisMdl}} method: Calculates missing model data from identities
#' @name fill_mdl_data
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' attempts to calculate missing data for endogenous
#' variables of a model by solving the identity equations in solution order.
#'
#' The procedure can be used to fill in data before and beyond the
#' model period (as set by method \code{set_period} for as many
#' variables as possible.
#'
#' @section Usage:
#' \preformatted{
#' mdl$fill_mdl_data(period = mdl$get_data_period(),
#'                   report = c("period", "minimal", "no"))
#'
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{period}}{a \code{\link[regts]{period_range}} object}
#' \item{\code{report}}{Defines the type of report about the number of
#' replaced missing values. See details.}
#' }
#'
#' @section Details:
#'
#' Argument \code{report} can be used to specify
#' the type of report about the number of replaced missing values.
#' Specify
#' \describe{
#' \item{\code{minimal}}{to get a minimal report. Only the total number
#' of replaced missing values is reported}
#' \item{\code{period}}{to get a report per period (default). For each period
#' the number of replaced missing values is reported}
#' \item{\code{no}}{to not generate a report}
#' }
#'
#'
#' @examples
#' mdl <- islm_mdl(period = "2017Q1/2018Q4")
#'
#' mdl$set_values(200, names = "t", period = "2017Q1")
#
#' mdl$fill_mdl_data(period = "2017Q1")
#' print(mdl$get_data(names = "yd"))
NULL

#' \code{\link{IsisMdl}} method: runs model equations
#' @name run_eqn
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' runs specific equations of the model separately.
#' Each specified equation is run separately for the specified period.
#' If the equation is a stochastic equation (a \code{frml} equation)
#' and the corresponding endogenous variable has been fixed
#' then the constant adjustment for the equation will be calculated
#' such that the result of the equation equals the predetermined required
#' value for the left-hand side.
#'
#' If neither argument \code{pattern} or \code{names} have been specified,
#' then all active model equations are ran in solve order.
#'
#' @section Usage:
#' \preformatted{
#' mdl$run_eqn(pattern, names, period = mdl$get_data_period())
#'
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{pattern}}{a regular expression. Equations with names
#' matching the regular expression are run in solve order}
#' \item{\code{names}}{a character vector with equation names. The
#' corresponding equations are solved in the order as they are
#' specified}
#' \item{\code{period}}{a \code{\link[regts]{period_range}} object}
#' }
#'
#' @examples
#' mdl <- islm_mdl("2017Q1/2019Q3")
#' mdl$run_eqn(names = c("c", "t"))
NULL


#' \code{\link{IsisMdl}} methods: Retrieve timeseries from the model data,
#' constant adjusments, fix values or fit targets
#' @name get_data-methods
#' @aliases get_data get_ca get_fix get_fit
#' @description
#' These methods of R6 class \code{\link{IsisMdl}}
#' can be used to retrieve timeseries from the model data,
#' constant adjusments, fix values or fit targets.
#'
#' @section Usage:
#' \preformatted{
#' mdl$get_data(pattern, names, period = mdl$get_data_period())
#'
#' mdl$get_ca(pattern, names, period = mdl$get_data_period())
#'
#' mdl$get_fix()
#'
#' mdl$get_fit()
#'
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{names}}{a character vector with variable names}
#' \item{\code{pattern}}{a regular expression}
#' \item{\code{period}}{an \code{\link[regts]{period_range}} object or an
#' object that can be coerced to a \code{period_range}}
#' }
#' @section Methods:
#' \itemize{
#' \item \code{get_mdl_data}: Model data
#'
#'\item \code{get_ca}: Constant adjustments
#'
#'\item \code{get_fix_values}: Fix values
#'
#'\item \code{get_fit_targets}: Fit targets
#'}
#'
#' @examples
#' mdl <- islm_mdl(period = "2016Q1/2017Q4")
#'
#' print(mdl$get_data())
#'
#' # print data for 2017Q2 and later
#' print(mdl$get_data(names = c("g", "y"), period = "2017Q2/"))
#'
#' # print data for all quarters in 2017 (2017Q1/2017Q4)
#' print(mdl$get_data(names = c("g", "y"), period = "2017"))
#'
#' print(mdl$get_data(pattern = "^ymdl"))
#'
#' @seealso \code{\link{set_data-methods}}, \code{\link{set_values-methods}}
#' and \code{\link{change_data-methods}}
NULL

#' \code{\link{IsisMdl}} methods: transfers data from a timeseries
#' object to the model data, constant adjusments, fix values or fit targets.
#' @name set_data-methods
#' @aliases set_data set_ca set_fix set_fit
#' @description
#' These methods of R6 class \code{\link{IsisMdl}}
#' Transfers data from a timeseries object to the model data,
#' constant adjusments, fix values or fit targets.
#' @section Usage:
#' \preformatted{
#' mdl$set_data(data, names = colnames(data), upd_mode = c("upd", "updval"),
#'              fun)
#'
#' mdl$set_ca(data, names = colnames(data), upd_mode = c("upd", "updval"),
#'            fun)
#'
#' mdl$set_fix(data, names = colnames(data), upd_mode = c("upd", "updval"))
#'
#' mdl$set_fit(data, names = colnames(data), upd_mode = c("upd", "updval"))
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{data}}{a \code{\link[stats]{ts}} or \code{\link[regts]{regts}}
#'  timeseries object}
#' \item{\code{names}}{a character vector with variable names, with the
#' same length as the number of timeseries in \code{data}. Defaults to the
#' column names of \code{data}. If \code{data} does not have column names,
#' then argument \code{names} is mandatory}
#' \item{\code{upd_mode}}{the update mode, a character string specifying
#' how the timeseries are updated: \code{"upd"} (standard update, default) or
#' \code{"updval"} (update only with valid numbers). See details.}
#' \item{\code{fun}}{a function used to update the model data. This should
#' be a function with two arguments. The original model data is passed to the first
#' argument of the function and \code{data} to the second argument.
#' See the examples.}
#' }
#' @section Methods:
#'
#' \describe{
#' \item{\code{set_data}}{Sets model data.
#' If \code{data} has labels, then \code{set_data} will also update
#' the labels of the corresponding model variables}
#' \item{\code{set_ca}}{Set constant adjustments, i.e. the residuals of
#' behavourial (frml) equations}
#' \item{\code{set_fix}}{Set fix values for the stochastic
#' model variables (i.e. model variables that occur at the left
#' hand side of a frml equation). The model variables will be fixed
#' at the specified value. A fix value of \code{NA} implies
#' that the corresponding variable is not fixed. \code{set_fix}
#' also updates the model data with all non NA values}
#' \item{\code{set_fit}}{Set fit targets for the fit procedure.
#' A fit target value of \code{NA} implies
#' that the corresponding variable is no fit target}
#'}
#' @section Details:
#'
#' Method \code{set_data} transfers data from a timeseries object to the
#' model data. If \code{data} is a multivariate timeseries object, then
#' each column is used to update the model variable with the same
#' name as the column name. If \code{data} does not have column names,
#' or if the column names do not correspond to the model variable names,
#' then argument \code{names} should be specified.
#'
#' By default, all values in \code{data} are used to update the corresponding
#' model variable. Sometimes it is desirable to skip the \code{NA} values
#' in \code{data}. This can be achieved by selecting \code{"updval"} for argument
#' \code{upd_mode}. Other non finite numbers (\code{NaN}, \code{Inf}, and
#' \code{-Inf}) are also disregarded for this update mode.
#'
#' \code{set_ca}, \code{set_fix} and \code{set_fit} and
#' \code{set_data} works similarly.
#'
#' @examples
#'
#' mdl <- islm_mdl(period = "2017Q1/2017Q3")
#'
#' # create a multivariate regts object for exogenous variables g and md
#' exo <- regts(matrix(c(200, 210, 220, 250, 260, 270), ncol = 2),
#'              start = "2017Q1", names = c("g", "ms"))
#'
#' # set and print data
#' mdl$set_data(exo)
#' print(mdl$get_data())
#'
#' # create a univariate regts object for exogenous variable ms,
#' # with a missing value in 2017Q2
#' ms <- regts(c(255, NA, 273), start = "2017Q1")
#'
#' # update with update mode updval (ignore NA)
#' # note that here we have to specify argument names,
#' # because ms does not have column names
#' mdl$set_data(ms, names = "ms", upd_mode = "updval")
#' print(mdl$get_data())
#'
#' # in the next example, we use argument fun to apply an additive shock to the
#' # exogenous variables g and ms.
#' shock <- regts(matrix(c(-5, -10, -15, 3 , 6, 6), ncol = 2),
#'              start = "2017Q1", names = c("g", "ms"))
#' mdl$set_data(shock, fun = function(x1, x2) {x1 + x2})
#'
#' # the statement above can be more concisely written as
#' mdl$set_data(shock, fun = `+`)
#' #`+` is a primitive function that adds its two arguments.
#'
#' @seealso \code{\link{get_data-methods}}, \code{\link{set_values-methods}},
#' \code{\link{change_data-methods}}, \code{\link{fix_variables}},
#' \code{\link{clear_fix}} and \code{\link{clear_fit}}.
NULL

#' \code{\link{IsisMdl}} methods: Sets the values of the model data,
#' constant adjustments, fix values or fit targets
#' @name set_values-methods
#' @aliases set_values set_ca_values set_fix_values set_fit_values
#' @description
#' These methods of R6 class \code{\link{IsisMdl}}
#' can be used to set the values of the model data, constant adjusments,
#' fix values or fit targets.
#'
#' @section Usage:
#' \preformatted{
#' mdl$set_values(value, names, pattern, period = mdl$get_data_period())
#'
#' mdl$set_ca_values(value, names, pattern, period = mdl$get_data_period())
#'
#' mdl$set_fix_values(value, names, pattern, period = mdl$get_data_period())
#'
#' mdl$set_fit_values(value, names, pattern, period = mdl$get_data_period())
#'
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{value}}{a numeric vector of length 1 or with the same length
#' as the length of the range of \code{period}}
#' \item{\code{names}}{a character vector with variable names}
#' \item{\code{pattern}}{a regular expression specifying the
#' variable names}
#' \item{\code{period}}{an \code{\link[regts]{period_range}} object or an
#' object that can be coerced to a \code{period_range}. The default
#' is the data period}
#' }
#' @section Methods:
#' \describe{
#' \item{\code{set_values}}{Sets the values of model data}
#' \item{\code{set_ca}}{Sets the values of the  constant adjustments, i.e. the
#' residuals of behavourial (frml) equations.}
#' \item{\code{set_fix}}{Set fix values for the stochastic
#' model variables (i.e. model variables that occur at the left
#' hand side of a frml equation). The model variables will be fixed
#' at the specified value. A fix value of \code{NA} implies
#' that the corresponding variable is not fixed. \code{set_fix}
#' also updates the model data with all non NA values}
#' \item{\code{set_fit}}{Set fit targets for the fit procedure.
#' A fit target value of \code{NA} implies
#' that the corresponding variable is no fit target}
#' }
#'
#' @examples
#'
#' mdl <- islm_mdl(period = "2017Q1/2017Q3")
#'
#' # set the values for y in the full data period
#' mdl$set_values(1000, names = "y")
#'
#' # set the values of ms and md in 2017Q1 and 2017Q2
#' mdl$set_values(c(205,206), pattern = "^m.$", period = "2017Q1/2017Q2")
#'
#' # set the values of ms and md in all quarters of 2017 (2017Q1/2017Q4)
#' mdl$set_values(c(205, 206, 207, 208), pattern = "^m.$", period = "2017")
#
#' print(mdl$get_data())
#'
#' @examples
#'
#' @seealso \code{\link{get_data-methods}}, \code{\link{set_data-methods}}
#' and \code{\link{change_data-methods}}
NULL

#' \code{\link{IsisMdl}} methods: changes the model data or constant
#' adjustments by applying a function.
#' @name change_data-methods
#' @aliases change_data change_ca
#' @description
#' This methods of R6 class \code{\link{IsisMdl}}
#' changes the model data or constant adjustments by applying a function.
#'
#' @section Usage:
#' \preformatted{
#' mdl$change_data(fun, names, pattern, period = mdl$get_data_period())
#'
#' mdl$change_ca(fun names, pattern, period = mdl$get_data_period())
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{fun}}{a function applied each model timeseries or
#' constant adjustment specified with argument \code{names} or \code{pattern}}
#' \item{\code{names}}{a character vector with variable names}
#' \item{\code{pattern}}{a regular expression}
#' \item{\code{period}}{an \code{\link[regts]{period_range}} object or an
#' object that can be coerced to a \code{period_range}}
#' \item{\code{...}}{arguments passed to \code{fun}}
#' }
#'
#' @section Details:
#'
#' The function specified with argument `fun` should be a function
#' with at least one argument, for example `fun = function(x) {x + 0.1}`.
#' The first argument (named `x` in the example) will be the model
#' variable. The function is evaluated for each model variable separately.
#' The values of the model variables for period range `period` are passed as a
#' normal numeric vector (not a timeseries) to the first argument.
#'
#' An example may help to clarify this. Consider the following statement
#'  ```
#'  mdl$change_data(fun = myfun, names = c("c", "y"),
#'                       period = "2017q1/2017q2"),
#'  ```
#'
#'  where `mdl` is a `DynMdl` object and `myfun` some function whose details
#'  are not relevant here. Method  \code{change_data} evaluates this as
#'  ```
#'  data <- mdl$get_data(names = c("c", "y"), period = "2017q1/2017q2")
#'  data[, "c"] <- myfun(as.numeric(data[, "c"]))
#'  data[, "y"] <- myfun(as.numeric(data[, "y"]))
#'  mdl$set_data(data)
#'  ```
#'
#'  The function result must be a vector (or timeseries) of length one or with
#'  the same length as the number of periods in the period range \code{period}.
#'
#' @section Methods:
#' \describe{
#' \item{\code{changes_data}}{Changes the model data}
#' \item{\code{change_ca}}{Changes the constant adjustments}
#' }
#' @examples
#' mdl <- islm_mdl(period = "2017Q1/2017Q3")
#'
#' # increase y and yd with 10% for the full data period
#' mdl$change_data(pattern = "^y.?$", fun = function(x) {x * 1.1})
#'
#' # increase ms in 2017Q1 and 2017Q2 with 10 and 20, resp.
#' mdl$change_data(names = "ms", fun = function(x, dx) {x + dx},
#'                 dx = c(10, 20), period = "2017Q1/2017Q2")
#' print(mdl$get_data())
#'
#' @seealso \code{\link{get_data-methods}}, \code{\link{set_data-methods}} and
#' \code{\link{set_values-methods}}
#'
NULL

#' \code{\link{IsisMdl}} method: Sets or updates  the root mean square errors
#' @name set_rms
#' @aliases get_rms
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' sets or updates the root mean square (rms) error data
#' used in the fit procedure. All variables whose rms value
#' is larger than 0 and not \code{NA} are used as
#' instruments of the fit procedure.
#'
#' Method \code{get_rms} returns all rms values
#' larger than 0 and not equal to \code{NA}.
#'
#' @section Usage:
#' \preformatted{
#' mdl$set_rms(values)
#'
#' mdl$get_rms()
#'
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object

#' @section Arguments:
#'
#' \describe{
#' \item{\code{values}}{a named numeric vector with rms values.
#' If a value is positive and not \code{"NA"},
#' then the corresponding value will be used
#' as fit instrument}
#' }
#' @examples
#' mdl <- islm_mdl(period = "2017Q1/2018Q4")
#'
#' mdl$set_rms(c(c = 5.0, t = 2, i = 21, md = 2))
#' print(mdl$get_rms())
#'
#' # stop using variable t as fit instrument
#' mdl$set_rms(c(t = NA))
#' print(mdl$get_rms())
NULL

#' \code{\link{IsisMdl}} method: Sets the solve options
#' @name set_solve_options
#' @aliases get_solve_options
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} can be used to set one or more
#' solve options. These options will be stored in the \code{IsisMdl} object.
#'
#' Method \code{get_solve_options} returns the solve options as a named
#' list
#'
#' @section Usage:
#' \preformatted{
#' mdl$set_solve_options(mode, fbstart, maxiter, maxjacupd, rlxspeed,
#'                       rlxmin, rlxmax, cstpbk, cnmtrx, xrelax,
#'                       xmaxiter, xupdate, dbgopt, erropt,
#'                       report, ratreport, ratreport_rep, ratfullreport_rep,
#'                       bktmax, xtfac, svdtest_tol)
#'
#' mdl$get_solve_options()
#' }
#'
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' All arguments below expect a numerical value unless mentioned otherwise.
#'
#' \describe{
#' \item{\code{mode}}{a character string specifying the solution mode
#' (\code{"auto"}, \code{"ratex"}, \code{"dynamic"}, \code{"reschk"},
#' \code{"backward"} or \code{"static"}). \code{"auto"} is the default.
#' See section "Solution modes" below}
#' \item{\code{fbstart}}{a character string specifying
#' the method of initialising feedback values.
#' (\code{"current"}, \code{"previous"}, \code{"curifok"} or \code{"previfok"}).
#' The default is \code{"current"}. See section "Feedback initialisation
#' methods" below}
#' \item{\code{maxiter}}{the maximum number of iterations per period (default 50)}
#' \item{\code{maxjacupd}}{the maximum number of Newton Jacobian updates per period
#'  (default 10)}
#'  \item{\code{rlxspeed}}{Newton relaxation shrinkage (default is 0.5)}
#'  \item{\code{rlxmin}}{Minimum Newton relaxation factor (default is 0.05)}
#'  \item{\code{rlxmax}}{Maximum Newton relaxation factor (default is 1.0)}
#'  \item{\code{cstpbk}}{Stepback criterion (default is 1.3).
#' If the convergence criterium \code{Fcrit} is larger
#' than \code{cstpbk} or invalid feedback variables
#' have been obtained then the Newton step
#' is not accepted and linesearching will be initiated.
#' If the linesearching procedure failed
#' (\code{Fcrit} is still larger than \code{cstpbk}
#' after the maximum number of linesearch steps \code{bktmax}
#' has been reached or if the relaxation
#' factor has become smaller than \code{rlxmin}),
#' a new Jacobian matrix is computed.
#' In each linesearch step the current relaxation factor is shrunk by
#' \code{rspeed}.
#' The relaxation factor is set to its maximum value
#' \code{rlxmax}) when a new Jacobian has been calculated.
#' }
#'  \item{\code{cnmtrx}}{Recalculate matrix criterion (default is 0.9).
#' If the convergence criterium \code{Fcrit} is larger
#' than \code{cnmtrx} but smaller than \code{cstpbk},
#' the Newton step is accepted but a new Jacobian is computed
#' and the relaxation factor is set to its maximum value
#' \code{rlxmax}.
#' The new Jacobian is used in the next step. However, the
#' Jacobian will not be recalculated if the number of Jacobian updates
#' in a period is larger than \code{maxjacupd}}
#'  \item{\code{xrelax}}{Rational expectations relaxation factor (default is 1)}
#'  \item{\code{xmaxiter}}{Maximum number of rational expectation iterations
#' (default is 10)}
#'  \item{\code{xupdate}}{Character string defining the method of updating
#' leads. Possible values are \code{"fixed"} (the default) and \code{"lastval"}.
#' For \code{"fixed"} the leads beyond the solution period
#' are fixed at the initial values. For \code{"lastval"} leads beyond
#' the solution period take on the values from the last solution date}
#' \item{\code{dbgopt}}{A character vector specifying one more
#' debugging options. See section "Debugging options" below}
#' \item{\code{erropt}}{Character string defining the error handling when
#' invalid lags, leads, constant adjustments  and/or exogenous variables are detected.
#' Possible values are \code{"stop"} (stop on errors),
#' \code{"cont"} (continue on errors but write a message to the output)
#' and \code{"silent"} (also continue but without message).
#' The default is \code{"stop"}}
#' \item{\code{report}}{A character string defining the type of
#' computation progress report. Possible values are
#' \code{"period"} (for a report per period),
#' \code{"fullrep"} (for a full report),
#' \code{"minimal"}  (for a minimal report), and
#' \code{"none"}  (for no report). The default is \code{"period"}}
#'  The report options \code{"none"} also suppresses all output
#' of the fit procedure and the Fair-Taylor progress report.
#' \item{\code{ratreport}}{Defines the type of rational expectations progress
#' report. See section "Ratex report options" below}
#' \item{\code{ratreport_rep}}{An integer number specifying
#' the Fair-Taylor report repetition count.
#' See Section "Ratex report options" below}
#' \item{\code{ratfullreport_rep}}{An integer number, specifying
#' the Fair-Taylor full report repetition count. See Section
#' "Ratex report options" below}
#' \item{\code{bktmax}}{Maximum number of backtracking linesearch steps
#' with old jacobian. Sometimes it is necessary for the Broyden
#' method to take a shorter step than the standard step. This is called
#' backtracking linesearch. \code{bktmax} is the maximum number of
#' line search steps before a new Jacobian is computed}
#' \item{\code{xtfac}}{Rational expectations convergence test multiplier
#' When using the \code{"ratex"} solution mode,
#' convergence of endogenous leads cannot be tested to the accuracy used in
#' testing for convergence in the solution of the model.
#' This option specifies the multiplier to apply to the convergence criterion
#' for each endogenous variable if the variable has an endogenous lead.
#' Suppose for example that some variable has a convergence criterion of $10^{-5}$
#' and assume a value of 10 for the multiplier.
#' Then its endogenous lead will be regarded as converged}
#' \item{\code{svdtest_tol}}{Singular Value Decomposition (SVD) test tolerance
#' parameter.
#' If the inverse condition of the Jacobian is smaller than this parameter,
#' then an SVD analysis of the Jacobian is performed. This may help to
#' find the equations that cause (near) singularity of the Jacobian.
#' The default value is \code{-1}, which implies that the SVD test is never
#' performed. Specify a number between 0 and 1 to enable an SVD analysis depending
#' on the inverse condition of the Jacobian.
#' When this option has been specified a copy of the Jacobian is kept in memory,
#' even if the Jacobian is not ill-conditioned.
#' This option should therefore only be used during testing. It should be turned
#' off in production calculations}
#' }
#'
#' @section Solution modes:
#'
#' The solution mode can be specified with argument \code{mode}.
#' Possible values are:
#' \describe{
#' \item{\code{"auto"}}{determine the solution mode automatically:
#' \code{"ratex"} for models with endogenous leads
#' and \code{"dynamic"} for models without endogenous leads}
#' \item{\code{"dynamic"}}{to update lags and current values of all
#' right-hand side endogenous variables (leads are not updated). This is the
#' default for models without endogenous leads}
#' \item{\code{"ratex"}}{to update lags, leads and current values of all
#' right-hand side endogenous variables. This is the default mode
#' for models with endogenous leads.
#' The model is solved in dynamic mode for all periods conditional
#' on the endogenous right-hand side leads. After solving for the complete
#' solution period the endogenous leads are updated with the the results
#' for the corresponding endogenous variables. The solution process thus consists
#' of an two loops: an inner loop solving the model  for all periods given the leads and
#' an outer loop which solves for the endogenous leads}
#' \item{\code{"static"}}{to update only current values of right-hand side
#' endogenous variables lags and leads are not modified}
#' \item{\code{"reschk"}}{to not update right-hand side
#' endogenous variables from the solution}
#' \item{\code{"backward"}}{same as dynamic, except that the model is solved
#' backwards. The model is solved in reversed order by starting at the last
#' solution period and ending at the first solution period. Leads are updated
#' and lags are not updated}
#' }
#' If a model contains leads then the \code{"ratex"} mode is the
#' default; this is a Fair-Taylor algorithm.
#'
#' The default is \code{"auto"}.
#'
#' @section Feedback initialisation methods:
#'
#' Argument \code{fbstart} can be used to specify
#' the way how the feedback variables at the current period
#' (i.e. the period for which the model is being solved)
#' are initialised from the model data.
#' Possible values of \code{fbstart} are:
#' \describe{
#' \item{\code{"current"}}{the initial values are always taken from the
#' current period. This is the default}
#' \item{\code{"previous"}}{The initial values are
#' taken from the previous period except when the first period
#' to be solved is the start of the model data period.
#' In that case current period values are used}
#' \item{\code{"curifok"}}{Current period
#' values are used if they are valid otherwise previous period
#' values are used}
#' \item{\code{"previfok"}}{At the start of the solution
#' period, previous period values will be used if they are available
#' and valid; otherwise current period values will be used.
#' Thereafter previous period initial values are always used, which is
#' equivalent to the \code{"previous"} method}
#' }
#' The default is \code{"current"}.
#'
#' @section Debugging options:
#'
#' Argument \code{dbgopt} can be used to specify one or more
#' options for debugging.  Possible values are
#' \describe{
#' \item{\code{"prifb"}}{print feedback variables at each iteration}
#' \item{\code{"prild"}}{print all leads at each ratex iteration}
#' \item{\code{"prijac"}}{print jacobian matrix when updated}
#' \item{\code{"prinoconv"}}{print all not converged endogenous variables}
#' \item{\code{"prinotconvl"}}{print all not converged leads}
#' \item{\code{"allinfo"}}{all of the above}
#' \item{\code{"noprifb"}}{do not print feedback variables at each iteration}
#' \item{\code{"noprild"}}{do not print all leads at each ratex iteration}
#' \item{\code{"noprijac"}}{do not print jacobian matrix when updated}
#' \item{\code{"noprinoconv"}}{print only the largest discrepancy of
#' all not converged endogenous variables}
#' \item{\code{"noprinotconvl"}}{print only the largest discrepancy of
#' all not converged leads}
#' \item{\code{"noinfo"}}{no debugging output}
#' \item{\code{"priscal"}}{print scaling factors as determined from the
#' jacobian}
#' \item{\code{nopriscal}}{do not print scaling factors as determined
#' from the jacobian}
#' }
#' Default is no printing of debugging information.

#' @section Ratex report options:
#'
#' The type of report is determined by argument \code{ratreport}.
#' Arguments \code{ratreport_rep} (the report repetion count)
#' and \code{ratfullreport_rep} (the full report repetition count),
#' both specified as integer numbers,
#' can be used to futher modify the progress report.
#'
#' Possible values for \code{ratreport} are
#' \describe{
#' \item{\code{"iter"}}{print the number of not converged
#' expectation values every \code{ratreport_rep} Fair Taylor iteration
#' (the default)}
#' \item{\code{"fullrep"}}{full report. The number of not converged
#' expectation values is printed every \code{ratreport_rep} Fair Taylor
#'  iteration and the largest remaining discrepancy every
#' \code{ratfullreport_rep} Fair Taylor iteration}
#' \item{\code{"minimal"}}{for a full report only after the last Fair Taylor
#' iteration}
#' }
#'
#' If \code{ratfullreport_rep} is \code{NA}, then the full report
#' is printed every \code{ratreport_rep} Fair-Taylor iteration.
#' The default values for \code{ratreport_rep}  and \code{ratfullreport_rep}
#' are 1 and \code{NA}, respectively.
#'
#' @examples
#' mdl <- islm_mdl(period = "2017Q1/2018Q4")
#' mdl$set_solve_options(maxiter = 100)
NULL

#' \code{\link{IsisMdl}} method: Sets the options for the fit procedure.
#' @name set_fit_options
#' @aliases get_fit_options
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} can be used to set one or more
#' options for the fit procedure.
#' These options will be stored in the \code{IsisMdl} object.
#'
#' Method \code{get_fit_options} returns the solve options as a named
#' list
#'
#' @section Usage:
#' \preformatted{
#' mdl$set_fit_options(maxiter, cvgabs, mkdcrt, zero_ca, warn_ca,
#'                    accurate_jac, zealous, report, dbgopt, svdtest_tol)
#'
#' mdl$get_fit_options()
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' All arguments below expect a numerical value unless mentioned otherwise.
#'
#' \describe{
#' \item{\code{maxiter}}{The maximum number of iterations (default 5)}
#' \item{\code{cvgabs}}{Criterion for absolute convergence.
#' When the largest scaled discrepancy of the fit target values is
#' less than \code{cvgabs}, the fit procedure has converged.
#' The default value is 100 times the square root of
#' the machine precision (\code{100 * sqrt(.Machine$double.eps)}),
#' which is typically \code{1.5e-6}.}
#' \item{\code{mkdcrt}}{Criterion for calculating a new fit jacobian.
#' When the ratio of two successive largest scaled discrepancies of
#' the fit target values is
#' larger than \code{mkdcrt} a new fit jacobian will be calculated
#' in the next iteration. Any value specified must lie between 0.05
#' and 0.95. The default value is 0.5.}
#' \item{\code{zero_ca}}{A logical. If \code{TRUE}, then the initial values
#' of the constant adjustments used in the fit procedure are initialised to 0.
#' The default is \code{FALSE}}
#' \item{\code{warn_ca}}{A logical. If \code{TRUE} (default), then warnings
#' are given for possibly too large constant adjustments at the end of the fit
#' procedure for each period.}
#' \item{\code{accurate_jac}}{A logical. If \code{TRUE} (default), then the
#' fit jacobian is calculated accurately, otherwise the jacobian
#' is calculated approximately. See Details}
#' \item{\code{zealous}}{A logical. If \code{TRUE} (default), then a zealous
#' version of the fit procedure is used, otherwise a lazy version is used
#' (see Details). The recommended option is to use the zealous version,
#' although this may require much more CPU time.}
#' \item{\code{report}}{A character string specifying the the
#' type of report of the fit procedure for each period.
#' Possible values are \code{"fullrep"}
#' (the default, an iteration report is printed for each period)
#' and  \code{"minimal"} (for a one line summary).}
#' \item{\code{dbgopt}}{A character vector specifying one or more
#' debugging options. See section "Debugging options" below}
#' \item{\code{svdtest_tol}}{Singular Value Decomposition (SVD) test tolerance
#' parameter.
#' If the inverse condition of the fit Jacobian is smaller than this parameter,
#' then an SVD analysis of the Jacobian is performed. This may help to
#' find the equations that cause (near) singularity of the Jacobian.
#' The default value is \code{-1}, which implies that the SVD test is never
#' performed. Specify a number between 0 and 1 to enable an SVD analysis depending
#' on the inverse condition of the Jacobian.
#' When this option has been specified a copy of the fit Jacobian is kept in memory,
#' even if the Jacobian is not ill-conditioned.
#' This option should therefore only be used during testing. It should be turned
#' off in production calculations}
#' }
#'
#' @section Debugging options:
#'
#' Argument \code{dbgopt} can be used to specify one or more
#' options for debugging the fit procedure.  Possible values are
#' \describe{
#' \item{\code{prica}}{print the fit jacobian every time it is calculated}
#' \item{\code{noprica}}{do not print the fit jacobian every time it is
#' calculated}
#' \item{\code{prijac}}{print the fit jacobian every time it is calculated}
#' \item{\code{noprijac}}{do not print the fit jacobian every time it is
#' calculated}
#' \item{\code{supsot}}{to suppress all output of the normal solution process}
#' \item{\code{nosupsot}}{to not suppress all output of the normal solution
#' process. Output will be a mess if this option is used}
#' }
#' The default debug options are \code{c("noprica", "noprijac", "supsot")}
NULL

#'
#' \code{\link{IsisMdl}} method: Returns the labels of the model variables.
#' @name get_labels
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' returns the labels of the model variables.
#' @section Usage:
#' \preformatted{
#' mdl$get_labels()
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#' @seealso
#' \code{\link{set_labels}}
NULL

#' \code{\link{IsisMdl}} method: Sets the convergence criterion for selected
#' variables.
#' @name set_cvgcrit
#' @aliases get_cvgcrit
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} sets the
#' convergence criterion for one or more endogenous model variables.
#' A variable \eqn{x} has converged when two
#' successive values \eqn{x_2} and
#' \eqn{x_1} satisfy the following
#' condition
#' \deqn{|x_2 - x_1| \le \epsilon \max(1,|x_1|)}
#' where \eqn{\epsilon} is
#' the convergence criterion for the tested
#' variable.
#'
#' The default value of \eqn{\epsilon} for all variables
#' is the square root of the machine precision
#' (\code{sqrt(.Machine$double.eps)}, typically about \code{1.5e-8})
#'
#' Method \code{get_cvgcrit()} returns
#' the convergence criteria for all model variables
#' @section Usage:
#' \preformatted{
#' mdl$set_cvgcrit(value, pattern, names)
#'
#' mdl$get_cvgcrit()
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{value}}{convergence criterion. This must be
#' a small positive number}
#' \item{\code{pattern}}{a regular expression specifying the
#' variable names}
#' \item{\code{names}}{a character vector with variable names}
#' }
#'
#' If neither \code{pattern} nor \code{names} have been specified,
#' then the convergence criterion of all endogenous variables
#' will be set to the specified value.
#'
#' @examples
#' mdl <- islm_mdl()
#'
#' # set convergence criterion for variables "c" and "i":
#' mdl$set_cvgcrit(1e-4, names = c("c", "i"))
#'
#' # set convergence criterion for variables "y" and "yd":
#' mdl$set_cvgcrit(1e-4, pattern = "^y*")
#'
#' print(mdl$get_cvgcrit())
NULL

#' \code{\link{IsisMdl}} method: Sets the Fair-Taylor relaxtion factors
#' @name set_ftrelax
#' @aliases get_ftrelax
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} sets the
#' Fair-Taylor relaxtion factors for the endogenous leads.
#'
#' Method \code{get_ftrelax()} returns
#' the Fair-Taylor relaxtion factors
#' for all endogenous leads.
#' @section Usage:
#' \preformatted{
#' mdl$set_ftrelaxvalue, pattern, names)
#'
#' mdl$get_ftrelax()
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{value}}{Fair-Taylor relaxtion number.
#' This must be a positive number or \code{NA} to disable any previously set value.
#' The default value for all endogenous leads is \code{NA}, which means that
#' the general uniform Fair-taylor relaxation
#' (solve option \code{ftrelax}, see \code{\link{set_solve_options}})
#' will be applied}
#' \item{\code{pattern}}{a regular expression specifying the
#' variable names}
#' \item{\code{names}}{a character vector with variable names}
#' }
#'
#' If neither \code{pattern} nor \code{names} have been specified,
#' then the Fair-Taylor relaxtion factors of all variables
#' with endogenous leads will be set to the specified values.
#'
#' @examples
#' mdl <- ifn_mdl()
#'
#' # set Fair-relaxtion factor all all variables with names of length 2
#' # to 0.5:
#' mdl$set_ftrelax(0.5, pattern = "^..$")
#'
#' # set Fair-relaxtion factor for variable "lambda":
#' mdl$set_ftrelax(0.5, names = "lambda")
#'
#' print(mdl$get_ftrelax())
NULL

#' \code{\link{IsisMdl}} method: Sets the model parameters
#' @name set_param
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' sets the model parameters
#' @section Usage:
#' \preformatted{
#' mdl$set_param(p)
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#' @section Arguments:
#'
#' \describe{
#' \item{\code{p}}{a named list.
#' The names are the names of the parameter names.
#' The list elements are numeric vectors with a length equal to the length
#' of the corresponding parameter}
#' }
#' @examples
#' mdl <- islm_mdl()
#' mdl$set_param(list(i0 = 101))
NULL


#' \code{\link{IsisMdl}} method: Returns model parameters
#' @name get_param
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' returns model parameters
#' @section Usage:
#' \preformatted{
#' mdl$get_param(pattern, names)
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#' @section Arguments:
#'
#' \describe{
#' \item{\code{pattern}}{a regular expression specifying parameter names}
#' \item{\code{names}}{a character vector with parameter names}
#' }
#' @examples
#' mdl <- islm_mdl()
#'
#' # print all model parameters
#' print(mdl$get_param())
#'
#' # print parameters c0, c1, c2 and c3
#' print(mdl$get_param(pattern = "^c.*"))
#' @seealso
#' \code{\link{set_param}}
NULL

#' Writes an \code{IsisMdl} object to  a file
#' @name write_mdl
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' serializes the model object and writes it to a binary file.
#' The model can be read back by function
#' \code{\link{read_mdl}}.
#'
#' @details
#' \code{write_mdl} employs the serialization interface provided
#' by base R function \code{\link[base:readRDS]{saveRDS}}.
#'
#' @section Usage:
#' \preformatted{
#' mdl$write_mdl(file)
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#' @section Arguments:
#'
#' \describe{
#' \item{\code{file}}{the filename. Preferably use the extension
#' \code{.ismdl} so that it is obvious that the written file
#' contains a serialized \code{IsisMdl} object.}
#' }
#' @examples
#' mdl <- islm_mdl("2017Q1/2019Q2")
#' mdl$write_mdl("islm_mdl.ismdl")
#' @seealso \code{\link{read_mdl}}
NULL

#' Serializes the model to an \code{serialized_isismdl} S3 class
#' @name serialize
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' serializes the model object and returns
#' an \code{serialized_isismdl} object, an S3 object that contains
#' all the information about the model.
#' The serialized model can be used to create a new
#' \code{IsisMdl} object with the command
#' \code{IsisMdl$new(serialized_mdl)}
#'
#' @section Usage:
#' \preformatted{
#' mdl$serialize()
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#' @examples
#' mdl <- islm_mdl("2017Q1/2019Q2")
#' serialized_mdl <- mdl$serialize()
#'
#' # create a new model from the serialized model
#' mdl2 <- IsisMdl$new(serialized_mdl)
#' @seealso \code{\link{write_mdl}} and \code{\link{read_mdl}}
NULL


#' \code{\link{IsisMdl}} method: deletes all fit targets and rms values
#' values
#' @name clear_fit
#' @description
#' This methods of R6 class \code{\link{IsisMdl}}
#' deletes all fit targets and root mean square (rms) error values
#' for the fit procedure.
#'
#' @section Usage:
#' \preformatted{
#' mdl$clear_fit()
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#' @seealso \code{\link{set_fit}} and \code{\link{get_fit}}
NULL

#' \code{\link{IsisMdl}} method: deletes all fix values
#' @name clear_fix
#' @description
#' This methods of R6 class \code{\link{IsisMdl}}
#' deletes all fix values
#'
#' @section Usage:
#' \preformatted{
#' mdl$clear_fix()
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#' @seealso \code{\link{set_fix}}, \code{\link{fix_variables}}
#' and \code{\link{get_fix}}
NULL

#' \code{\link{IsisMdl}} method: Returns a copy of this \code{IsisMdl} object
#' @name copy
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}}
#' returns a deep copy of an \code{IsisMdl} object
#' @section Usage:
#' \preformatted{
#' mdl$copy()
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Details:
#' \code{mdl$copy()} is  equivalent to \code{mdl$clone(deep = TRUE)}
#'
#' @examples
#' mdl <- islm_mdl("2017Q1/2019Q2")
#' mdl2 <- mdl$copy()
NULL

#' \code{\link{IsisMdl}} method: Fix variables to their current values
#' @name fix_variables
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} fixes the specified
#' model variables to their current values.
#' @section Usage:
#' \preformatted{
#' mdl$fix_variables(names, pattern, period = mdl$get_period())
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{pattern}}{a regular expression specifying the
#' variable names}
#' \item{\code{names}}{a character vector with variable names}
#' \item{\code{period}}{an \code{\link[regts]{period_range}} object or an
#' object that can be coerced to a \code{period_range}}
#' }
#'
#' @examples
#' mdl <- islm_mdl("2015Q2/2016Q3")
#' mdl$solve()
#'
#' # fix variable "c" for a specific period:
#' mdl$fix_variables(names = "c", period = "2015Q3/2015Q4")
#'
#' # fix all stochastic model variables
#' mdl$fix_variables(pattern = ".*")
#' @seealso \code{\link{set_fix}} and \code{\link{get_fix}}
NULL

#' \code{\link{IsisMdl}} method: R Sets the debug equation option
#' @name set_debug_eqn
#' @aliases get_debug_eqn
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} sets the
#' debug equation option (\code{TRUE} or \code{FALSE})
#'
#' Method \code{get_debug_eqn()} returns the debug equation option.
#' @section Usage:
#' \preformatted{
#' mdl$set_debug_eqn(value)
#'
#' mdl$get_debug_eqn()
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{value}}{A logical. If \code{TRUE}, then equation debugging
#' is turned on. The default is \code{FALSE}}
#' }
#'
#' @section Details:
#'
#' When a model cannot be solved this may be caused by errors in the
#' model equations or even errors in the initial data.
#' If debug mode is set to on, Isis will print messages in the
#' output file whenever it encounters numerical problems during calculation
#' of an equation.
#'
#' @examples
#' mdl <- islm_mdl()
#' mdl$set_debug_eqn(TRUE)
#'
#' print(mdl$get_debug_eqn())
NULL

#' \code{\link{IsisMdl}} method: orders the equations of a model

#' @name order
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} orders the equations of a model.
#' This can be useful after (de)activation equations.
#' By specifying argument \code{orfnam} it is also possible to write ordering
#' information to a file.
#' @section Usage:
#' \preformatted{
#' mdl$order(orfnam, silent = FALSE)
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#'
#' @section Arguments:
#'
#' \describe{
#' \item{\code{orfnam}}{Name of file on which to print ordering information.
#'   If no output file is specified no ordering information will
#'   be written}
#' \item{\code{silent}}{A logical (default \code{FALSE}). If \code{TRUE}, then
#' output is suppressed.}
#' }
NULL

#' \code{\link{IsisMdl}} method: Returns the model text file

#' @name get_text
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the model text,
#' i.e. the contents of the model file passed to function \code{\link{isis_mdl}}.
#' \cr
#' In principle, it is possible to remove the original model file after
#' the \code{IsisMdl} object has been created and saved to a file with method
#' \code{\link{write_mdl}}, since the model text used to create the model
#' is stored in this file. However, this is not a good idea if the
#' model contains preprocessor directives
#' (\code{#include} or \code{#if}). The current version of \code{isismdl}
#' does not handle preprocessor directives yet, but in future
#' versions \code{isismdl} will store the preprocessed model text (the model
#' text obtained by evaluating the preprocessor directives). \emph{Therefore,
#' we recomment to always keep the original model file}.
#' @section Usage:
#' \preformatted{
#' mdl$get_text()
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#' @examples
#' mdl <- islm_mdl()
#' cat(mdl$get_text())
NULL

#' \code{\link{IsisMdl}} method: Returns the last solve period

#' @name get_last_solve_period
#'
#' @description
#' This method of R6 class \code{\link{IsisMdl}} returns the last solve period,
#' i.e. the last period for which method \code{\link{solve}} attemted to
#' find a solution (whether succesful or not). The period is returned as a
#' \code{\link[regts]{period}} object. The function returns \code{NULL} when
#' method \code{solve} has not yet been used fot this \code{IsisMdl} object.
#' @section Usage:
#' \preformatted{
#' mdl$get_last_solve_period()
#'
#' }
#' \code{mdl} is an \code{\link{IsisMdl}} object
#' @examples
#' mdl <- islm_mdl(period = "2018q1/2018q4")$solve()
#' mdl$get_last_solve_period()
NULL

