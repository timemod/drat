## ----echo = FALSE, message = FALSE----------------------------------------------------------------
library(regts)
library(Hmisc)
library(readxl)
data <- matrix(c(3,2,4,3,5,2,5,3), ncol = 2)
data1 <- matrix(c(1,3,2,6,4,8,3,0,9), ncol = 3)

# input/output chunks are separated
# R inputlines start with >, outputlines with nothing
knitr::opts_chunk$set(collapse = FALSE, comment = "", prompt = TRUE)

# set options for page width = 100
options(width = 100)


## -------------------------------------------------------------------------------------------------
regm <- regts(1:24, start = "2016M1")
regm
aggregate(regm, FUN = mean, nfrequency = 4)

## -------------------------------------------------------------------------------------------------
regq <- regts(1:10, start = "2016q1")
regq
aggregate(regq, FUN = sum)

## -------------------------------------------------------------------------------------------------
regq2 <- regts(2:10, start = "2016q2")
regq2
aggregate(regq2, FUN = sum)

## -------------------------------------------------------------------------------------------------
tq2 <- ts(2:10, start = c(2016,2), frequency = 4)
tq2
aggregate(tq2, FUN = sum)

## ----eval = FALSE---------------------------------------------------------------------------------
#  xgrowth <- growth(regts(1:8, start = "2019q1"))
#  aggregate_gr(xgrowth, method = "rel")

## -------------------------------------------------------------------------------------------------
xdif <- diff(regts(1:8, start = "2019q1"))
xdif
aggregate_gr(xdif, method = "difmean")
aggregate_gr(xdif, method = "difsum")  

