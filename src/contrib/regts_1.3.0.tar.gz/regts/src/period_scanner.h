int prlex(void);
void init_period_scanner(const std::string &period_text);
