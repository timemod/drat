SEXP convert_mdl_file_c(SEXP filename, SEXP outputfile_, SEXP flags, 
                        SEXP include_dirs, SEXP options);
