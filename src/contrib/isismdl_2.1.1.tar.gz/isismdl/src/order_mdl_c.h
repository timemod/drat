SEXP order_mdl_c(SEXP model_index_, SEXP orfnam);
