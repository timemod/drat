SEXP get_fit_opts_c(SEXP model_index_);
