init_app <- function(session) {
  session$setInputs(table_desc = "")
  return(invisible())
}