int get_fit_repopt(const char *name, const char *repopt_text);
const char *get_fit_repopt_text(int repopt);

extern const char *FIT_PRICA_OPTS[];
extern const char *FIT_PRIJAC_OPTS[];
extern const char *FIT_SUPSOT_OPTS[];
