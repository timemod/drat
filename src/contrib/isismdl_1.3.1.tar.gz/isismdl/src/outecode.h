
void out_ecode(FILE *fp);
