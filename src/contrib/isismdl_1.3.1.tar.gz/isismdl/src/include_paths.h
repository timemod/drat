extern  void    set_standard_path(char *path);
extern  void    add_include_path(const char *path);
extern  char    *get_includefilename(char *includename);
extern  void    init_include_dirs(void);
