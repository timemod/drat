#ifndef INIT_H
#define INIT_H

void  mcinit( void );

extern  SymTab  *Stp;   /* pointer to Symbol table */

extern  SymTab  *Eqntp; /* pointer to symbol table
                         * for eqn names
                         */

#endif
