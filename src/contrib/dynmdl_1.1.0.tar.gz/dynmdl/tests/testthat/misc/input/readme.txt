ifn_input.csv is converted from ../dynare/ifn_input.xlsx, used in dynare.
