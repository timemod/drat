extend_path

%
% ifn does not have a steady state
%
dynare ifn_check noclearall

clean_dynare('ifn_check', 'temp', false)

