int run_dynare(char *modfile);
