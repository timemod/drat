library(testthat)
library(dynmdl)

test_check("dynmdl")
