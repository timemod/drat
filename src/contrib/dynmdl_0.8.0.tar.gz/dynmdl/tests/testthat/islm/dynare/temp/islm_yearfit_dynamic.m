function [residual, g1, g2, g3] = islm_yearfit_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           rows: equations in order of declaration
%                                                           columns: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(24, 1);
lhs =y(7);
rhs =y(10)+y(11)+x(it_, 1);
residual(1)= lhs-rhs;
lhs =y(8);
rhs =y(7)-y(9);
residual(2)= lhs-rhs;
lhs =y(9);
rhs =params(17)+y(7)*params(18)+y(15);
residual(3)= lhs-rhs;
lhs =y(10);
rhs =params(1)+params(2)*y(2)+y(8)*params(3)+params(4)*y(32)+params(5)*y(13)+params(6)*y(13)^2+y(16);
residual(4)= lhs-rhs;
lhs =y(11);
rhs =params(7)+params(8)*y(1)+y(7)*params(9)+params(10)*y(31)+y(13)*params(11)+y(13)^2*params(12)+y(17);
residual(5)= lhs-rhs;
lhs =y(12);
rhs =params(13)+y(7)*params(14)+y(13)*params(15)+y(13)^2*params(16)+y(18);
residual(6)= lhs-rhs;
lhs =y(12);
rhs =x(it_, 2);
residual(7)= lhs-rhs;
lhs =y(14);
rhs =0.25*(y(7)+y(1)+y(5)+y(6));
residual(8)= lhs-rhs;
lhs =y(15)/params(19)^2;
rhs =y(21);
residual(9)= lhs-rhs;
lhs =y(16)/params(20)^2;
rhs =y(22);
residual(10)= lhs-rhs;
lhs =y(17)/params(21)^2;
rhs =y(23);
residual(11)= lhs-rhs;
lhs =y(18)/params(22)^2;
rhs =y(24);
residual(12)= lhs-rhs;
residual(13) = x(it_, 3)*(y(14)-x(it_, 4))+(1-x(it_, 3))*(-y(26));
residual(14) = (-y(19))+y(20)+params(18)*y(21)+params(8)*y(34)+params(9)*y(23)+params(10)*y(4)+params(14)*y(24)+0.25*(y(26)+y(35)+y(36)+y(37));
residual(15) = (-y(20))+params(2)*y(33)+params(3)*y(22)+params(4)*y(3);
residual(16) = y(19)-y(22);
residual(17) = y(19)-y(23);
residual(18) = (-y(24))-y(25);
residual(19) = y(22)*(params(5)+y(13)*2*params(6))+y(23)*(params(11)+y(13)*2*params(12))+y(24)*(params(15)+y(13)*2*params(16));
residual(20) = (-y(20))-y(21);
lhs =y(27);
rhs =y(35);
residual(21)= lhs-rhs;
lhs =y(28);
rhs =y(36);
residual(22)= lhs-rhs;
lhs =y(29);
rhs =y(1);
residual(23)= lhs-rhs;
lhs =y(30);
rhs =y(5);
residual(24)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(24, 41);

  %
  % Jacobian matrix
  %

  g1(1,7)=1;
  g1(1,10)=(-1);
  g1(1,11)=(-1);
  g1(1,38)=(-1);
  g1(2,7)=(-1);
  g1(2,8)=1;
  g1(2,9)=1;
  g1(3,7)=(-params(18));
  g1(3,9)=1;
  g1(3,15)=(-1);
  g1(4,2)=(-params(2));
  g1(4,8)=(-params(3));
  g1(4,32)=(-params(4));
  g1(4,10)=1;
  g1(4,13)=(-(params(5)+params(6)*2*y(13)));
  g1(4,16)=(-1);
  g1(5,1)=(-params(8));
  g1(5,7)=(-params(9));
  g1(5,31)=(-params(10));
  g1(5,11)=1;
  g1(5,13)=(-(params(11)+params(12)*2*y(13)));
  g1(5,17)=(-1);
  g1(6,7)=(-params(14));
  g1(6,12)=1;
  g1(6,13)=(-(params(15)+params(16)*2*y(13)));
  g1(6,18)=(-1);
  g1(7,12)=1;
  g1(7,39)=(-1);
  g1(8,1)=(-0.25);
  g1(8,7)=(-0.25);
  g1(8,14)=1;
  g1(8,5)=(-0.25);
  g1(8,6)=(-0.25);
  g1(9,15)=1/params(19)^2;
  g1(9,21)=(-1);
  g1(10,16)=1/params(20)^2;
  g1(10,22)=(-1);
  g1(11,17)=1/params(21)^2;
  g1(11,23)=(-1);
  g1(12,18)=1/params(22)^2;
  g1(12,24)=(-1);
  g1(13,14)=x(it_, 3);
  g1(13,26)=(-(1-x(it_, 3)));
  g1(13,40)=y(14)-x(it_, 4)+y(26);
  g1(13,41)=(-x(it_, 3));
  g1(14,19)=(-1);
  g1(14,20)=1;
  g1(14,21)=params(18);
  g1(14,4)=params(10);
  g1(14,23)=params(9);
  g1(14,34)=params(8);
  g1(14,24)=params(14);
  g1(14,26)=0.25;
  g1(14,35)=0.25;
  g1(14,36)=0.25;
  g1(14,37)=0.25;
  g1(15,20)=(-1);
  g1(15,3)=params(4);
  g1(15,22)=params(3);
  g1(15,33)=params(2);
  g1(16,19)=1;
  g1(16,22)=(-1);
  g1(17,19)=1;
  g1(17,23)=(-1);
  g1(18,24)=(-1);
  g1(18,25)=(-1);
  g1(19,13)=y(22)*2*params(6)+y(23)*2*params(12)+y(24)*2*params(16);
  g1(19,22)=params(5)+y(13)*2*params(6);
  g1(19,23)=params(11)+y(13)*2*params(12);
  g1(19,24)=params(15)+y(13)*2*params(16);
  g1(20,20)=(-1);
  g1(20,21)=(-1);
  g1(21,35)=(-1);
  g1(21,27)=1;
  g1(22,36)=(-1);
  g1(22,28)=1;
  g1(23,1)=(-1);
  g1(23,29)=1;
  g1(24,5)=(-1);
  g1(24,30)=1;
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],24,1681);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],24,68921);
end
end
