function [residual, g1, g2, g3] = NK_baseline_simul_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           rows: equations in order of declaration
%                                                           columns: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(28, 1);
T14 = y(14)^(-1);
T35 = y(42)^(-1);
T54 = y(43)^(-1);
T55 = T35*params(2)*y(44)/y(17)*T54;
T66 = params(4)/2;
T70 = (1-params(5))*y(49)+y(46)*y(48)-(params(3)*(y(48)-1)+T66*(y(48)-1)^2);
T74 = params(6)/2;
T83 = 1-T74*(y(14)*y(21)/y(5)-params(26))^2;
T86 = y(21)*params(6)*(y(14)*y(21)/y(5)-params(26))/y(5);
T94 = params(6)*T35*y(44)*params(2)*y(49)/y(17);
T98 = y(42)*y(47)/y(21)-params(26);
T99 = T94*T98;
T100 = (y(42)*y(47)/y(21))^2;
T111 = (params(7)-1)/params(7)*y(27)^(1-params(7));
T123 = y(19)^params(11)/y(45);
T125 = params(2)*params(14)*T123^(1-params(7));
T128 = y(42)*y(51)/y(27);
T129 = T128^(params(7)-1);
T144 = y(28)^((-params(7))*(1+params(10)));
T146 = y(25)^(1+params(10));
T149 = params(2)*params(14)*T123^((-params(7))*(1+params(10)));
T151 = T128^(params(7)*(1+params(10)));
T165 = y(19)^params(12)/y(45);
T183 = y(29)*params(2)*params(13)*T165^(1-params(8))/y(52);
T197 = params(15)/(1-params(15));
T199 = y(26)*T197/y(20);
T204 = 1/(1-params(15));
T208 = T204^(1-params(15))*(1/params(15))^params(15);
T210 = T208*y(26)^(1-params(15));
T215 = y(4)^params(11);
T216 = T215/y(19);
T218 = params(14)*T216^(1-params(7));
T221 = T14*y(6)/y(26);
T222 = T221^(1-params(7));
T230 = y(4)^params(12)/y(19);
T243 = (y(3)/params(16))^params(18);
T247 = (y(19)/params(17))^params(19);
T253 = y(14)*y(32)/y(7)/exp(params(27));
T258 = (T247*T253^params(20))^(1-params(18));
T270 = params(3)*(y(22)-1)+T66*(y(22)-1)^2;
T279 = y(25)^(1-params(15));
T299 = T215*T221/y(19);
T362 = (y(22)*y(8))^params(15);
T386 = getPowerDeriv(y(13)-params(1)*y(2)*T14,(-1),1);
T391 = getPowerDeriv(y(41)*y(42)-y(13)*params(1),(-1),1);
T398 = getPowerDeriv(y(14),(-1),1);
T403 = 2*(y(14)*y(21)/y(5)-params(26));
T418 = getPowerDeriv(T221,1-params(7),1);
T426 = getPowerDeriv(T247*T253^params(20),1-params(18),1);
T442 = getPowerDeriv(T299,(-params(7)),1);
T456 = getPowerDeriv(y(42),(-1),1);
T476 = getPowerDeriv(T128,params(7)-1,1);
T481 = getPowerDeriv(T128,params(7)*(1+params(10)),1);
T562 = getPowerDeriv(y(4),params(12),1)/y(19);
T579 = getPowerDeriv(y(19),params(11),1)/y(45);
T593 = getPowerDeriv(y(19),params(12),1)/y(45);
T614 = (-(y(4)^params(12)))/(y(19)*y(19));
T642 = (-(y(19)^params(11)))/(y(45)*y(45));
T654 = (-(y(19)^params(12)))/(y(45)*y(45));
lhs =y(12)*(y(13)-params(1)*y(2)*T14)^(-1)-params(1)*params(2)*y(40)*(y(41)*y(42)-y(13)*params(1))^(-1);
rhs =y(17);
residual(1)= lhs-rhs;
lhs =y(17);
rhs =params(2)*y(44)*T35/y(45)*y(18);
residual(2)= lhs-rhs;
lhs =y(20);
rhs =params(3)+params(4)*(y(22)-1);
residual(3)= lhs-rhs;
lhs =y(23);
rhs =T55*T70;
residual(4)= lhs-rhs;
lhs =1;
rhs =y(23)*(T83-y(14)*T86)+T99*T100;
residual(5)= lhs-rhs;
lhs =y(24);
rhs =y(17)*T111*y(26)^params(7)*y(25)+T125*T129*y(50);
residual(6)= lhs-rhs;
lhs =y(24);
rhs =y(12)*params(9)*y(38)*T144*T146+y(50)*T149*T151;
residual(7)= lhs-rhs;
lhs =y(30);
rhs =y(17)*y(33)*y(32)+params(2)*params(13)*T165^(-params(8))*y(53);
residual(8)= lhs-rhs;
lhs =y(31);
rhs =y(32)*y(17)*y(29)+T183*y(54);
residual(9)= lhs-rhs;
lhs =y(30)*params(8);
rhs =y(31)*(params(8)-1);
residual(10)= lhs-rhs;
lhs =y(22)*y(8)/y(25);
rhs =y(14)*T199*y(15);
residual(11)= lhs-rhs;
lhs =y(33);
rhs =T210*y(20)^params(15);
residual(12)= lhs-rhs;
lhs =1;
rhs =T218*T222+(1-params(14))*y(28)^(1-params(7));
residual(13)= lhs-rhs;
lhs =1;
rhs =params(13)*T230^(1-params(8))+(1-params(13))*y(29)^(1-params(8));
residual(14)= lhs-rhs;
lhs =y(18)/params(16);
rhs =T243*T258*exp(x(it_, 5));
residual(15)= lhs-rhs;
lhs =y(32);
rhs =y(13)+y(21)+T14*y(15)^(-1)*T270*y(8);
residual(16)= lhs-rhs;
lhs =y(32);
rhs =(T279*T14*y(16)*T362-params(21))/y(35);
residual(17)= lhs-rhs;
lhs =y(37);
rhs =y(25)*y(36);
residual(18)= lhs-rhs;
lhs =y(35);
rhs =params(13)*T230^(-params(8))*y(9)+(1-params(13))*y(29)^(-params(8));
residual(19)= lhs-rhs;
lhs =y(36);
rhs =params(14)*T299^(-params(7))*y(10)+(1-params(14))*y(28)^(-params(7));
residual(20)= lhs-rhs;
residual(21) = y(15)*y(14)*y(34)-(1-params(5))*y(8)-y(21)*T83*y(14)*y(15);
lhs =y(39);
rhs =y(32)-y(25)*y(26)*T204;
residual(22)= lhs-rhs;
lhs =y(28);
rhs =y(27)/y(26);
residual(23)= lhs-rhs;
lhs =log(y(12));
rhs =params(22)*log(y(1))+x(it_, 1);
residual(24)= lhs-rhs;
lhs =log(y(38));
rhs =params(23)*log(y(11))+x(it_, 2);
residual(25)= lhs-rhs;
lhs =log(y(15));
rhs =params(24)+x(it_, 3);
residual(26)= lhs-rhs;
lhs =log(y(16));
rhs =params(25)+x(it_, 4);
residual(27)= lhs-rhs;
lhs =y(14);
rhs =y(16)^T204*y(15)^T197;
residual(28)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(28, 59);

  %
  % Jacobian matrix
  %

  g1(1,12)=(y(13)-params(1)*y(2)*T14)^(-1);
  g1(1,40)=(-(params(1)*params(2)*(y(41)*y(42)-y(13)*params(1))^(-1)));
  g1(1,2)=y(12)*(-(params(1)*T14))*T386;
  g1(1,13)=y(12)*T386-params(1)*params(2)*y(40)*(-params(1))*T391;
  g1(1,41)=(-(params(1)*params(2)*y(40)*y(42)*T391));
  g1(1,14)=y(12)*T386*(-(params(1)*y(2)*T398));
  g1(1,42)=(-(params(1)*params(2)*y(40)*y(41)*T391));
  g1(1,17)=(-1);
  g1(2,42)=(-(y(18)*params(2)*y(44)*T456/y(45)));
  g1(2,17)=1;
  g1(2,44)=(-(y(18)*params(2)*T35/y(45)));
  g1(2,18)=(-(params(2)*y(44)*T35/y(45)));
  g1(2,45)=(-(y(18)*(-(params(2)*y(44)*T35))/(y(45)*y(45))));
  g1(3,20)=1;
  g1(3,22)=(-params(4));
  g1(4,42)=(-(T70*T54*params(2)*y(44)/y(17)*T456));
  g1(4,43)=(-(T70*T35*params(2)*y(44)/y(17)*getPowerDeriv(y(43),(-1),1)));
  g1(4,17)=(-(T70*T54*T35*(-(params(2)*y(44)))/(y(17)*y(17))));
  g1(4,44)=(-(T70*T54*T35*params(2)/y(17)));
  g1(4,46)=(-(T55*y(48)));
  g1(4,48)=(-(T55*(y(46)-(params(3)+T66*2*(y(48)-1)))));
  g1(4,23)=1;
  g1(4,49)=(-(T55*(1-params(5))));
  g1(5,14)=(-(y(23)*((-(T74*y(21)/y(5)*T403))-(T86+y(14)*y(21)*params(6)*y(21)/y(5)/y(5)))));
  g1(5,42)=(-(T100*(T98*params(6)*y(44)*params(2)*y(49)/y(17)*T456+T94*y(47)/y(21))+T99*y(47)/y(21)*2*y(42)*y(47)/y(21)));
  g1(5,17)=(-(T100*T98*params(6)*T35*(-(y(44)*params(2)*y(49)))/(y(17)*y(17))));
  g1(5,44)=(-(T100*T98*params(6)*T35*params(2)*y(49)/y(17)));
  g1(5,5)=(-(y(23)*((-(T74*T403*y(14)*(-y(21))/(y(5)*y(5))))-y(14)*(y(5)*y(21)*params(6)*y(14)*(-y(21))/(y(5)*y(5))-y(21)*params(6)*(y(14)*y(21)/y(5)-params(26)))/(y(5)*y(5)))));
  g1(5,21)=(-(y(23)*((-(T74*T403*y(14)*1/y(5)))-y(14)*(params(6)*(y(14)*y(21)/y(5)-params(26))+y(21)*params(6)*y(14)*1/y(5))/y(5))+T100*T94*y(42)*(-y(47))/(y(21)*y(21))+T99*2*y(42)*y(47)/y(21)*y(42)*(-y(47))/(y(21)*y(21))));
  g1(5,47)=(-(T100*T94*y(42)*1/y(21)+T99*2*y(42)*y(47)/y(21)*y(42)*1/y(21)));
  g1(5,23)=(-(T83-y(14)*T86));
  g1(5,49)=(-(T100*T98*T35*params(2)*y(44)/y(17)*params(6)));
  g1(6,42)=(-(y(50)*T125*y(51)/y(27)*T476));
  g1(6,17)=(-(y(25)*T111*y(26)^params(7)));
  g1(6,19)=(-(y(50)*T129*params(2)*params(14)*T579*getPowerDeriv(T123,1-params(7),1)));
  g1(6,45)=(-(y(50)*T129*params(2)*params(14)*getPowerDeriv(T123,1-params(7),1)*T642));
  g1(6,24)=1;
  g1(6,50)=(-(T125*T129));
  g1(6,25)=(-(y(17)*T111*y(26)^params(7)));
  g1(6,26)=(-(y(25)*y(17)*T111*getPowerDeriv(y(26),params(7),1)));
  g1(6,27)=(-(y(25)*y(26)^params(7)*y(17)*(params(7)-1)/params(7)*getPowerDeriv(y(27),1-params(7),1)+y(50)*T125*T476*y(42)*(-y(51))/(y(27)*y(27))));
  g1(6,51)=(-(y(50)*T125*T476*y(42)*1/y(27)));
  g1(7,12)=(-(T146*T144*params(9)*y(38)));
  g1(7,42)=(-(y(50)*T149*y(51)/y(27)*T481));
  g1(7,19)=(-(y(50)*T151*params(2)*params(14)*T579*getPowerDeriv(T123,(-params(7))*(1+params(10)),1)));
  g1(7,45)=(-(y(50)*T151*params(2)*params(14)*getPowerDeriv(T123,(-params(7))*(1+params(10)),1)*T642));
  g1(7,24)=1;
  g1(7,50)=(-(T149*T151));
  g1(7,25)=(-(y(12)*params(9)*y(38)*T144*getPowerDeriv(y(25),1+params(10),1)));
  g1(7,27)=(-(y(50)*T149*T481*y(42)*(-y(51))/(y(27)*y(27))));
  g1(7,51)=(-(y(50)*T149*T481*y(42)*1/y(27)));
  g1(7,28)=(-(T146*y(12)*params(9)*y(38)*getPowerDeriv(y(28),(-params(7))*(1+params(10)),1)));
  g1(7,38)=(-(T146*y(12)*params(9)*T144));
  g1(8,17)=(-(y(33)*y(32)));
  g1(8,19)=(-(y(53)*params(2)*params(13)*T593*getPowerDeriv(T165,(-params(8)),1)));
  g1(8,45)=(-(y(53)*params(2)*params(13)*getPowerDeriv(T165,(-params(8)),1)*T654));
  g1(8,30)=1;
  g1(8,53)=(-(params(2)*params(13)*T165^(-params(8))));
  g1(8,32)=(-(y(17)*y(33)));
  g1(8,33)=(-(y(17)*y(32)));
  g1(9,17)=(-(y(32)*y(29)));
  g1(9,19)=(-(y(54)*y(29)*params(2)*params(13)*T593*getPowerDeriv(T165,1-params(8),1)/y(52)));
  g1(9,45)=(-(y(54)*y(29)*params(2)*params(13)*getPowerDeriv(T165,1-params(8),1)*T654/y(52)));
  g1(9,29)=(-(y(17)*y(32)+y(54)*params(2)*params(13)*T165^(1-params(8))/y(52)));
  g1(9,52)=(-(y(54)*(-(y(29)*params(2)*params(13)*T165^(1-params(8))))/(y(52)*y(52))));
  g1(9,31)=1;
  g1(9,54)=(-T183);
  g1(9,32)=(-(y(17)*y(29)));
  g1(10,30)=params(8);
  g1(10,31)=(-(params(8)-1));
  g1(11,14)=(-(T199*y(15)));
  g1(11,15)=(-(y(14)*T199));
  g1(11,20)=(-(y(15)*y(14)*(-(y(26)*T197))/(y(20)*y(20))));
  g1(11,22)=y(8)/y(25);
  g1(11,25)=(-(y(22)*y(8)))/(y(25)*y(25));
  g1(11,26)=(-(y(15)*y(14)*T197/y(20)));
  g1(11,8)=y(22)/y(25);
  g1(12,20)=(-(T210*getPowerDeriv(y(20),params(15),1)));
  g1(12,26)=(-(y(20)^params(15)*T208*getPowerDeriv(y(26),1-params(15),1)));
  g1(12,33)=1;
  g1(13,14)=(-(T218*y(6)/y(26)*T398*T418));
  g1(13,4)=(-(T222*params(14)*getPowerDeriv(y(4),params(11),1)/y(19)*getPowerDeriv(T216,1-params(7),1)));
  g1(13,19)=(-(T222*params(14)*getPowerDeriv(T216,1-params(7),1)*(-T215)/(y(19)*y(19))));
  g1(13,6)=(-(T218*T418*T14*1/y(26)));
  g1(13,26)=(-(T218*T418*T14*(-y(6))/(y(26)*y(26))));
  g1(13,28)=(-((1-params(14))*getPowerDeriv(y(28),1-params(7),1)));
  g1(14,4)=(-(params(13)*T562*getPowerDeriv(T230,1-params(8),1)));
  g1(14,19)=(-(params(13)*getPowerDeriv(T230,1-params(8),1)*T614));
  g1(14,29)=(-((1-params(13))*getPowerDeriv(y(29),1-params(8),1)));
  g1(15,14)=(-(exp(x(it_, 5))*T243*T247*y(32)/y(7)/exp(params(27))*getPowerDeriv(T253,params(20),1)*T426));
  g1(15,3)=(-(exp(x(it_, 5))*T258*1/params(16)*getPowerDeriv(y(3)/params(16),params(18),1)));
  g1(15,18)=1/params(16);
  g1(15,19)=(-(exp(x(it_, 5))*T243*T426*T253^params(20)*1/params(17)*getPowerDeriv(y(19)/params(17),params(19),1)));
  g1(15,7)=(-(exp(x(it_, 5))*T243*T426*T247*getPowerDeriv(T253,params(20),1)*y(14)*(-y(32))/(y(7)*y(7))/exp(params(27))));
  g1(15,32)=(-(exp(x(it_, 5))*T243*T426*T247*getPowerDeriv(T253,params(20),1)*y(14)*1/y(7)/exp(params(27))));
  g1(15,59)=(-(T243*T258*exp(x(it_, 5))));
  g1(16,13)=(-1);
  g1(16,14)=(-(y(8)*T270*y(15)^(-1)*T398));
  g1(16,15)=(-(y(8)*T270*T14*getPowerDeriv(y(15),(-1),1)));
  g1(16,21)=(-1);
  g1(16,22)=(-(y(8)*T14*y(15)^(-1)*(params(3)+T66*2*(y(22)-1))));
  g1(16,32)=1;
  g1(16,8)=(-(T14*y(15)^(-1)*T270));
  g1(17,14)=(-(T279*T362*y(16)*T398/y(35)));
  g1(17,16)=(-(T279*T14*T362/y(35)));
  g1(17,22)=(-(T279*T14*y(16)*y(8)*getPowerDeriv(y(22)*y(8),params(15),1)/y(35)));
  g1(17,25)=(-(T14*y(16)*T362*getPowerDeriv(y(25),1-params(15),1)/y(35)));
  g1(17,32)=1;
  g1(17,8)=(-(T279*T14*y(16)*y(22)*getPowerDeriv(y(22)*y(8),params(15),1)/y(35)));
  g1(17,35)=(-((-(T279*T14*y(16)*T362-params(21)))/(y(35)*y(35))));
  g1(18,25)=(-y(36));
  g1(18,36)=(-y(25));
  g1(18,37)=1;
  g1(19,4)=(-(y(9)*params(13)*T562*getPowerDeriv(T230,(-params(8)),1)));
  g1(19,19)=(-(y(9)*params(13)*getPowerDeriv(T230,(-params(8)),1)*T614));
  g1(19,29)=(-((1-params(13))*getPowerDeriv(y(29),(-params(8)),1)));
  g1(19,9)=(-(params(13)*T230^(-params(8))));
  g1(19,35)=1;
  g1(20,14)=(-(y(10)*params(14)*T215*y(6)/y(26)*T398/y(19)*T442));
  g1(20,4)=(-(y(10)*params(14)*T442*T221*getPowerDeriv(y(4),params(11),1)/y(19)));
  g1(20,19)=(-(y(10)*params(14)*T442*(-(T215*T221))/(y(19)*y(19))));
  g1(20,6)=(-(y(10)*params(14)*T442*T215*T14*1/y(26)/y(19)));
  g1(20,26)=(-(y(10)*params(14)*T442*T215*T14*(-y(6))/(y(26)*y(26))/y(19)));
  g1(20,28)=(-((1-params(14))*getPowerDeriv(y(28),(-params(7)),1)));
  g1(20,10)=(-(params(14)*T299^(-params(7))));
  g1(20,36)=1;
  g1(21,14)=y(34)*y(15)-y(21)*(y(14)*y(15)*(-(T74*y(21)/y(5)*T403))+T83*y(15));
  g1(21,15)=y(14)*y(34)-y(21)*y(14)*T83;
  g1(21,5)=(-(y(21)*y(14)*y(15)*(-(T74*T403*y(14)*(-y(21))/(y(5)*y(5))))));
  g1(21,21)=(-(T83*y(14)*y(15)+y(21)*y(14)*y(15)*(-(T74*T403*y(14)*1/y(5)))));
  g1(21,8)=(-(1-params(5)));
  g1(21,34)=y(14)*y(15);
  g1(22,25)=y(26)*T204;
  g1(22,26)=y(25)*T204;
  g1(22,32)=(-1);
  g1(22,39)=1;
  g1(23,26)=(-((-y(27))/(y(26)*y(26))));
  g1(23,27)=(-(1/y(26)));
  g1(23,28)=1;
  g1(24,1)=(-(params(22)*1/y(1)));
  g1(24,12)=1/y(12);
  g1(24,55)=(-1);
  g1(25,11)=(-(params(23)*1/y(11)));
  g1(25,38)=1/y(38);
  g1(25,56)=(-1);
  g1(26,15)=1/y(15);
  g1(26,57)=(-1);
  g1(27,16)=1/y(16);
  g1(27,58)=(-1);
  g1(28,14)=1;
  g1(28,15)=(-(y(16)^T204*getPowerDeriv(y(15),T197,1)));
  g1(28,16)=(-(y(15)^T197*getPowerDeriv(y(16),T204,1)));
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],28,3481);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],28,205379);
end
end
