function [residual, g1, g2] = islm_fit_exolag1_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                     columns: variables in declaration order
%                                                     rows: equations in order of declaration
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: variables in declaration order
%                                                       rows: equations in order of declaration
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 18, 1);

%
% Model equations
%

lhs =y(7);
rhs =params(21)+params(22)*y(1)+y(8);
residual(1)= lhs-rhs;
lhs =y(1);
rhs =y(3)+y(4)+x(1);
residual(2)= lhs-rhs;
lhs =y(2);
rhs =y(1)-y(7);
residual(3)= lhs-rhs;
lhs =y(3);
rhs =params(5)+y(2)*params(6)+y(2)*params(7)+y(2)*params(8)+params(9)*y(6)+params(10)*y(6)^2+y(9);
residual(4)= lhs-rhs;
lhs =y(4);
rhs =y(9)+params(11)+y(1)*params(12)+y(1)*params(13)+y(1)*params(14)+y(6)*params(15)+y(6)^2*params(16)+y(11);
residual(5)= lhs-rhs;
lhs =y(5);
rhs =params(17)+y(1)*params(18)+y(6)*params(19)+y(6)^2*params(20)+y(10);
residual(6)= lhs-rhs;
lhs =y(5);
rhs =x(2);
residual(7)= lhs-rhs;
residual(8) = (params(1)>=0)*(y(8)/params(1)^2-y(12))+(params(1)<0)*(y(8)-x(17));
residual(9) = (params(2)>=0)*(y(9)/params(2)^2-y(15)-y(16))+(params(2)<0)*(y(9)-x(18));
residual(10) = (params(4)>=0)*(y(10)/params(4)^2-y(17))+(params(4)<0)*(y(10)-x(19));
residual(11) = (params(3)>=0)*(y(11)/params(3)^2-y(16))+(params(3)<0)*(y(11)-x(20));
residual(12) = x(3)*(y(1)-x(10))+(1-x(3))*(y(16)*(-params(12))+y(12)*(-params(22))+y(13)-y(14)+y(16)*(-params(13))+y(17)*(-params(18))+y(16)*(-params(14)));
residual(13) = x(4)*(y(2)-x(11))+(1-x(4))*(y(14)+y(15)*(-params(6))+y(15)*(-params(7))+y(15)*(-params(8)));
residual(14) = x(5)*(y(3)-x(12))+(1-x(5))*(y(15)-y(13));
residual(15) = x(6)*(y(4)-x(13))+(1-x(6))*(y(16)-y(13));
residual(16) = x(7)*(y(5)-x(14))+(1-x(7))*(y(17)+y(18));
residual(17) = x(8)*(y(6)-x(15))+(1-x(8))*(y(15)*(-(params(9)+y(6)*2*params(10)))+y(16)*(-(params(15)+y(6)*2*params(16)))+y(17)*(-(params(19)+y(6)*2*params(20))));
residual(18) = x(9)*(y(7)-x(16))+(1-x(9))*(y(12)+y(14));
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(18, 18);

  %
  % Jacobian matrix
  %

  g1(1,1)=(-params(22));
  g1(1,7)=1;
  g1(1,8)=(-1);
  g1(2,1)=1;
  g1(2,3)=(-1);
  g1(2,4)=(-1);
  g1(3,1)=(-1);
  g1(3,2)=1;
  g1(3,7)=1;
  g1(4,2)=(-(params(8)+params(6)+params(7)));
  g1(4,3)=1;
  g1(4,6)=(-(params(9)+params(10)*2*y(6)));
  g1(4,9)=(-1);
  g1(5,1)=(-(params(14)+params(12)+params(13)));
  g1(5,4)=1;
  g1(5,6)=(-(params(15)+params(16)*2*y(6)));
  g1(5,9)=(-1);
  g1(5,11)=(-1);
  g1(6,1)=(-params(18));
  g1(6,5)=1;
  g1(6,6)=(-(params(19)+params(20)*2*y(6)));
  g1(6,10)=(-1);
  g1(7,5)=1;
  g1(8,8)=(params(1)<0)+(params(1)>=0)*1/params(1)^2;
  g1(8,12)=(-(params(1)>=0));
  g1(9,9)=(params(2)<0)+(params(2)>=0)*1/params(2)^2;
  g1(9,15)=(-(params(2)>=0));
  g1(9,16)=(-(params(2)>=0));
  g1(10,10)=(params(4)<0)+(params(4)>=0)*1/params(4)^2;
  g1(10,17)=(-(params(4)>=0));
  g1(11,11)=(params(3)<0)+(params(3)>=0)*1/params(3)^2;
  g1(11,16)=(-(params(3)>=0));
  g1(12,1)=x(3);
  g1(12,12)=(1-x(3))*(-params(22));
  g1(12,13)=1-x(3);
  g1(12,14)=(-(1-x(3)));
  g1(12,16)=(1-x(3))*((-params(12))-params(13)-params(14));
  g1(12,17)=(1-x(3))*(-params(18));
  g1(13,2)=x(4);
  g1(13,14)=1-x(4);
  g1(13,15)=(1-x(4))*((-params(6))-params(7)-params(8));
  g1(14,3)=x(5);
  g1(14,13)=(-(1-x(5)));
  g1(14,15)=1-x(5);
  g1(15,4)=x(6);
  g1(15,13)=(-(1-x(6)));
  g1(15,16)=1-x(6);
  g1(16,5)=x(7);
  g1(16,17)=1-x(7);
  g1(16,18)=1-x(7);
  g1(17,6)=x(8)+(1-x(8))*(y(15)*(-(2*params(10)))+y(16)*(-(2*params(16)))+y(17)*(-(2*params(20))));
  g1(17,15)=(1-x(8))*(-(params(9)+y(6)*2*params(10)));
  g1(17,16)=(1-x(8))*(-(params(15)+y(6)*2*params(16)));
  g1(17,17)=(1-x(8))*(-(params(19)+y(6)*2*params(20)));
  g1(18,7)=x(9);
  g1(18,12)=1-x(9);
  g1(18,14)=1-x(9);
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],18,324);
end
end
