function y = islm_var2_simul_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(16)=y(2);
y(17)=y(16);
y(18)=y(13);
y(19)=y(18);
y(20)=y(19);
y(21)=y(12);
y(22)=y(21);
y(23)=y(2);
y(24)=y(23);
y(25)=y(1);
y(26)=y(25);
y(27)=y(26);
y(28)=y(12);
y(29)=y(28);
