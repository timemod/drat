extern void F77_SUB(init_get_options)(int *model_index);
