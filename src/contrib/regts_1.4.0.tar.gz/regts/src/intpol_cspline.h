int intpol_cspline(int n, int nnew, double x[], double y[],
                   double xnew[], double ynew[], char conds, 
                   double *work[4]);

