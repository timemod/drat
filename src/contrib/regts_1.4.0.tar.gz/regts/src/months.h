int get_month_number(const char *name);
