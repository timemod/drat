library(testthat)
library(isismdl)
library(tibble)

rm(list = ls())

test_that("solve_exo solves exogenous variables for a simple model", {
  mdl_content <- c(
    "ident x1 = 0.5 * x1(-1) + 0.3 * y1;",
    "ident x2 = 0.6 * x2(-1) + 0.4 * y2;",
    "ident x3 = 0.4 * x3(-1) + 0.2 * y3;",
    "ident obs1 = 2.0 * x1;",
    "ident obs2 = 1.5 * x2;",
    "ident obs3 = 1.2 * x3;"
  )

  mdl <- isismdl::isis_mdl(model_text = mdl_content, period = "2019/2020", silent = TRUE)
  mdl$set_values(10, names = "x1", period = "2019")
  mdl$set_values(20, names = "x2", period = "2019")
  mdl$set_values(30, names = "x3", period = "2019")

  mdl$set_values(50, names = "obs1", period = "2020")
  mdl$set_values(60, names = "obs2", period = "2020")
  mdl$set_values(70, names = "obs3", period = "2020")

  target_obs <- c(50, 60, 70)

  solve_period <- "2020"

  exo_vars <- c("y1", "y2", "y3")
  target_vars <- c("obs1", "obs2", "obs3")

  res <- mdl$solve_exo(
    solve_period = solve_period,
    exo_vars = exo_vars,
    target_vars = target_vars,
    report = "no",
    jacobian = FALSE
  )

  mdl$run_eqn(period = "2020", solve_order = TRUE)

  model_obs <- mdl$get_data(
    names = c("obs1", "obs2", "obs3"),
    period = "2020"
  )

  expect_true(all(abs(as.numeric(model_obs) - target_obs) < 1e-6))

  solved_y <- mdl$get_data(names = exo_vars, period = "2020")
  expect_false(any(is.na(solved_y)))
  expect_true(all(is.finite(solved_y)))
})

test_that("solve_exo errors when target variables contain NA", {
  mdl_content <- c(
    "ident x1 = 0.5 * x1(-1) + 0.3 * y1;",
    "ident obs1 = 2.0 * x1;"
  )

  mdl <- isismdl::isis_mdl(model_text = mdl_content, period = "2019/2020", silent = TRUE)

  mdl$set_values(10, names = "x1", period = "2019")

  expect_error(
    mdl$solve_exo(
      solve_period = "2020",
      exo_vars = "y1",
      target_vars = "obs1",
      report = "none"
    ),
    regexp = "target variables contain NA values"
  )
})

test_that("solve_exo solves for a period range", {
  mdl_content <- c(
    "ident x = y;",
    "ident obs = 2 * x;"
  )

  mdl <- isismdl::isis_mdl(model_text = mdl_content, period = "2020Q1/2020Q2", silent = TRUE)

  # Set target values for two quarters
  mdl$set_values(c(100, 200), names = "obs", period = "2020Q1/2020Q2")

  # Solve for the range
  mdl$solve_exo(
    solve_period = "2020Q1/2020Q2",
    exo_vars = "y",
    target_vars = "obs",
    report = "none"
  )

  # Verify values in both quarters
  data <- mdl$get_data(names = c("y", "obs"), period = "2020Q1/2020Q2")
  expect_equal(as.numeric(data[, "y"]), c(50, 100))
  expect_equal(as.numeric(data[, "obs"]), c(100, 200))
})

test_that("solve_exo errors when model has feedback variables", {
  mdl_content <- c(
    "ident x = 0.5 * x + y;",
    "ident obs = x;"
  )

  mdl <- isismdl::isis_mdl(model_text = mdl_content, period = "2020", silent = TRUE)
  mdl$set_values(100, names = "obs", period = "2020")

  expect_error(
    mdl$solve_exo(
      solve_period = "2020",
      exo_vars = "y",
      target_vars = "obs",
      report = "none"
    ),
    regexp = "solve_exo does not support models with feedback variables"
  )
})

test_that("solve_exo errors when target_vars are not endogenous", {
  mdl <- isis_mdl(model_text = "ident x = y;", period = "2020", silent = TRUE)

  expect_error(
    mdl$solve_exo(exo_vars = "y", target_vars = "y", report = "none"),
    regexp = "The following target variables are not active endogenous: y"
  )
  expect_error(
    mdl$solve_exo(exo_vars = "y", target_vars = "non_existent", report = "none"),
    regexp = "The following target variables are not active endogenous: non_existent"
  )
})

test_that("solve_exo errors when exo_vars are not exogenous", {
  mdl_content <- c(
    "ident x = y;",
    "ident z = x;"
  )
  mdl <- isis_mdl(model_text = mdl_content, period = "2020", silent = TRUE)
  expect_error(
    mdl$solve_exo(exo_vars = "x", target_vars = "z", report = "none"),
    regexp = "The following variables in 'exo_vars' are not exogenous: x"
  )
  expect_error(
    mdl$solve_exo(exo_vars = "non_existent", target_vars = "z", report = "none"),
    regexp = "The following variables in 'exo_vars' are not exogenous: non_existent"
  )
})

# --- jacob field tests -------------------------------------------------------

test_that("solve_exo: jacob is NULL when jacobian = FALSE", {
  mdl_content <- c(
    "ident x = y;",
    "ident obs = 2 * x;"
  )
  mdl <- isis_mdl(model_text = mdl_content, period = "2020", silent = TRUE)
  mdl$set_values(100, names = "obs", period = "2020")

  mdl$solve_exo(
    solve_period = "2020",
    exo_vars = "y",
    target_vars = "obs",
    report = "none",
    jacobian = FALSE
  )

  expect_null(mdl$get_jacobian())
})

test_that("solve_exo: jacob is a matrix with correct dims when jacobian = TRUE", {
  mdl_content <- c(
    "ident x1 = y1;",
    "ident x2 = y2;",
    "ident obs1 = 2 * x1;",
    "ident obs2 = 3 * x2;"
  )
  mdl <- isis_mdl(model_text = mdl_content, period = "2020", silent = TRUE)
  mdl$set_values(100, names = "obs1", period = "2020")
  mdl$set_values(150, names = "obs2", period = "2020")

  mdl$solve_exo(
    solve_period = "2020",
    exo_vars   = c("y1", "y2"),
    target_vars = c("obs1", "obs2"),
    report = "none",
    jacobian = TRUE
  )

  jac <- mdl$get_jacobian()
  expect_true(is.matrix(jac))
  expect_equal(dim(jac), c(2L, 2L))
  expect_equal(rownames(jac), c("obs1", "obs2"))
  expect_equal(colnames(jac), c("y1", "y2"))
})

test_that("solve_exo: jacob is updated on repeated calls", {
  mdl_content <- c(
    "ident x = y;",
    "ident obs = 2 * x;"
  )
  mdl <- isis_mdl(model_text = mdl_content, period = "2020/2021", silent = TRUE)
  mdl$set_values(c(100, 200), names = "obs", period = "2020/2021")

  # First call: single period
  mdl$solve_exo(
    solve_period = "2020",
    exo_vars = "y",
    target_vars = "obs",
    report = "none",
    jacobian = TRUE
  )
  jac1 <- mdl$get_jacobian()

  # Second call: period range — jacob reflects last period solved
  mdl$solve_exo(
    solve_period = "2020/2021",
    exo_vars = "y",
    target_vars = "obs",
    report = "none",
    jacobian = TRUE
  )
  jac2 <- mdl$get_jacobian()

  expect_true(is.matrix(jac1))
  expect_true(is.matrix(jac2))
  # Both are 1x1 but from different periods; values may differ
  expect_equal(dim(jac1), c(1L, 1L))
  expect_equal(dim(jac2), c(1L, 1L))
})

test_that("solve_exo: jacobian = TRUE does NOT print anything", {
  mdl_content <- c(
    "ident x = y;",
    "ident obs = 2 * x;"
  )
  mdl <- isis_mdl(model_text = mdl_content, period = "2020", silent = TRUE)
  mdl$set_values(100, names = "obs", period = "2020")

  output <- capture.output(
    mdl$solve_exo(
      solve_period = "2020",
      exo_vars = "y",
      target_vars = "obs",
      report = "none",
      jacobian = TRUE
    )
  )

  expect_false(any(grepl("jacobian", output, ignore.case = TRUE)))
})

test_that("solve_exo returns jacobian and updates status on failure", {
  # Use a non-solvable model to force failure (x = exp(y), target x = -1)
  mdl_content <- c(
    "ident x = exp(y);",
    "ident obs = x;"
  )
  mdl <- isis_mdl(model_text = mdl_content, period = "2020", silent = TRUE)
  mdl$set_values(-1, names = "obs", period = "2020")
  mdl$set_values(0, names = "y", period = "2020")

  expect_warning(
    mdl$solve_exo(
      solve_period = "2020",
      exo_vars = "y",
      target_vars = "obs",
      report = "none",
      jacobian = TRUE
    ),
    "solve_exo_internal: Failed to solve exogenous variables"
  )

  expect_equal(mdl$get_solve_status(), "Simulation stopped")
  expect_false(is.null(mdl$get_jacobian()))
  expect_true(is.matrix(mdl$get_jacobian()))
})


test_that("solve_exo duplicate names", {
  mdl_content <- c(
    "ident x1 = 0.5 * x1(-1) + 0.3 * y1;",
    "ident x2 = 0.6 * x2(-1) + 0.4 * y2;",
    "ident x3 = 0.4 * x3(-1) + 0.2 * y3;",
    "ident obs1 = 2.0 * x1;",
    "ident obs2 = 1.5 * x2;",
    "ident obs3 = 1.2 * x3;"
  )

  mdl <- isismdl::isis_mdl(model_text = mdl_content, period = "2019/2020", silent = TRUE)
  solve_period <- "2020"

  # duplicate exo_vars ----
  exo_vars <- c("y1", "y2", "y3", "y3")
  target_vars <- c("obs1", "obs2", "obs3", "obs4")

  emsg <- "'exo_vars' must have unique names, but contains duplicates:
y3."
  expect_error(
    mdl$solve_exo(
      solve_period = solve_period,
      exo_vars = exo_vars,
      target_vars = target_vars
    ),
    emsg,
    fixed = TRUE
  )

  # duplicate target_vars ----
  exo_vars <- c("y1", "y2", "y3", "y4", "y5")
  target_vars <- c("obs1", "obs2", "obs3", "obs1", "obs2")

  emsg <- "'target_vars' must have unique names, but contains duplicates:
obs1, obs2"
  expect_error(
    mdl$solve_exo(
      solve_period = solve_period,
      exo_vars = exo_vars,
      target_vars = target_vars
    ),
    emsg,
    fixed = TRUE
  )

  # wrong argument type ----
  exo_vars <- 1:5
  expect_error(
    mdl$solve_exo(
      solve_period = solve_period,
      exo_vars = exo_vars,
      target_vars = target_vars
    ),
    "'exo_vars' is not a character vector",
    fixed = TRUE
  )

})
