#' Solves multiple groups of derived variables with the accompanying
#' observed variables
#'
#' @param mdl A reference to an `IsisMdl` object.
#' @param period A `period_range` object for the overall solve.
#' @param solve_df A data frame with solve instructions.
#' @param report String ('no', 'period', or 'all') describing the level of reporting.
#' @param default_initial_guess Numeric. The default initial guess if not specified in `solve_df`.
#' @param jacobian Logical. Whether the final estimated Jacobian should be returned.
#' @param print_jacobian Logical. Whether to print the Jacobian or not. Only
#' used if `report == "period` and `jacobian == TRUE`.
#' @param ... Extra arguments passed to `nleqslv`.
#' @return If `jacobian == TRUE`: Returns a list containing the Jacobian matrix
#' and the convergence status for the last group and period solved. Otherwise
#' returns NULL.
#'
#' @importFrom dplyr group_split filter inner_join select
#' @importFrom rlang .data
#'
#' @noRd

fmds <- function(
    mdl, period, solve_df, report, default_initial_guess, jacobian,
    print_jacobian = TRUE, ...) {

  # Only print the jacobian when the full report is printed (report = "period").
  if (report != "period") print_jacobian <- FALSE

  solve_df <- ensure_solve_df_cols(solve_df,
                                   default_initial_guess = default_initial_guess)

  period <- as.period_range(period)
  solve_periods <- as.period(solve_df$solve_period)
  outside <- solve_periods < start_period(period) |
    solve_periods > end_period(period)
  if (any(outside)) {
    offending_periods <- unique(solve_df$solve_period[outside])
    stop(
      "One or more solve periods in solve_df are outside the specified ",
      "period range (", as.character(period), "). Offending periods:\n ",
      paste(offending_periods, collapse = ", ")
    )
  }

  # Check that solve_variables and observed_variables are endogenous.
  all_endo <- mdl$get_endo_names()
  check_endo(solve_df$solve_variable, all_endo, "solve")
  check_endo(solve_df$observed_variable, all_endo, "observed")

  # Check for overlap between solve and observed variables
  v_solve <- paste0(solve_df$solve_variable, "[", solve_df$solve_period, "]")
  v_obs   <- paste0(solve_df$observed_variable, "[", solve_df$solve_period, "]")
  check_overlap(v_solve, v_obs,
                "The following solve variables are also observed variables in the same period")

  # Check for duplicates in solve and observed variables
  check_unique(v_solve, "solve")
  check_unique(v_obs, "observed")

  # Check that each equation name is the same as the name of the corresponding
  # endogenous variable (LHS).
  # This IS the case for the current implementation of fmds.
  eq_names <- mdl$get_eq_names()
  if (!all(all_endo %in% eq_names)) {
    stop(paste(
      "Currently, fill_mdl_data_solve requires that all endogenous",
      "variables have an equation with the same name."
    ))
  }

  # Check the model type: it must be recursive (no feedback variables and no leads).
  if (length(mdl$get_endo_names(type = "feedback")) > 0) {
    stop("fill_mdl_data_solve does not support models with feedback variables.")
  }
  if (mdl$get_maxlead() > 0) {
    stop("fill_mdl_data_solve does not support models with leads.")
  }

  # Check that solve_variables are NA at their respective solve_periods.

  solve_periods <- as.period(solve_df$solve_period)
  solve_period_range <- period_range(min(solve_periods),
                                     max(solve_periods))
  mdl_data_long <- regts::as_data_frame(
    mdl$get_data(names = unique(solve_df$solve_variable),
                 period = solve_period_range),
    format = "long",
    name_col = "solve_variable",
    period_col = "solve_period"
  ) |>
    dplyr::filter(!is.na(.data$value))

  offending_values <- solve_df |>
    dplyr::inner_join(mdl_data_long, by = c("solve_period", "solve_variable")) |>
    dplyr::select("solve_variable", "solve_period")

  if (nrow(offending_values) > 0) {
    offending_table <- capture.output(print(as.data.frame(offending_values)))
    stop(
      "Some solve variables are not NA. Non-NA values for the following ",
      "variables and periods:\n",
      paste(offending_table, collapse = "\n")
    )
  }

  # Check that observed_variables are not NA at their respective solve_periods.
  obs_data_long <- regts::as_data_frame(
    mdl$get_data(names = unique(solve_df$observed_variable),
                 period = solve_period_range),
    format = "long",
    name_col = "observed_variable",
    period_col = "solve_period"
  ) |>
    dplyr::filter(is.na(.data$value))

  offending_obs <- solve_df |>
    dplyr::inner_join(obs_data_long, by = c("solve_period", "observed_variable")) |>
    dplyr::select("observed_variable", "solve_period")

  if (nrow(offending_obs) > 0) {
    offending_table <- capture.output(print(as.data.frame(offending_obs)))
    stop(
      "Some observed variables are NA. NA values for the following ",
      "variables and periods:\n",
      paste(offending_table, collapse = "\n")
    )
  }

  mdl_original_data <- mdl$get_data()

  # get dependency structure as list
  dep_struc <- mdl$get_dep_struct(one_lag_per_row = TRUE) |>
    dep_struct_to_list()

  if (missing(period)) {
    period <- mdl$get_data_period()
  }

  mdl$fill_mdl_data(period = period, report = "no", include_frmls = TRUE)
  data_after_first_fill <- mdl$get_data()

  for (single_solve_period in solve_df |> group_split(.data$solve_period)) {
    this_period <- single_solve_period$solve_period[1]
    for (group_data in single_solve_period |> group_split(.data$group)) {

      observed_data <- get_observed_data(mdl$get_data())

      # numerical vector used in nleqslv
      initial_guess_vector <- group_data$initial_guess

      res <- fmds_group(
        mdl,
        solve_group = group_data$group[1],
        solve_period = this_period,
        solve_variables = group_data$solve_variable,
        observed_variables = group_data$observed_variable,
        observed_data = observed_data,
        dep_struc = dep_struc,
        initial_guess = initial_guess_vector,
        report = report,
        jacobian = jacobian,
        print_jacobian = print_jacobian,
        ...
      )
      if (!res$solved) {
        return(list(solved = FALSE, jacobian = res$jacobian))
      }
      jac <- res$jacobian

    }

    # Fill model data for this period.
    mdl$fill_mdl_data(period = this_period, report = "no", include_frmls = TRUE)

  }

  # Finally solve for missing data for the full period again, more variables
  # may be calculated.
  mdl$fill_mdl_data(period = period, report = "no", include_frmls = TRUE)

  mdl_solved_data <- mdl$get_data()

  dif_table <- tsdif(mdl_original_data, mdl_solved_data, fun = cvgdif,
                     tol = 1e-4)$dif_table

  if (!is.null(dif_table) && !all(is.na(dif_table$value1))) {
    stop(paste(
      "One or more valid (non-NA) values have been modified during the solve",
      "process. This is not allowed. Offending variables:\n ",
      paste(unique(dif_table$name[!is.na(dif_table$value1)]), collapse = ", ")
    ))
  }

  # Create summary based on report type
  if (report != "no") {
    n_first_fill <- sum(is.na(mdl_original_data) & !is.na(data_after_first_fill))
    n_solved     <- nrow(solve_df)
    n_final_fill <- sum(is.na(data_after_first_fill) & !is.na(mdl_solved_data)) - n_solved
    cat("\n===============================================\n")
    cat("Summary of missing values replaced:")
    cat("\n===============================================\n\n")
    cat("by fill_mdl_data pre solve        : ", n_first_fill, "\n",   sep = "")
    cat("solved                            : ", n_solved,     "\n",   sep = "")
    cat("by fill_mdl_data_solve post solve : ", n_final_fill, "\n\n", sep = "")
  }

  # Returns the result list
  list(solved = TRUE, jacobian = jac)
}
