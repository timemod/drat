module model_type

    use model_params
    use mdl_flen

    !
    ! Model paramters
    !    fboflg feedback ordering flag
    !             0 : Do not generate feedback ordering
    !             1 : Generate feedback ordering and write to
    !                 mif.
    !             2 : Generate fb ordering, but do not write
    !                 to mif. The fb ordering will be generated
    !                 again after reading the model. 
    !             WARNING: if fboflg > 0, the model does not
    !             always have a feedback ordering. See argument
    !             fbomem.
    !   fbomem  size that array fbordr should have to hold
    !           the feedback ordering information. If equal to 0,
    !           the model does not have a feedback ordering.
    !           This is possible if the model has less than 2
    !           feedback variables or if the Jacobian is so
    !           dense that it is not advantageous to
    !           use feedback ordering (see module mcfbor).


    type model
        integer(kind = MC_IKIND)  :: cnamelen
        character(len = MAXMOLEN) :: cname
        character(len = 10) :: date, time
        integer(kind = MC_IKIND)  :: &
&           neq,loops,loope,nuf,nulf,ielast,ufblen,eqblen, &
&           nrp,nrc,nfb,nrv,nca,nendex,nd,nd1,ivlast,iplast, &
&           iflast,iulflast, fboflg,fbomem, &
&           mxlead, mxlag
        integer(kind = MC_IKIND), dimension(:), allocatable :: &
&           enames,vnames,pnames,fnames,ulfnames,ienames,ivnames, &
&           ipnames,ifnames,iulfnames,indexe,lhsnum, eqnum, indexv, &
&           narguf,indexp,nvalp,cfptr,etype, &
&           numfb,fbtype,iendex,ica,aci,ibx1,ibx2, &
&           order,order_inv,fboptr,fbordr,nrecp,nrecuf,equat
         logical(kind = MC_IKIND), dimension(:), allocatable :: lik
         real(kind = MC_RKIND), dimension(:), allocatable :: coef
    end type model

    integer, parameter, private :: ACTIVATE = 1
    integer, parameter, private :: DEACTIVATE = 2

    private :: activate_deactivate_eq

contains

    subroutine allocate_model(mdl, eqCount, varCount, parCount, &
&       coefCount, funCount, ulFunCount, eqCharCount, &
&       varCharCount, parCharCount, funCharCount, ulFunCharCount, &
&       caCount, leadVarCount, stat)

       type(model), intent(inout) :: mdl
       integer(kind = MC_IKIND), intent(in) :: eqCount, varCount, &
&                  parCount, coefCount, funCount, ulFunCount
       integer(kind = MC_IKIND), intent(in) ::  eqCharCount, &
&               varCharCount, parCharCount, funCharCount, &
&               ulFunCharCount, caCount, leadVarCount
       integer, intent(out) :: stat

       integer(kind = MC_IKIND) ::  kmaxe, kmaxv, kmaxp, kmaxf, kmaxulf

       call deallocate_model(mdl)

       allocate(mdl%ienames(eqCount), stat = stat)
       if (stat == 0) allocate(mdl%ivnames(varCount), stat = stat)
       if (stat == 0) allocate(mdl%ipnames(parCount), stat = stat)
       if (stat == 0) allocate(mdl%ifnames(funCount), stat = stat)
       if (stat == 0) allocate(mdl%indexe(eqCount), stat = stat)
       if (stat == 0) allocate(mdl%indexv(varCount), stat = stat)
       if (stat == 0) allocate(mdl%indexp(parCount), stat = stat)
       if (stat == 0) allocate(mdl%lhsnum(eqCount), stat = stat)
       if (stat == 0) allocate(mdl%eqnum(eqCount), stat = stat)
       if (stat == 0) allocate(mdl%etype(eqCount / MCNYI4 + 1), stat = stat)
       if (stat == 0) allocate(mdl%narguf(funCount), stat = stat)
       if (stat == 0) allocate(mdl%coef(coefCount), stat = stat)
       if (stat == 0) allocate(mdl%nvalp(parCount), stat = stat)
       if (stat == 0) allocate(mdl%cfptr(parCount), stat = stat)
       if (stat == 0) allocate(mdl%order(eqCount), stat = stat)
       if (stat == 0) allocate(mdl%order_inv(eqCount), stat = stat)
       if (stat == 0) allocate(mdl%ibx1(varCount + 1), stat = stat)
       if (stat == 0) allocate(mdl%ibx2(varCount + 1), stat = stat)
       if (stat == 0) allocate(mdl%lik(varCount), stat = stat)
       if (stat == 0) allocate(mdl%ica(caCount), stat = stat)
       if (stat == 0) allocate(mdl%aci(varCount), stat = stat)

       if (stat > 0) then
          call deallocate_model(mdl)
          return
       endif

       kmaxp  =  (parCharCount - 1)   / MCNYI4 + 1
       kmaxe  =  (eqCharCount  - 1)   / MCNYI4 + 1
       kmaxv  =  (varCharCount - 1)   / MCNYI4 + 1
       kmaxf  =  (funCharCount - 1)   / MCNYI4 + 1

       allocate(mdl%enames(kmaxe), stat = stat)
       if (stat == 0) allocate(mdl%vnames(kmaxv), stat = stat)
       if (stat == 0) allocate(mdl%pnames(kmaxp), stat = stat)
       if (stat == 0) allocate(mdl%fnames(kmaxf), stat = stat)

       if (stat == 0 .and. leadVarCount > 0) then
           allocate(mdl%iendex(leadVarCount), stat = stat)
       endif

       if (stat == 0 .and. ulFunCount > 0) then
           kmaxulf = (ulFunCharCount - 1) / MCNYI4 + 1
           allocate(mdl%iulfnames(ulFunCount), stat = stat)
           if (stat == 0) allocate(mdl%ulfnames(kmaxulf), stat = stat)
       endif

       if (stat > 0) call deallocate_model(mdl)

    end subroutine allocate_model

    subroutine deallocate_model(mdl)
        type(model), intent(inout) :: mdl

        if (allocated(mdl%enames))    deallocate(mdl%enames)
        if (allocated(mdl%vnames))    deallocate(mdl%vnames)
        if (allocated(mdl%pnames))    deallocate(mdl%pnames)
        if (allocated(mdl%fnames))    deallocate(mdl%fnames)
        if (allocated(mdl%ulfnames))  deallocate(mdl%ulfnames)
        if (allocated(mdl%ienames))   deallocate(mdl%ienames)
        if (allocated(mdl%ivnames))   deallocate(mdl%ivnames)
        if (allocated(mdl%ipnames))   deallocate(mdl%ipnames)
        if (allocated(mdl%ifnames))   deallocate(mdl%ifnames)
        if (allocated(mdl%iulfnames)) deallocate(mdl%iulfnames)
        if (allocated(mdl%indexe))    deallocate(mdl%indexe)
        if (allocated(mdl%indexv))    deallocate(mdl%indexv)
        if (allocated(mdl%indexp))    deallocate(mdl%indexp)
        if (allocated(mdl%lhsnum))    deallocate(mdl%lhsnum)
        if (allocated(mdl%eqnum))     deallocate(mdl%eqnum)
        if (allocated(mdl%narguf))    deallocate(mdl%narguf)
        if (allocated(mdl%nvalp))     deallocate(mdl%nvalp)
        if (allocated(mdl%cfptr))     deallocate(mdl%cfptr)
        if (allocated(mdl%etype))     deallocate(mdl%etype)
        if (allocated(mdl%numfb))     deallocate(mdl%numfb)
        if (allocated(mdl%fbtype))    deallocate(mdl%fbtype)
        if (allocated(mdl%iendex))    deallocate(mdl%iendex)
        if (allocated(mdl%ica))       deallocate(mdl%ica)
        if (allocated(mdl%aci))       deallocate(mdl%aci)
        if (allocated(mdl%ibx1))      deallocate(mdl%ibx1)
        if (allocated(mdl%ibx2))      deallocate(mdl%ibx2)
        if (allocated(mdl%order))     deallocate(mdl%order)
        if (allocated(mdl%order_inv)) deallocate(mdl%order_inv)
        if (allocated(mdl%fboptr))    deallocate(mdl%fboptr)
        if (allocated(mdl%fbordr))    deallocate(mdl%fbordr)
        if (allocated(mdl%nrecp))     deallocate(mdl%nrecp)
        if (allocated(mdl%nrecuf))    deallocate(mdl%nrecuf)
        if (allocated(mdl%equat))     deallocate(mdl%equat)
        if (allocated(mdl%lik))       deallocate(mdl%lik)
        if (allocated(mdl%coef))      deallocate(mdl%coef)

    end subroutine deallocate_model

    function has_endo_lead(mdl)
        logical :: has_endo_lead
        type(model), intent(in) :: mdl

        !
        !returns true if the model has an endogenous lead

        integer :: i

        has_endo_lead = .false.
        do i = 1, mdl%nendex
            if (mdl%iendex(i) > 0 .and. mdl%lik(mdl%iendex(i))) then
                has_endo_lead = .true.
                return
            endif
         end do
         return
    end function has_endo_lead
    
    ! This subroutine is used to extract the name of model
    ! variable i. The name is put as a byte string in nam,
    ! and nlen is set to its length. If a name does not
    ! exist is nlen is set to -1.
    subroutine get_var_name(mdl, i, alphabetical, nam, nlen)
        use mdl_name_utils
        type(model), intent(in) :: mdl
        integer, intent(in) :: i
        logical, intent(in) :: alphabetical
        integer, intent(out) :: nlen  ! length of name
        integer, dimension(*), intent(out) :: nam ! name (ascii char.)

        integer :: iv

        if (i <= 0 .or. i > mdl%nrv) then
            nlen = -1
            return
        endif

        if (alphabetical) then
            iv = mdl%indexv(i)
        else
            iv = i
        endif
        call mcgetnam(nam, nlen, mdl%ivnames(iv), mdl%vnames)

    end subroutine get_var_name

    ! This subroutine is used to extract the name of model
    ! parameter i. The name is put as a byte string in nam,
    ! and nlen is set to its length. If a name does not
    ! exist is nlen is set to -1.
    subroutine get_par_name(mdl, i, alphabetical, nam, nlen)
        use mdl_name_utils
        type(model), intent(in) :: mdl
        integer, intent(in) :: i
        logical, intent(in) :: alphabetical
        integer, intent(out) :: nlen  ! length of name
        integer, dimension(*), intent(out) :: nam ! name (ascii char.)

        integer :: ip

        if (i <= 0 .or. i > mdl%nrp) then
            nlen = -1
            return
        endif

        if (alphabetical) then
            ip = mdl%indexp(i)
        else
            ip = i
        endif
        call mcgetnam(nam, nlen, mdl%ipnames(ip), mdl%pnames)

    end subroutine get_par_name

    ! This subroutine is used to extract the name of model
    ! variable i. The name is put as a byte string in nam,
    ! and nlen is set to its length. If a name does not
    ! exist is nlen is set to -1.
    subroutine get_eq_name(mdl, i, alphabetical, nam, nlen)
        use mdl_name_utils
        type(model), intent(in) :: mdl
        integer, intent(in) :: i
        logical, intent(in) :: alphabetical
        integer, intent(out) :: nlen  ! length of name
        integer, dimension(*), intent(out) :: nam ! name (ascii char.)

        integer :: ieq

        if (i <= 0 .or. i > mdl%neq) then
            nlen = -1
            return
        endif

        if (alphabetical) then
            ieq = mdl%indexe(i)
        else
            ieq = i
        endif
        call mcgetnam(nam, nlen, mdl%ienames(ieq), mdl%enames)

    end subroutine get_eq_name

    ! This subroutine is used to extract the name of model
    ! parameter i. The name is put as a byte string in nam,
   
    logical function is_frml(mdl, iv) 
        ! returns true if variable iv is a frml equation
        type(model), intent(in) :: mdl
        integer, intent(in) :: iv
        is_frml = mdl%aci(iv) > 0
    end function is_frml

    logical function is_active(mdl, eqnum)
        ! returns true if equation eqnum is active
        type(model), intent(in) :: mdl
        integer, intent(in) :: eqnum

        integer :: eqtyp
        integer, external :: bysget


        eqtyp = bysget(mdl%etype, eqnum)
        ! eqtyp is lowercase for active eqaution and uppercase for an 
        ! inactive equaiton
        is_active = eqtyp <= 96
    end function is_active

    subroutine activate_eq(mdl, eqnum)
        type(model), intent(inout) :: mdl
        integer, intent(in) :: eqnum
        call activate_deactivate_eq(mdl, eqnum, ACTIVATE)
    end subroutine activate_eq

    subroutine deactivate_eq(mdl, eqnum)
        type(model), intent(inout) :: mdl
        integer, intent(in) :: eqnum
        call activate_deactivate_eq(mdl, eqnum, DEACTIVATE)
    end subroutine deactivate_eq

    subroutine activate_deactivate_eq(mdl, eqnum, action)
        use utils, only : idxlzuk
        type(model), intent(inout) :: mdl
        integer, intent(in) :: eqnum, action

        integer :: eqtyp, lhsvar, jen, canum, lhsvar_signed
        logical :: is_act
        integer, external :: bysget

        is_act = is_active(mdl, eqnum)

        if ((action == ACTIVATE .and. is_act) .or. &
            (action == DEACTIVATE  .and. .not. is_act)) return

        eqtyp  = bysget(mdl%etype, eqnum)
        lhsvar = mdl%lhsnum(eqnum)

        ! eqtyp is lowercase for active eqaution and uppercase for an 
        ! inactive equaiton
        if (action == ACTIVATE) then
            call bysset(mdl%etype, eqnum, eqtyp - 32)
        else 
            call bysset(mdl%etype, eqnum, eqtyp + 32)
        endif
        mdl%lik(lhsvar) = action == ACTIVATE

        !
        ! now update mdl%iendex and mdl%ica: lhsvar should be replaced by -lhsvar if 
        ! the variable is deactivated, and +lhsvar if the equation is activated
        !
        if (action == ACTIVATE) then
            lhsvar_signed = lhsvar
        else 
            lhsvar_signed = -lhsvar
        endif
        
        if (mdl%ibx2(lhsvar + 1) > mdl%ibx2(lhsvar)) then
            ! The variable has leads: look up index in iendex (to make exogenous)
            ! Note that we use -lhsvar_signed: we use the sign of the variable
            ! before activation / deactivation 
            jen = idxlzuk(mdl%iendex, mdl%nendex, -lhsvar_signed)
            if (jen == 0) then
                call rexit("Internal error in activate_deactivate_eq: iendex array error")
            endif
        else 
            jen = 0
        endif
        if (jen > 0) mdl%iendex(jen) = lhsvar_signed

        ! CA number (if <> 0 index into ica() corresponding to lhs variable)
        canum = mdl%aci(lhsvar)
        if (canum > 0) mdl%ica(canum)  = lhsvar_signed
    end subroutine activate_deactivate_eq

    logical function has_fb_order(mdl)
        type(model), intent(inout) :: mdl
        has_fb_order = mdl%fboflg > 0 .and. mdl%fbomem > 0
    end function has_fb_order

    ! generate an alphabetical ordering of names
    subroutine sort_names(mdl)
       use mdl_name_utils
       type(model), intent(inout) :: mdl

       ! equations
       call hsortmvn(mdl%indexe, mdl%neq, mdl%ienames, mdl%enames)
    
       ! variables
       call hsortmvn(mdl%indexv, mdl%nrv, mdl%ivnames, mdl%vnames)
    
       ! parameters
       call hsortmvn(mdl%indexp, mdl%nrp, mdl%ipnames, mdl%pnames)
    
    end subroutine sort_names

    subroutine set_order_inv(mdl)
       type(model), intent(inout) :: mdl

       integer :: ieq, ieq_ord

       mdl%order_inv(:mdl%neq) = 0
       do ieq_ord = 1, mdl%neq
           ieq = mdl%order(ieq_ord)
           if (ieq > 0) mdl%order_inv(ieq) = ieq_ord
       end do

    end subroutine set_order_inv


    ! check if active equations are in solve order
    subroutine check_active_equations(mdl) 
       type(model), intent(in) :: mdl

       integer :: ieq
      
       do ieq = 1, mdl%neq
           if (mdl%order_inv(ieq) == 0) then
               if (is_active(mdl, ieq)) then
                 call rexit("One or more active equations not in solve order. Reorder the model with method 'order'.")
               endif
          end if
       end do
    end subroutine check_active_equations


end module model_type
