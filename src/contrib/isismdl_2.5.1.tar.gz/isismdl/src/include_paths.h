extern  void    add_include_path(const char *path);
extern  char    *get_includefilename(char *includename, char *current_dirname);
extern  void    init_include_dirs(void);
