// prepare_compiler.h
#ifndef PREPARE_COMPILER_H
#define PREPARE_COMPILER_H

#include <Rinternals.h>

void prepare_compiler(SEXP flags, SEXP include_dirs);

#endif
