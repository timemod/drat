library(utils)
library(isismdl)
library(testthat)

context("test for complex model 2")

period <- as.period_range("2017m12")
expected_output_file <- "expected_output/complex2.rds"
orf_name <- "output/complex2.orf"
expected_orf_name <- "expected_output/complex2.orf"
mdl_filename <- "mdl/complex2.mdl"
mdl_subst_filename <- "mdl/complex2_subst.mdl"

# create model
capture.output(mdl <- isis_mdl(mdl_filename, period))
data_per <- mdl$get_data_period()
mdl$set_values(seq_len(nperiod(data_per)), names = paste0("x", 1:3))
mdl$set_solve_options(report = "none")

# convert model by using function substitution
outp <- capture.output(convert_mdl_file(mdl_filename, mdl_subst_filename,
                       conversion_options = list(substitute = TRUE)))

# create model with substituted user functions
outp <- capture.output(mdl_subst <- isis_mdl(mdl_subst_filename, period))
mdl_subst$set_values(seq_len(nperiod(data_per)), names = paste0("x", 1:3))
mdl_subst$set_solve_options(report = "none")

test_that("mdl_subst is correct", {
  expect_identical(mdl_subst$get_data_period(), data_per)
  expect_identical(mdl$get_var_names(), mdl_subst$get_var_names())
})

test_that("order works correctly", {

  mdl_old <- mdl$copy()
  outp  <- capture.output(mdl$order(orfnam = orf_name))
  expect_equal(mdl, mdl_old)

  # compare orf files
  orf <- readLines(orf_name)
  expected_orf <- readLines(expected_orf_name)
  expect_identical(orf, expected_orf)
})

test_that("model is solved correctly", {

  mdl$solve()
  expect_equal_to_reference(mdl$get_data(), file = expected_output_file)

  mdl_subst$solve()
  expect_equal(mdl$get_data(), mdl_subst$get_data())
})

