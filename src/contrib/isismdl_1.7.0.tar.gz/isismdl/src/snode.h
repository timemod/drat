
void    out_scode( FILE *fp, Symbol *sp );
void    out_spar( FILE *fp, Symbol *sp );
