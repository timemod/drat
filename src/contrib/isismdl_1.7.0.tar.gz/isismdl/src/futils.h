int file_exists (char *filename);

