void set_fit_options(int *model_index, SEXP options);
