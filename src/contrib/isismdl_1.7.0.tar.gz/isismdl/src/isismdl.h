#include <Rinternals.h>

#define PRINTF Rprintf
#define WARN warning
#define ERROR error
