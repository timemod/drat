int add_flag(const char *flag);
int flag_present(const char *flag);
void clear_flags(void);
