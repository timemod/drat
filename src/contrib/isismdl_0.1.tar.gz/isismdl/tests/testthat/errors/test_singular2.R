library(isismdl)
library(testthat)

# cmpmdl("../mdl/singular2");
# readmdl("../mdl/singular2");
#
# setmdp(2011y);
# x1 = 0.0;
# y1 = 0.0;
# z1 = 0.0;
# x2 = 0.0;
# y2 = 0.0;
# z2 = 0.0;
# p1 = 0.0;
#
# solve(method = broyden; dbgopt = prifb, prijac; svdtest_tol = 1e-6);

