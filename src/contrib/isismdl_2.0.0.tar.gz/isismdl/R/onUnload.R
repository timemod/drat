.onUnload <- function (libpath) {
    library.dynam.unload("isismdl", libpath)
}
