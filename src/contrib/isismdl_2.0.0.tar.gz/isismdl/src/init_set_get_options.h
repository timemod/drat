extern void F77_SUB(init_set_options)(int *model_index, int *use_mws);
extern void F77_SUB(init_get_options)(int *model_index);
