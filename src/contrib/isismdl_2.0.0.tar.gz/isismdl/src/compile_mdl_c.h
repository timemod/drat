SEXP compile_mdl_c(SEXP filename, SEXP mifname, SEXP flags, SEXP include_dirs, 
                   SEXP gen_dep_file_);
