/*
 * Common variables and functions for output of model
 * for Isis and Troll (outomdl.c and outtmdl.c)
 */

static  Symbol  *sumsp; /* for loop variable in SUM */

