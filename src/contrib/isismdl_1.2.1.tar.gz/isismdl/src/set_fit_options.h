void set_fit_options(int *mws_index, SEXP options);
