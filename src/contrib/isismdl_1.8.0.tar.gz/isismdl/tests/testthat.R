library(testthat)

test_check("isismdl")
