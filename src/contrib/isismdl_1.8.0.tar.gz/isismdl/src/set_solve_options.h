void set_solve_options(int *model_index, SEXP options);
