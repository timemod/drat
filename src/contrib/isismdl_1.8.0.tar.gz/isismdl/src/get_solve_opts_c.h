SEXP get_solve_opts_c(SEXP model_index_);
