library(testthat)
library(regts)

test_check("regts")
