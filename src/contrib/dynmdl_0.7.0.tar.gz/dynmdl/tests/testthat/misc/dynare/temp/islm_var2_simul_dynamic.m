function [residual, g1, g2, g3] = islm_var2_simul_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           rows: equations in order of declaration
%                                                           columns: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(29, 1);
lhs =y(12);
rhs =y(15)+y(16)+x(it_, 1);
residual(1)= lhs-rhs;
lhs =y(13);
rhs =y(12)-y(14);
residual(2)= lhs-rhs;
lhs =y(14);
rhs =params(18)+y(12)*params(19);
residual(3)= lhs-rhs;
lhs =y(15);
rhs =y(19)+0.1*y(6)+0.25*y(46)+params(2)+params(3)*y(2)+y(13)*params(4)+params(5)*y(42)+params(6)*y(18)+params(7)*y(18)^2+0.1*y(5);
residual(4)= lhs-rhs;
lhs =y(16);
rhs =y(18)^2*params(13)+y(18)*params(12)+params(8)+params(9)*y(1)+y(12)*params(10)+params(11)*y(41)+0.01*y(9);
residual(5)= lhs-rhs;
lhs =y(17);
rhs =params(14)+y(12)*params(15)+y(18)*params(16)+y(18)^2*params(17);
residual(6)= lhs-rhs;
lhs =y(17);
rhs =x(it_, 2);
residual(7)= lhs-rhs;
residual(8) = (params(1)>=0)*(y(19)/params(1)^2-y(23))+(params(1)<0)*(y(19)-x(it_, 17));
residual(9) = x(it_, 3)*(y(12)-x(it_, 10))+(1-x(it_, 3))*(y(4)*(-params(11))+y(25)*(-params(15))+y(24)*(-params(10))+y(22)*(-params(19))+y(20)+y(44)*(-params(9))+(-0.01)*y(49)-y(21));
residual(10) = x(it_, 4)*(y(13)-x(it_, 11))+(1-x(it_, 4))*(y(3)*(-params(5))+y(23)*(-params(4))+y(21)+y(43)*(-params(3))+(-0.1)*y(51)+(-0.1)*y(50)+(-0.25)*y(11));
residual(11) = x(it_, 5)*(y(14)-x(it_, 12))+(1-x(it_, 5))*(y(21)+y(22));
residual(12) = x(it_, 6)*(y(15)-x(it_, 13))+(1-x(it_, 6))*(y(23)-y(20));
residual(13) = x(it_, 7)*(y(16)-x(it_, 14))+(1-x(it_, 7))*(y(24)-y(20));
residual(14) = x(it_, 8)*(y(17)-x(it_, 15))+(1-x(it_, 8))*(y(25)+y(26));
residual(15) = x(it_, 9)*(y(18)-x(it_, 16))+(1-x(it_, 9))*(y(23)*(-(params(6)+y(18)*2*params(7)))+y(24)*(-(params(12)+y(18)*2*params(13)))+y(25)*(-(params(16)+y(18)*2*params(17))));
lhs =y(27);
rhs =y(42);
residual(16)= lhs-rhs;
lhs =y(28);
rhs =y(45);
residual(17)= lhs-rhs;
lhs =y(29);
rhs =y(44);
residual(18)= lhs-rhs;
lhs =y(30);
rhs =y(47);
residual(19)= lhs-rhs;
lhs =y(31);
rhs =y(48);
residual(20)= lhs-rhs;
lhs =y(32);
rhs =y(43);
residual(21)= lhs-rhs;
lhs =y(33);
rhs =y(50);
residual(22)= lhs-rhs;
lhs =y(34);
rhs =y(2);
residual(23)= lhs-rhs;
lhs =y(35);
rhs =y(5);
residual(24)= lhs-rhs;
lhs =y(36);
rhs =y(1);
residual(25)= lhs-rhs;
lhs =y(37);
rhs =y(7);
residual(26)= lhs-rhs;
lhs =y(38);
rhs =y(8);
residual(27)= lhs-rhs;
lhs =y(39);
rhs =y(3);
residual(28)= lhs-rhs;
lhs =y(40);
rhs =y(10);
residual(29)= lhs-rhs;
if nargout >= 2,
  g1 = zeros(29, 68);

  %
  % Jacobian matrix
  %

  g1(1,12)=1;
  g1(1,15)=(-1);
  g1(1,16)=(-1);
  g1(1,52)=(-1);
  g1(2,12)=(-1);
  g1(2,13)=1;
  g1(2,14)=1;
  g1(3,12)=(-params(19));
  g1(3,14)=1;
  g1(4,2)=(-params(3));
  g1(4,13)=(-params(4));
  g1(4,42)=(-params(5));
  g1(4,15)=1;
  g1(4,18)=(-(params(6)+params(7)*2*y(18)));
  g1(4,19)=(-1);
  g1(4,46)=(-0.25);
  g1(4,5)=(-0.1);
  g1(4,6)=(-0.1);
  g1(5,1)=(-params(9));
  g1(5,12)=(-params(10));
  g1(5,41)=(-params(11));
  g1(5,16)=1;
  g1(5,18)=(-(params(12)+params(13)*2*y(18)));
  g1(5,9)=(-0.01);
  g1(6,12)=(-params(15));
  g1(6,17)=1;
  g1(6,18)=(-(params(16)+params(17)*2*y(18)));
  g1(7,17)=1;
  g1(7,53)=(-1);
  g1(8,19)=(params(1)<0)+(params(1)>=0)*1/params(1)^2;
  g1(8,23)=(-(params(1)>=0));
  g1(8,68)=(-(params(1)<0));
  g1(9,12)=x(it_, 3);
  g1(9,20)=1-x(it_, 3);
  g1(9,21)=(-(1-x(it_, 3)));
  g1(9,22)=(1-x(it_, 3))*(-params(19));
  g1(9,4)=(1-x(it_, 3))*(-params(11));
  g1(9,24)=(1-x(it_, 3))*(-params(10));
  g1(9,44)=(1-x(it_, 3))*(-params(9));
  g1(9,25)=(1-x(it_, 3))*(-params(15));
  g1(9,54)=y(12)-x(it_, 10)-(y(4)*(-params(11))+y(25)*(-params(15))+y(24)*(-params(10))+y(22)*(-params(19))+y(20)+y(44)*(-params(9))+(-0.01)*y(49)-y(21));
  g1(9,61)=(-x(it_, 3));
  g1(9,49)=(1-x(it_, 3))*(-0.01);
  g1(10,13)=x(it_, 4);
  g1(10,21)=1-x(it_, 4);
  g1(10,3)=(1-x(it_, 4))*(-params(5));
  g1(10,23)=(1-x(it_, 4))*(-params(4));
  g1(10,43)=(1-x(it_, 4))*(-params(3));
  g1(10,55)=y(13)-x(it_, 11)-(y(3)*(-params(5))+y(23)*(-params(4))+y(21)+y(43)*(-params(3))+(-0.1)*y(51)+(-0.1)*y(50)+(-0.25)*y(11));
  g1(10,62)=(-x(it_, 4));
  g1(10,50)=(1-x(it_, 4))*(-0.1);
  g1(10,51)=(1-x(it_, 4))*(-0.1);
  g1(10,11)=(1-x(it_, 4))*(-0.25);
  g1(11,14)=x(it_, 5);
  g1(11,21)=1-x(it_, 5);
  g1(11,22)=1-x(it_, 5);
  g1(11,56)=y(14)-x(it_, 12)-(y(21)+y(22));
  g1(11,63)=(-x(it_, 5));
  g1(12,15)=x(it_, 6);
  g1(12,20)=(-(1-x(it_, 6)));
  g1(12,23)=1-x(it_, 6);
  g1(12,57)=y(15)-x(it_, 13)-(y(23)-y(20));
  g1(12,64)=(-x(it_, 6));
  g1(13,16)=x(it_, 7);
  g1(13,20)=(-(1-x(it_, 7)));
  g1(13,24)=1-x(it_, 7);
  g1(13,58)=y(16)-x(it_, 14)-(y(24)-y(20));
  g1(13,65)=(-x(it_, 7));
  g1(14,17)=x(it_, 8);
  g1(14,25)=1-x(it_, 8);
  g1(14,26)=1-x(it_, 8);
  g1(14,59)=y(17)-x(it_, 15)-(y(25)+y(26));
  g1(14,66)=(-x(it_, 8));
  g1(15,18)=x(it_, 9)+(1-x(it_, 9))*(y(23)*(-(2*params(7)))+y(24)*(-(2*params(13)))+y(25)*(-(2*params(17))));
  g1(15,23)=(1-x(it_, 9))*(-(params(6)+y(18)*2*params(7)));
  g1(15,24)=(1-x(it_, 9))*(-(params(12)+y(18)*2*params(13)));
  g1(15,25)=(1-x(it_, 9))*(-(params(16)+y(18)*2*params(17)));
  g1(15,60)=y(18)-x(it_, 16)-(y(23)*(-(params(6)+y(18)*2*params(7)))+y(24)*(-(params(12)+y(18)*2*params(13)))+y(25)*(-(params(16)+y(18)*2*params(17))));
  g1(15,67)=(-x(it_, 9));
  g1(16,42)=(-1);
  g1(16,27)=1;
  g1(17,45)=(-1);
  g1(17,28)=1;
  g1(18,44)=(-1);
  g1(18,29)=1;
  g1(19,47)=(-1);
  g1(19,30)=1;
  g1(20,48)=(-1);
  g1(20,31)=1;
  g1(21,43)=(-1);
  g1(21,32)=1;
  g1(22,50)=(-1);
  g1(22,33)=1;
  g1(23,2)=(-1);
  g1(23,34)=1;
  g1(24,5)=(-1);
  g1(24,35)=1;
  g1(25,1)=(-1);
  g1(25,36)=1;
  g1(26,7)=(-1);
  g1(26,37)=1;
  g1(27,8)=(-1);
  g1(27,38)=1;
  g1(28,3)=(-1);
  g1(28,39)=1;
  g1(29,10)=(-1);
  g1(29,40)=1;
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],29,4624);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],29,314432);
end
end
