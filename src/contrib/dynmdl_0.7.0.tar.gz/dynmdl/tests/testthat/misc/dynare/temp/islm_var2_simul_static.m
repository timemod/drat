function [residual, g1, g2] = islm_var2_simul_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                     columns: variables in declaration order
%                                                     rows: equations in order of declaration
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: variables in declaration order
%                                                       rows: equations in order of declaration
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 29, 1);

%
% Model equations
%

lhs =y(1);
rhs =y(4)+y(5)+x(1);
residual(1)= lhs-rhs;
lhs =y(2);
rhs =y(1)-y(3);
residual(2)= lhs-rhs;
lhs =y(3);
rhs =params(18)+y(1)*params(19);
residual(3)= lhs-rhs;
lhs =y(4);
rhs =y(8)+0.1*y(24)+0.25*y(17)+params(2)+y(2)*params(3)+y(2)*params(4)+y(2)*params(5)+params(6)*y(7)+params(7)*y(7)^2+0.1*y(23);
residual(4)= lhs-rhs;
lhs =y(5);
rhs =y(7)^2*params(13)+y(7)*params(12)+params(8)+y(1)*params(9)+y(1)*params(10)+y(1)*params(11)+0.01*y(27);
residual(5)= lhs-rhs;
lhs =y(6);
rhs =params(14)+y(1)*params(15)+y(7)*params(16)+y(7)^2*params(17);
residual(6)= lhs-rhs;
lhs =y(6);
rhs =x(2);
residual(7)= lhs-rhs;
residual(8) = (params(1)>=0)*(y(8)/params(1)^2-y(12))+(params(1)<0)*(y(8)-x(17));
residual(9) = x(3)*(y(1)-x(10))+(1-x(3))*(y(13)*(-params(11))+y(14)*(-params(15))+y(13)*(-params(10))+y(11)*(-params(19))+y(9)+y(13)*(-params(9))+(-0.01)*y(20)-y(10));
residual(10) = x(4)*(y(2)-x(11))+(1-x(4))*(y(12)*(-params(5))+y(12)*(-params(4))+y(10)+y(12)*(-params(3))+(-0.1)*y(22)+(-0.1)*y(21)+(-0.25)*y(29));
residual(11) = x(5)*(y(3)-x(12))+(1-x(5))*(y(11)+y(10));
residual(12) = x(6)*(y(4)-x(13))+(1-x(6))*(y(12)-y(9));
residual(13) = x(7)*(y(5)-x(14))+(1-x(7))*(y(13)-y(9));
residual(14) = x(8)*(y(6)-x(15))+(1-x(8))*(y(14)+y(15));
residual(15) = x(9)*(y(7)-x(16))+(1-x(9))*(y(12)*(-(params(6)+y(7)*2*params(7)))+y(13)*(-(params(12)+y(7)*2*params(13)))+y(14)*(-(params(16)+y(7)*2*params(17))));
lhs =y(16);
rhs =y(2);
residual(16)= lhs-rhs;
lhs =y(17);
rhs =y(16);
residual(17)= lhs-rhs;
lhs =y(18);
rhs =y(13);
residual(18)= lhs-rhs;
lhs =y(19);
rhs =y(18);
residual(19)= lhs-rhs;
lhs =y(20);
rhs =y(19);
residual(20)= lhs-rhs;
lhs =y(21);
rhs =y(12);
residual(21)= lhs-rhs;
lhs =y(22);
rhs =y(21);
residual(22)= lhs-rhs;
lhs =y(23);
rhs =y(2);
residual(23)= lhs-rhs;
lhs =y(24);
rhs =y(23);
residual(24)= lhs-rhs;
lhs =y(25);
rhs =y(1);
residual(25)= lhs-rhs;
lhs =y(26);
rhs =y(25);
residual(26)= lhs-rhs;
lhs =y(27);
rhs =y(26);
residual(27)= lhs-rhs;
lhs =y(28);
rhs =y(12);
residual(28)= lhs-rhs;
lhs =y(29);
rhs =y(28);
residual(29)= lhs-rhs;
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(29, 29);

  %
  % Jacobian matrix
  %

  g1(1,1)=1;
  g1(1,4)=(-1);
  g1(1,5)=(-1);
  g1(2,1)=(-1);
  g1(2,2)=1;
  g1(2,3)=1;
  g1(3,1)=(-params(19));
  g1(3,3)=1;
  g1(4,2)=(-(params(5)+params(3)+params(4)));
  g1(4,4)=1;
  g1(4,7)=(-(params(6)+params(7)*2*y(7)));
  g1(4,8)=(-1);
  g1(4,17)=(-0.25);
  g1(4,23)=(-0.1);
  g1(4,24)=(-0.1);
  g1(5,1)=(-(params(11)+params(9)+params(10)));
  g1(5,5)=1;
  g1(5,7)=(-(params(12)+params(13)*2*y(7)));
  g1(5,27)=(-0.01);
  g1(6,1)=(-params(15));
  g1(6,6)=1;
  g1(6,7)=(-(params(16)+params(17)*2*y(7)));
  g1(7,6)=1;
  g1(8,8)=(params(1)<0)+(params(1)>=0)*1/params(1)^2;
  g1(8,12)=(-(params(1)>=0));
  g1(9,1)=x(3);
  g1(9,9)=1-x(3);
  g1(9,10)=(-(1-x(3)));
  g1(9,11)=(1-x(3))*(-params(19));
  g1(9,13)=(1-x(3))*((-params(11))+(-params(10))-params(9));
  g1(9,14)=(1-x(3))*(-params(15));
  g1(9,20)=(1-x(3))*(-0.01);
  g1(10,2)=x(4);
  g1(10,10)=1-x(4);
  g1(10,12)=(1-x(4))*((-params(5))+(-params(4))-params(3));
  g1(10,21)=(1-x(4))*(-0.1);
  g1(10,22)=(1-x(4))*(-0.1);
  g1(10,29)=(1-x(4))*(-0.25);
  g1(11,3)=x(5);
  g1(11,10)=1-x(5);
  g1(11,11)=1-x(5);
  g1(12,4)=x(6);
  g1(12,9)=(-(1-x(6)));
  g1(12,12)=1-x(6);
  g1(13,5)=x(7);
  g1(13,9)=(-(1-x(7)));
  g1(13,13)=1-x(7);
  g1(14,6)=x(8);
  g1(14,14)=1-x(8);
  g1(14,15)=1-x(8);
  g1(15,7)=x(9)+(1-x(9))*(y(12)*(-(2*params(7)))+y(13)*(-(2*params(13)))+y(14)*(-(2*params(17))));
  g1(15,12)=(1-x(9))*(-(params(6)+y(7)*2*params(7)));
  g1(15,13)=(1-x(9))*(-(params(12)+y(7)*2*params(13)));
  g1(15,14)=(1-x(9))*(-(params(16)+y(7)*2*params(17)));
  g1(16,2)=(-1);
  g1(16,16)=1;
  g1(17,16)=(-1);
  g1(17,17)=1;
  g1(18,13)=(-1);
  g1(18,18)=1;
  g1(19,18)=(-1);
  g1(19,19)=1;
  g1(20,19)=(-1);
  g1(20,20)=1;
  g1(21,12)=(-1);
  g1(21,21)=1;
  g1(22,21)=(-1);
  g1(22,22)=1;
  g1(23,2)=(-1);
  g1(23,23)=1;
  g1(24,23)=(-1);
  g1(24,24)=1;
  g1(25,1)=(-1);
  g1(25,25)=1;
  g1(26,25)=(-1);
  g1(26,26)=1;
  g1(27,26)=(-1);
  g1(27,27)=1;
  g1(28,12)=(-1);
  g1(28,28)=1;
  g1(29,28)=(-1);
  g1(29,29)=1;
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],29,841);
end
end
