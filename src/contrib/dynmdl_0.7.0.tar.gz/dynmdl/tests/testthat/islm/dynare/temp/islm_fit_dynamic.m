function [residual, g1, g2, g3] = islm_fit_dynamic(y, x, params, steady_state, it_)
%
% Status : Computes dynamic model for Dynare
%
% Inputs :
%   y         [#dynamic variables by 1] double    vector of endogenous variables in the order stored
%                                                 in M_.lead_lag_incidence; see the Manual
%   x         [M_.exo_nbr by nperiods] double     matrix of exogenous variables (in declaration order)
%                                                 for all simulation periods
%   params    [M_.param_nbr by 1] double          vector of parameter values in declaration order
%   it_       scalar double                       time period for exogenous variables for which to evaluate the model
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the dynamic model equations in order of 
%                                          declaration of the equations
%   g1        [M_.endo_nbr by #dynamic variables] double    Jacobian matrix of the dynamic model equations;
%                                                           rows: equations in order of declaration
%                                                           columns: variables in order stored in M_.lead_lag_incidence
%   g2        [M_.endo_nbr by (#dynamic variables)^2] double   Hessian matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%   g3        [M_.endo_nbr by (#dynamic variables)^3] double   Third order derivative matrix of the dynamic model equations;
%                                                              rows: equations in order of declaration
%                                                              columns: variables in order stored in M_.lead_lag_incidence
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

%
% Model equations
%

residual = zeros(18, 1);
lhs =y(5);
rhs =y(8)+y(9)+x(it_, 1);
residual(1)= lhs-rhs;
lhs =y(6);
rhs =y(5)-y(7);
residual(2)= lhs-rhs;
lhs =y(7);
rhs =params(17)+y(5)*params(18)+y(12);
residual(3)= lhs-rhs;
lhs =y(8);
rhs =params(1)+params(2)*y(2)+y(6)*params(3)+params(4)*y(24)+params(5)*y(11)+params(6)*y(11)^2+y(13);
residual(4)= lhs-rhs;
lhs =y(9);
rhs =params(7)+params(8)*y(1)+y(5)*params(9)+params(10)*y(23)+y(11)*params(11)+y(11)^2*params(12)+y(14);
residual(5)= lhs-rhs;
lhs =y(10);
rhs =params(13)+y(5)*params(14)+y(11)*params(15)+y(11)^2*params(16)+y(15);
residual(6)= lhs-rhs;
lhs =y(10);
rhs =x(it_, 2);
residual(7)= lhs-rhs;
lhs =y(12)/params(19)^2;
rhs =y(18);
residual(8)= lhs-rhs;
lhs =y(13)/params(20)^2;
rhs =y(19);
residual(9)= lhs-rhs;
lhs =y(14)/params(21)^2;
rhs =y(20);
residual(10)= lhs-rhs;
lhs =y(15)/params(22)^2;
rhs =y(21);
residual(11)= lhs-rhs;
residual(12) = x(it_, 3)*(y(5)-x(it_, 10))+(1-x(it_, 3))*((-y(16))+y(17)+params(18)*y(18)+params(8)*y(26)+params(9)*y(20)+params(10)*y(4)+params(14)*y(21));
residual(13) = x(it_, 4)*(y(6)-x(it_, 11))+(1-x(it_, 4))*((-y(17))+params(2)*y(25)+params(3)*y(19)+params(4)*y(3));
residual(14) = x(it_, 6)*(y(8)-x(it_, 12))+(1-x(it_, 6))*(y(16)-y(19));
residual(15) = x(it_, 7)*(y(9)-x(it_, 13))+(1-x(it_, 7))*(y(16)-y(20));
residual(16) = x(it_, 8)*(y(10)-x(it_, 15))+(1-x(it_, 8))*((-y(21))-y(22));
residual(17) = x(it_, 9)*(y(11)-x(it_, 16))+(1-x(it_, 9))*(y(19)*(params(5)+y(11)*2*params(6))+y(20)*(params(11)+y(11)*2*params(12))+y(21)*(params(15)+y(11)*2*params(16)));
residual(18) = x(it_, 5)*(y(7)-x(it_, 14))+(1-x(it_, 5))*((-y(17))-y(18));
if nargout >= 2,
  g1 = zeros(18, 42);

  %
  % Jacobian matrix
  %

  g1(1,5)=1;
  g1(1,8)=(-1);
  g1(1,9)=(-1);
  g1(1,27)=(-1);
  g1(2,5)=(-1);
  g1(2,6)=1;
  g1(2,7)=1;
  g1(3,5)=(-params(18));
  g1(3,7)=1;
  g1(3,12)=(-1);
  g1(4,2)=(-params(2));
  g1(4,6)=(-params(3));
  g1(4,24)=(-params(4));
  g1(4,8)=1;
  g1(4,11)=(-(params(5)+params(6)*2*y(11)));
  g1(4,13)=(-1);
  g1(5,1)=(-params(8));
  g1(5,5)=(-params(9));
  g1(5,23)=(-params(10));
  g1(5,9)=1;
  g1(5,11)=(-(params(11)+params(12)*2*y(11)));
  g1(5,14)=(-1);
  g1(6,5)=(-params(14));
  g1(6,10)=1;
  g1(6,11)=(-(params(15)+params(16)*2*y(11)));
  g1(6,15)=(-1);
  g1(7,10)=1;
  g1(7,28)=(-1);
  g1(8,12)=1/params(19)^2;
  g1(8,18)=(-1);
  g1(9,13)=1/params(20)^2;
  g1(9,19)=(-1);
  g1(10,14)=1/params(21)^2;
  g1(10,20)=(-1);
  g1(11,15)=1/params(22)^2;
  g1(11,21)=(-1);
  g1(12,5)=x(it_, 3);
  g1(12,16)=(-(1-x(it_, 3)));
  g1(12,17)=1-x(it_, 3);
  g1(12,18)=params(18)*(1-x(it_, 3));
  g1(12,4)=params(10)*(1-x(it_, 3));
  g1(12,20)=params(9)*(1-x(it_, 3));
  g1(12,26)=params(8)*(1-x(it_, 3));
  g1(12,21)=params(14)*(1-x(it_, 3));
  g1(12,29)=y(5)-x(it_, 10)-((-y(16))+y(17)+params(18)*y(18)+params(8)*y(26)+params(9)*y(20)+params(10)*y(4)+params(14)*y(21));
  g1(12,36)=(-x(it_, 3));
  g1(13,6)=x(it_, 4);
  g1(13,17)=(-(1-x(it_, 4)));
  g1(13,3)=params(4)*(1-x(it_, 4));
  g1(13,19)=params(3)*(1-x(it_, 4));
  g1(13,25)=params(2)*(1-x(it_, 4));
  g1(13,30)=y(6)-x(it_, 11)-((-y(17))+params(2)*y(25)+params(3)*y(19)+params(4)*y(3));
  g1(13,37)=(-x(it_, 4));
  g1(14,8)=x(it_, 6);
  g1(14,16)=1-x(it_, 6);
  g1(14,19)=(-(1-x(it_, 6)));
  g1(14,32)=y(8)-x(it_, 12)-(y(16)-y(19));
  g1(14,38)=(-x(it_, 6));
  g1(15,9)=x(it_, 7);
  g1(15,16)=1-x(it_, 7);
  g1(15,20)=(-(1-x(it_, 7)));
  g1(15,33)=y(9)-x(it_, 13)-(y(16)-y(20));
  g1(15,39)=(-x(it_, 7));
  g1(16,10)=x(it_, 8);
  g1(16,21)=(-(1-x(it_, 8)));
  g1(16,22)=(-(1-x(it_, 8)));
  g1(16,34)=y(10)-x(it_, 15)-((-y(21))-y(22));
  g1(16,41)=(-x(it_, 8));
  g1(17,11)=x(it_, 9)+(1-x(it_, 9))*(y(19)*2*params(6)+y(20)*2*params(12)+y(21)*2*params(16));
  g1(17,19)=(1-x(it_, 9))*(params(5)+y(11)*2*params(6));
  g1(17,20)=(1-x(it_, 9))*(params(11)+y(11)*2*params(12));
  g1(17,21)=(1-x(it_, 9))*(params(15)+y(11)*2*params(16));
  g1(17,35)=y(11)-x(it_, 16)-(y(19)*(params(5)+y(11)*2*params(6))+y(20)*(params(11)+y(11)*2*params(12))+y(21)*(params(15)+y(11)*2*params(16)));
  g1(17,42)=(-x(it_, 9));
  g1(18,7)=x(it_, 5);
  g1(18,17)=(-(1-x(it_, 5)));
  g1(18,18)=(-(1-x(it_, 5)));
  g1(18,31)=y(7)-x(it_, 14)-((-y(17))-y(18));
  g1(18,40)=(-x(it_, 5));
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],18,1764);
end
if nargout >= 4,
  %
  % Third order derivatives
  %

  g3 = sparse([],[],[],18,74088);
end
end
