function [residual, g1, g2] = islm_fit_static(y, x, params)
%
% Status : Computes static model for Dynare
%
% Inputs : 
%   y         [M_.endo_nbr by 1] double    vector of endogenous variables in declaration order
%   x         [M_.exo_nbr by 1] double     vector of exogenous variables in declaration order
%   params    [M_.param_nbr by 1] double   vector of parameter values in declaration order
%
% Outputs:
%   residual  [M_.endo_nbr by 1] double    vector of residuals of the static model equations 
%                                          in order of declaration of the equations
%   g1        [M_.endo_nbr by M_.endo_nbr] double    Jacobian matrix of the static model equations;
%                                                     columns: variables in declaration order
%                                                     rows: equations in order of declaration
%   g2        [M_.endo_nbr by (M_.endo_nbr)^2] double   Hessian matrix of the static model equations;
%                                                       columns: variables in declaration order
%                                                       rows: equations in order of declaration
%
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

residual = zeros( 18, 1);

%
% Model equations
%

lhs =y(1);
rhs =y(4)+y(5)+x(1);
residual(1)= lhs-rhs;
lhs =y(2);
rhs =y(1)-y(3);
residual(2)= lhs-rhs;
lhs =y(3);
rhs =params(17)+y(1)*params(18)+y(8);
residual(3)= lhs-rhs;
lhs =y(4);
rhs =params(1)+y(2)*params(2)+y(2)*params(3)+y(2)*params(4)+params(5)*y(7)+params(6)*y(7)^2+y(9);
residual(4)= lhs-rhs;
lhs =y(5);
rhs =params(7)+y(1)*params(8)+y(1)*params(9)+y(1)*params(10)+y(7)*params(11)+y(7)^2*params(12)+y(10);
residual(5)= lhs-rhs;
lhs =y(6);
rhs =params(13)+y(1)*params(14)+y(7)*params(15)+y(7)^2*params(16)+y(11);
residual(6)= lhs-rhs;
lhs =y(6);
rhs =x(2);
residual(7)= lhs-rhs;
lhs =y(8)/params(19)^2;
rhs =y(14);
residual(8)= lhs-rhs;
lhs =y(9)/params(20)^2;
rhs =y(15);
residual(9)= lhs-rhs;
lhs =y(10)/params(21)^2;
rhs =y(16);
residual(10)= lhs-rhs;
lhs =y(11)/params(22)^2;
rhs =y(17);
residual(11)= lhs-rhs;
residual(12) = x(3)*(y(1)-x(10))+(1-x(3))*((-y(12))+y(13)+params(18)*y(14)+params(8)*y(16)+params(9)*y(16)+params(10)*y(16)+params(14)*y(17));
residual(13) = x(4)*(y(2)-x(11))+(1-x(4))*((-y(13))+params(2)*y(15)+params(3)*y(15)+params(4)*y(15));
residual(14) = x(6)*(y(4)-x(12))+(1-x(6))*(y(12)-y(15));
residual(15) = x(7)*(y(5)-x(13))+(1-x(7))*(y(12)-y(16));
residual(16) = x(8)*(y(6)-x(15))+(1-x(8))*((-y(17))-y(18));
residual(17) = x(9)*(y(7)-x(16))+(1-x(9))*(y(15)*(params(5)+y(7)*2*params(6))+y(16)*(params(11)+y(7)*2*params(12))+y(17)*(params(15)+y(7)*2*params(16)));
residual(18) = x(5)*(y(3)-x(14))+(1-x(5))*((-y(13))-y(14));
if ~isreal(residual)
  residual = real(residual)+imag(residual).^2;
end
if nargout >= 2,
  g1 = zeros(18, 18);

  %
  % Jacobian matrix
  %

  g1(1,1)=1;
  g1(1,4)=(-1);
  g1(1,5)=(-1);
  g1(2,1)=(-1);
  g1(2,2)=1;
  g1(2,3)=1;
  g1(3,1)=(-params(18));
  g1(3,3)=1;
  g1(3,8)=(-1);
  g1(4,2)=(-(params(4)+params(2)+params(3)));
  g1(4,4)=1;
  g1(4,7)=(-(params(5)+params(6)*2*y(7)));
  g1(4,9)=(-1);
  g1(5,1)=(-(params(10)+params(8)+params(9)));
  g1(5,5)=1;
  g1(5,7)=(-(params(11)+params(12)*2*y(7)));
  g1(5,10)=(-1);
  g1(6,1)=(-params(14));
  g1(6,6)=1;
  g1(6,7)=(-(params(15)+params(16)*2*y(7)));
  g1(6,11)=(-1);
  g1(7,6)=1;
  g1(8,8)=1/params(19)^2;
  g1(8,14)=(-1);
  g1(9,9)=1/params(20)^2;
  g1(9,15)=(-1);
  g1(10,10)=1/params(21)^2;
  g1(10,16)=(-1);
  g1(11,11)=1/params(22)^2;
  g1(11,17)=(-1);
  g1(12,1)=x(3);
  g1(12,12)=(-(1-x(3)));
  g1(12,13)=1-x(3);
  g1(12,14)=params(18)*(1-x(3));
  g1(12,16)=(1-x(3))*(params(10)+params(8)+params(9));
  g1(12,17)=params(14)*(1-x(3));
  g1(13,2)=x(4);
  g1(13,13)=(-(1-x(4)));
  g1(13,15)=(1-x(4))*(params(4)+params(2)+params(3));
  g1(14,4)=x(6);
  g1(14,12)=1-x(6);
  g1(14,15)=(-(1-x(6)));
  g1(15,5)=x(7);
  g1(15,12)=1-x(7);
  g1(15,16)=(-(1-x(7)));
  g1(16,6)=x(8);
  g1(16,17)=(-(1-x(8)));
  g1(16,18)=(-(1-x(8)));
  g1(17,7)=x(9)+(1-x(9))*(y(15)*2*params(6)+y(16)*2*params(12)+y(17)*2*params(16));
  g1(17,15)=(1-x(9))*(params(5)+y(7)*2*params(6));
  g1(17,16)=(1-x(9))*(params(11)+y(7)*2*params(12));
  g1(17,17)=(1-x(9))*(params(15)+y(7)*2*params(16));
  g1(18,3)=x(5);
  g1(18,13)=(-(1-x(5)));
  g1(18,14)=(-(1-x(5)));
  if ~isreal(g1)
    g1 = real(g1)+2*imag(g1);
  end
end
if nargout >= 3,
  %
  % Hessian matrix
  %

  g2 = sparse([],[],[],18,324);
end
end
