function y = islm_yearfit_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(21)=y(20);
y(22)=y(21);
y(23)=y(1);
y(24)=y(23);
