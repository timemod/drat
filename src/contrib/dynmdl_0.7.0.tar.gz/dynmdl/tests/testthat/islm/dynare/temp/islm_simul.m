%
% Status : main Dynare file 
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

tic;
global M_ oo_ options_ ys0_ ex0_ estimation_info
options_ = [];
M_.fname = 'islm_simul';
%
% Some global variables initialization
%
global_initialization;
diary off;
diary('islm_simul.log');
M_.exo_names = 'g';
M_.exo_names_tex = 'g';
M_.exo_names_long = 'g';
M_.exo_names = char(M_.exo_names, 'ms');
M_.exo_names_tex = char(M_.exo_names_tex, 'ms');
M_.exo_names_long = char(M_.exo_names_long, 'ms');
M_.endo_names = 'y';
M_.endo_names_tex = 'y';
M_.endo_names_long = 'y';
M_.endo_names = char(M_.endo_names, 'yd');
M_.endo_names_tex = char(M_.endo_names_tex, 'yd');
M_.endo_names_long = char(M_.endo_names_long, 'yd');
M_.endo_names = char(M_.endo_names, 't');
M_.endo_names_tex = char(M_.endo_names_tex, 't');
M_.endo_names_long = char(M_.endo_names_long, 't');
M_.endo_names = char(M_.endo_names, 'c');
M_.endo_names_tex = char(M_.endo_names_tex, 'c');
M_.endo_names_long = char(M_.endo_names_long, 'c');
M_.endo_names = char(M_.endo_names, 'i');
M_.endo_names_tex = char(M_.endo_names_tex, 'i');
M_.endo_names_long = char(M_.endo_names_long, 'i');
M_.endo_names = char(M_.endo_names, 'md');
M_.endo_names_tex = char(M_.endo_names_tex, 'md');
M_.endo_names_long = char(M_.endo_names_long, 'md');
M_.endo_names = char(M_.endo_names, 'r');
M_.endo_names_tex = char(M_.endo_names_tex, 'r');
M_.endo_names_long = char(M_.endo_names_long, 'r');
M_.param_names = 'c0';
M_.param_names_tex = 'c0';
M_.param_names_long = 'c0';
M_.param_names = char(M_.param_names, 'c1');
M_.param_names_tex = char(M_.param_names_tex, 'c1');
M_.param_names_long = char(M_.param_names_long, 'c1');
M_.param_names = char(M_.param_names, 'c2');
M_.param_names_tex = char(M_.param_names_tex, 'c2');
M_.param_names_long = char(M_.param_names_long, 'c2');
M_.param_names = char(M_.param_names, 'c3');
M_.param_names_tex = char(M_.param_names_tex, 'c3');
M_.param_names_long = char(M_.param_names_long, 'c3');
M_.param_names = char(M_.param_names, 'c4');
M_.param_names_tex = char(M_.param_names_tex, 'c4');
M_.param_names_long = char(M_.param_names_long, 'c4');
M_.param_names = char(M_.param_names, 'c5');
M_.param_names_tex = char(M_.param_names_tex, 'c5');
M_.param_names_long = char(M_.param_names_long, 'c5');
M_.param_names = char(M_.param_names, 'i0');
M_.param_names_tex = char(M_.param_names_tex, 'i0');
M_.param_names_long = char(M_.param_names_long, 'i0');
M_.param_names = char(M_.param_names, 'i1');
M_.param_names_tex = char(M_.param_names_tex, 'i1');
M_.param_names_long = char(M_.param_names_long, 'i1');
M_.param_names = char(M_.param_names, 'i2');
M_.param_names_tex = char(M_.param_names_tex, 'i2');
M_.param_names_long = char(M_.param_names_long, 'i2');
M_.param_names = char(M_.param_names, 'i3');
M_.param_names_tex = char(M_.param_names_tex, 'i3');
M_.param_names_long = char(M_.param_names_long, 'i3');
M_.param_names = char(M_.param_names, 'i4');
M_.param_names_tex = char(M_.param_names_tex, 'i4');
M_.param_names_long = char(M_.param_names_long, 'i4');
M_.param_names = char(M_.param_names, 'i5');
M_.param_names_tex = char(M_.param_names_tex, 'i5');
M_.param_names_long = char(M_.param_names_long, 'i5');
M_.param_names = char(M_.param_names, 'm0');
M_.param_names_tex = char(M_.param_names_tex, 'm0');
M_.param_names_long = char(M_.param_names_long, 'm0');
M_.param_names = char(M_.param_names, 'm1');
M_.param_names_tex = char(M_.param_names_tex, 'm1');
M_.param_names_long = char(M_.param_names_long, 'm1');
M_.param_names = char(M_.param_names, 'm2');
M_.param_names_tex = char(M_.param_names_tex, 'm2');
M_.param_names_long = char(M_.param_names_long, 'm2');
M_.param_names = char(M_.param_names, 'm3');
M_.param_names_tex = char(M_.param_names_tex, 'm3');
M_.param_names_long = char(M_.param_names_long, 'm3');
M_.param_names = char(M_.param_names, 't0');
M_.param_names_tex = char(M_.param_names_tex, 't0');
M_.param_names_long = char(M_.param_names_long, 't0');
M_.param_names = char(M_.param_names, 't1');
M_.param_names_tex = char(M_.param_names_tex, 't1');
M_.param_names_long = char(M_.param_names_long, 't1');
M_.exo_det_nbr = 0;
M_.exo_nbr = 2;
M_.endo_nbr = 7;
M_.param_nbr = 18;
M_.orig_endo_nbr = 7;
M_.aux_vars = [];
M_.Sigma_e = zeros(2, 2);
M_.Correlation_matrix = eye(2, 2);
M_.H = 0;
M_.Correlation_matrix_ME = 1;
M_.sigma_e_is_diagonal = 1;
options_.block=0;
options_.bytecode=0;
options_.use_dll=0;
erase_compiled_function('islm_simul_static');
erase_compiled_function('islm_simul_dynamic');
M_.lead_lag_incidence = [
 1 3 10;
 2 4 11;
 0 5 0;
 0 6 0;
 0 7 0;
 0 8 0;
 0 9 0;]';
M_.nstatic = 5;
M_.nfwrd   = 0;
M_.npred   = 0;
M_.nboth   = 2;
M_.nsfwrd   = 2;
M_.nspred   = 2;
M_.ndynamic   = 2;
M_.equations_tags = {
};
M_.static_and_dynamic_models_differ = 0;
M_.exo_names_orig_ord = [1:2];
M_.maximum_lag = 1;
M_.maximum_lead = 1;
M_.maximum_endo_lag = 1;
M_.maximum_endo_lead = 1;
oo_.steady_state = zeros(7, 1);
M_.maximum_exo_lag = 0;
M_.maximum_exo_lead = 0;
oo_.exo_steady_state = zeros(2, 1);
M_.params = NaN(18, 1);
M_.NNZDerivatives = zeros(3, 1);
M_.NNZDerivatives(1) = 24;
M_.NNZDerivatives(2) = 0;
M_.NNZDerivatives(3) = -1;
M_.params( 1 ) = 100;
c0 = M_.params( 1 );
M_.params( 2 ) = 0.28;
c1 = M_.params( 2 );
M_.params( 3 ) = 0.32;
c2 = M_.params( 3 );
M_.params( 4 ) = 0.10;
c3 = M_.params( 4 );
M_.params( 5 ) = (-20);
c4 = M_.params( 5 );
M_.params( 6 ) = 1;
c5 = M_.params( 6 );
M_.params( 7 ) = 100;
i0 = M_.params( 7 );
M_.params( 8 ) = 0.12;
i1 = M_.params( 8 );
M_.params( 9 ) = 0.08;
i2 = M_.params( 9 );
M_.params( 10 ) = 0.04;
i3 = M_.params( 10 );
M_.params( 11 ) = (-40);
i4 = M_.params( 11 );
M_.params( 12 ) = (-1.5);
i5 = M_.params( 12 );
M_.params( 13 ) = 75;
m0 = M_.params( 13 );
M_.params( 14 ) = 0.23;
m1 = M_.params( 14 );
M_.params( 15 ) = (-35);
m2 = M_.params( 15 );
M_.params( 16 ) = (-1.5);
m3 = M_.params( 16 );
M_.params( 17 ) = (-15);
t0 = M_.params( 17 );
M_.params( 18 ) = 0.22;
t1 = M_.params( 18 );
%
% INITVAL instructions
%
options_.initval_file = 0;
oo_.exo_steady_state( 1 ) = 240;
oo_.exo_steady_state( 2 ) = 230;
oo_.steady_state( 7 ) = 3.5;
oo_.steady_state( 1 ) = 980;
oo_.steady_state( 4 ) = 500;
oo_.steady_state( 3 ) = 100;
oo_.steady_state( 6 ) = oo_.exo_steady_state(2);
oo_.steady_state( 2 ) = oo_.steady_state(1)-oo_.steady_state(3);
oo_.steady_state( 5 ) = oo_.steady_state(1)-oo_.steady_state(4)-oo_.exo_steady_state(1);
if M_.exo_nbr > 0;
	oo_.exo_simul = [ones(M_.maximum_lag,1)*oo_.exo_steady_state'];
end;
if M_.exo_det_nbr > 0;
	oo_.exo_det_simul = [ones(M_.maximum_lag,1)*oo_.exo_det_steady_state'];
end;
steady;
oo_.dr.eigval = check(M_,options_,oo_);
%
% INITVAL instructions
%
options_.initval_file = 0;
oo_.steady_state( 1 ) = 1200;
if M_.exo_nbr > 0;
	oo_.exo_simul = [ones(M_.maximum_lag,1)*oo_.exo_steady_state'];
end;
if M_.exo_det_nbr > 0;
	oo_.exo_det_simul = [ones(M_.maximum_lag,1)*oo_.exo_det_steady_state'];
end;
%
% ENDVAL instructions
%
ys0_= oo_.steady_state;
ex0_ = oo_.exo_steady_state;
oo_.steady_state( 1 ) = 1210.381827;
%
% SHOCKS instructions
%
make_ex_;
set_shocks(0,1, 1, 245);
set_shocks(0,2, 1, 250);
set_shocks(0,3, 1, 260);
M_.exo_det_length = 0;
options_.periods = 18;
simul();
save('islm_simul_results.mat', 'oo_', 'M_', 'options_');
if exist('estim_params_', 'var') == 1
  save('islm_simul_results.mat', 'estim_params_', '-append');
end
if exist('bayestopt_', 'var') == 1
  save('islm_simul_results.mat', 'bayestopt_', '-append');
end
if exist('dataset_', 'var') == 1
  save('islm_simul_results.mat', 'dataset_', '-append');
end
if exist('estimation_info', 'var') == 1
  save('islm_simul_results.mat', 'estimation_info', '-append');
end


disp(['Total computing time : ' dynsec2hms(toc) ]);
if ~isempty(lastwarn)
  disp('Note: warning(s) encountered in MATLAB/Octave code')
end
diary off
