void set_solve_options(int *mws_index, SEXP options);
