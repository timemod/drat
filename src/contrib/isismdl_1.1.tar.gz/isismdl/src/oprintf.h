/* used for model conversion outout */

void oprintf( char *fmt, ... );
void xprintf( char *fmt, ... );
void initout();
void setoleader();
void setmaxowid(size_t width);
void setfpout(FILE *fp);
void setlinecont(char lchar);

