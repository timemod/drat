library(testthat)
library(umfpackr)

test_check("umfpackr")
